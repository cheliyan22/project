import { SurfaceProvider } from '../environment/SurfaceMaterials'
import { useEnvironment } from '../environment/ScenePrimitives'
import { useMemo, useState, type ReactNode } from 'react'
import type { CitySceneProps } from '../CityWorldModule'
import { CITIES, type CityId } from '../cityRegistry'
import { CityTower, makeTowerDNA, type TowerCap } from './cityKit'
import { DistrictMegaTitle } from '../environment/MegaTitles'
import { ExplorationSites } from '../environment/ExplorationSites'
import { WorldHost } from '@/planet/worlds/WorldHost'

/** Project buildings retain real status and selection; the world around them is
 *  authored per district by the world kit. */
export function DistrictScene({ city, children, cap = 'spire', projects, selectedId, onSelect }: CitySceneProps & { city: CityId; children?: ReactNode; cap?: TowerCap }) {
  const { lowEffects } = useEnvironment()
  const palette = CITIES[city].palette
  const [hovered, setHovered] = useState<string | null>(null)
  const towers = useMemo(() => projects.map((p, i) => makeTowerDNA(p, i, projects.length)), [projects])
  return <SurfaceProvider city={city} low={lowEffects}><group name={city+'-district'}>
    <WorldHost city={city} />
    <DistrictMegaTitle city={city} />
    <ExplorationSites city={city} />
    {children}
    {projects.map((project,i)=><CityTower key={project.id} project={project} dna={towers[i]} palette={palette} cap={cap} hovered={hovered === project.id} selected={selectedId === project.id} onHover={setHovered} onSelect={onSelect} />)}
  </group></SurfaceProvider>
}
