import * as THREE from 'three'
import type { Architecture, Shape } from '../environment/ScenePrimitives'

/** Bake only explicitly solid architecture. Animated scenery never enters this static mesh. */
export function bakeCollisionGeometry(root: THREE.Object3D) {
  const vertices: number[] = [], indices: number[] = []
  const geometries = new Map<Shape, THREE.BufferGeometry>([
    ['box', new THREE.BoxGeometry()], ['hex', new THREE.CylinderGeometry(1,1,1,6)],
    ['pillar', new THREE.CylinderGeometry(1,1,1,12)], ['cone', new THREE.ConeGeometry(1,1,6)],
    ['orb', new THREE.SphereGeometry(1,16,10)], ['rock', new THREE.IcosahedronGeometry(1,0)],
  ])
  const dummy = new THREE.Object3D(), point = new THREE.Vector3(), matrix = new THREE.Matrix4()
  function append(geometry: THREE.BufferGeometry, transform: THREE.Matrix4) {
    const positions = geometry.getAttribute('position'), offset = vertices.length / 3
    for (let i=0;i<positions.count;i++) { point.fromBufferAttribute(positions,i).applyMatrix4(transform); vertices.push(point.x,point.y,point.z) }
    const index = geometry.index
    for (let i=0;i<(index?.count ?? positions.count);i++) indices.push(offset+(index ? index.getX(i) : i))
  }
  root.updateWorldMatrix(true,true)
  root.traverse(object => {
    const architecture = object.userData.solidArchitecture as Architecture | undefined
    if (architecture) for (const part of architecture.parts) {
      const geometry = geometries.get(part.shape)
      if (!geometry || part.glow || Math.max(...part.s) < .4) continue
      dummy.position.set(...part.p); dummy.rotation.set(...part.r); dummy.scale.set(...part.s); dummy.updateMatrix()
      matrix.multiplyMatrices(object.matrixWorld,dummy.matrix); append(geometry,matrix)
    }
    // Project colliders follow customization, lean and true displayed dimensions.
    if (object.userData.projectId) object.children.forEach(child => {
      if (child instanceof THREE.Mesh && child.geometry && child.material instanceof THREE.MeshStandardMaterial) append(child.geometry, child.matrixWorld)
    })
  })
  geometries.forEach(geometry => geometry.dispose())
  return { vertices: new Float32Array(vertices), indices: new Uint32Array(indices) }
}
