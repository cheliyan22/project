import { ReflectionLighting } from './environment/ReflectionLighting'
import { worldOf } from '@/planet/worlds/profiles'
import { WORLD_PROFILES } from './worldManifest'
import { ExplorationHUD } from './exploration/ExplorationHUD'
import { Weather,WeatherControl } from './environment/Weather'
import { ZeroScene } from '../zero/ZeroScene'
import { isZeroProject,recordedViews,sceneBuildings } from '@/planet/lib/projectDiscovery'
import { LandmarkConsole } from './environment/LandmarkConsole'
import { useDistrictSignals } from './environment/districtSignals'
import { Component, Suspense, lazy, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { ACESFilmicToneMapping, HalfFloatType, SRGBColorSpace, UnsignedByteType } from 'three'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { SoftShadows } from '@react-three/drei'
import { Bloom, EffectComposer, N8AO, SMAA, ToneMapping } from '@react-three/postprocessing'
import { ToneMappingMode } from 'postprocessing'
import { supportsHdrBuffers } from '@/planet/lib/hdrSupport'
import { HdrGuard } from '@/planet/lib/HdrGuard'
import { OrbitalWorld } from './OrbitalWorld'
import { ArrivalCamera } from './ArrivalCamera'
import { FlightDeck } from './FlightDeck'
import { useJourney } from '@/planet/stores/journey'
import { CityLife } from './CityLife'
import { EnvironmentSettings } from './environment/ScenePrimitives'
import { CITY_STORIES, CITY_LIGHTING } from './environment/cityDesign'
import { ViewpointCamera } from './environment/ViewpointCamera'
import { WorldControls } from './WorldControls'
import { useUI } from '@/planet/stores/ui'
import { useAuth, useProjects } from '@/planet/stores/auth'
import { planPlanet } from '@/planet/modules/city/CityModule'
import { ProjectDetail } from '@/planet/modules/city/CityVisualization'
import { CustomizationPanel } from '@/planet/components/CustomizationPanel'
import { CITIES, isCityId, CITY_CATEGORIES, CITY_LABELS, CITY_ENV, type CityId } from './cityRegistry'
import { DISTRICT_MAP } from '@/planet/types/project'
import { CITY_SCENES } from './cityScenes'
import { PortalTransition } from './PortalTransition'
import { useCityNavigation, useMotionSettings } from './hooks/useCityNavigation'
import { useRenderProbe, type RenderFailure } from './hooks/useRenderProbe'
import { PersonalCityScene } from './PersonalCityScene'
import { useEconomy } from '@/planet/stores/economy'

const Exploration = lazy(() => import('./exploration/Exploration'))
const WorldsScene = lazy(() => import('@/planet/modules/city/MiniatureWorlds').then(m => ({default: m.WorldsScene})))
class SceneBoundary extends Component<{children: ReactNode; onError: () => void; fallback: ReactNode}, {failed: boolean}> {
  state = {failed: false}
  static getDerivedStateFromError() { return {failed: true} }
  componentDidCatch() { this.props.onError() }
  render() { return this.state.failed ? this.props.fallback : this.props.children }
}
/** Frames a district from its authored entrance viewpoint whenever it loads. */
function Framing({ city, active }: {city: CityId; active: boolean}) {
  const camera = useThree(s => s.camera)
  const controls = useThree(s => s.controls) as unknown as {target: {set: (x: number, y: number, z: number) => void}; update: () => void} | null
  useEffect(() => {
    if (!active) return
    // Every world shares the same civic deck radius, so one elevated
    // three-quarter establishing shot frames all of them without ever sitting
    // inside a grove, terrace or rim feature.
    camera.position.set(56, 42, 88)
    camera.lookAt(0, 12, 0)
    if (controls) {
      controls.target.set(0, 12, 0)
      controls.update()
    }
  }, [city, active, camera, controls])
  return null
}
/* Reports that a district's subtree — lazy chunk included — has committed. This
 * is mounting only; whether that subtree produced a visible frame is the
 * probe's call, because a committed scene can still be an empty clear colour
 * while its shaders compile. */
function SceneMounted({ onMounted }: {onMounted: () => void}) {
  const frames = useRef(0)
  const invalidate = useThree(s => s.invalidate)
  useFrame(() => {
    frames.current++
    if (frames.current === 1) onMounted()
    if (frames.current < 4) invalidate()
  })
  return null
}
/** Reads the district's presented frame and reports when it actually holds a picture. */
function RenderProbe({active, nonce, onSlow, onPainted, onFailed}: {active: boolean; nonce: number; onSlow: () => void; onPainted: () => void; onFailed: (failure: RenderFailure) => void}) {
  useRenderProbe({active, nonce, onSlow, onPainted, onFailed})
  return null
}
function ContextHealth({ onLost }: {onLost: () => void}) {
  const gl = useThree(s => s.gl)
  useEffect(() => {
    const lost = (event: Event) => { event.preventDefault(); onLost() }
    gl.domElement.addEventListener('webglcontextlost', lost)
    return () => gl.domElement.removeEventListener('webglcontextlost', lost)
  }, [gl, onLost])
  return null
}
function supportsWebGL() {
  try {
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('webgl2')
    if (!context) return false
    context.getExtension('WEBGL_lose_context')?.loseContext()
    return true
  } catch { return false }
}

export function CityWorldManager() {
  const {phase, destination, busy} = useCityNavigation()
  const {reduced, lowEffects, setLowEffects} = useMotionSettings()
  const hdr = supportsHdrBuffers()
  const [hdrFailed, setHdrFailed] = useState(false)
  const useHdr = hdr && !hdrFailed
  const category = useUI(s => s.cityCategory)
  const exploring = useUI(s => s.exploring)
  const recording = useUI(s => s.recording)
  const mode = useUI(s => s.mode)
  const introducing = useJourney(s => s.introducing)
  const hub = !category && mode !== 'personal' && mode !== 'zero' && mode !== 'worlds'
  const projects = useProjects(s => s.projects)
  const projectError = useProjects(s => s.error)
  const projectsLoading = useProjects(s => s.loading)
  const selectedId = useUI(s => s.selectedProjectId)
  const selectProject = useUI(s => s.selectProject)
  const error = useUI(s => s.travelError)
  const status = useUI(s => s.statusFilter)
  const sort = useUI(s => s.sortFilter)
  const filter = useUI(s => s.categoryFilter)
  const [guideOpen,setGuideOpen]=useState(false)
  /* Three separate facts, because they fail at different times: the subtree
   * committed, its first frame was confirmed on screen, or it never drew. */
  const [readyKey, setReadyKey] = useState('')
  const [mountedKey, setMountedKey] = useState('')
  const [stalledKey, setStalledKey] = useState('')
  const [probeNonce, setProbeNonce] = useState(0)
  const [viewpoint, setViewpoint] = useState({view:'Entrance',request:0})
  useEffect(()=>setViewpoint({view:'Entrance',request:0}),[category])
  const [webgl, setWebgl] = useState(supportsWebGL)
  useEffect(() => { if (!webgl) useJourney.getState().finishEntry() }, [webgl])
  const veil = useRef<HTMLDivElement>(null)
  const user = useAuth(s => s.user)
  const landmarkOpen = useDistrictSignals(s => !!s.landmark || !!s.resident)
  useEffect(() => {
    useDistrictSignals.getState().close()
    return () => useDistrictSignals.getState().close()
  }, [category])
  useEffect(() => {if(selectedId) useDistrictSignals.getState().signal()}, [selectedId])
  const key = category ?? mode
  const visible = useMemo(() => {
    let list = projects.filter(p=>mode==='zero'?isZeroProject(p):!isZeroProject(p)).filter(p => (!category || p.category === category || (category==='Graveyard'&&p.status==='abandoned')) && (!status || p.status === status))
    if (!category && !busy && filter) list = list.filter(p => p.category === filter)
    return [...list].sort((a,b) => sort === 'alphabetical' ? a.name.localeCompare(b.name) : sort === 'trending' ? b.followers-a.followers : sort === 'revived' ? Number(b.status==='reviving')-Number(a.status==='reviving') : sort === 'abandoned' ? Number(b.status==='abandoned')-Number(a.status==='abandoned') : +new Date(b.createdAt)-+new Date(a.createdAt))
  }, [projects, category, status, sort, filter, busy,mode])
  const rendered=useMemo(()=>sceneBuildings(visible,selectedId),[visible,selectedId])
  const planet = useMemo(() => planPlanet(rendered), [rendered])
  const customizations=useUI(s=>s.customizations)
  const placements=useEconomy(s=>s.placements)
  const ownership=useEconomy(s=>s.ownership)
  const collisionRevision=useMemo(()=>JSON.stringify([lowEffects,rendered.map(p=>[p.id,p.category,p.stage,p.status,p.buildingCustomization,customizations[p.id]]),placements,ownership]),[lowEffects,rendered,customizations,placements,ownership])
  const customizing = useUI(s=>s.customizingProjectId)
  const selected = projects.find(p => p.id === selectedId)
  /* Appearance edits are owner-only; opening the editor for someone else's
     record only produced a failed save. */
  const canCustomize = !!selected && !!user && selected.ownerId === user.uid
  const Scene = mode==='personal'?PersonalCityScene:mode==='zero'?ZeroScene:category ? CITY_SCENES[category] : null
  const env = mode==='personal'?{bg:'#07111d',fogNear:130,fogFar:390}:category ? CITY_ENV[category]! : {bg:'#03050a', fogNear:260, fogFar:700}
  const lighting=category&&isCityId(category)?CITY_LIGHTING[category]:{sky:'#9bc4ff',sun:'#cfe2ff',intensity:1.6}
  const world=worldOf(category)
  const surfaceRig=!!category&&isCityId(category)
  const name = mode==='personal'?'My City':mode==='zero'?'Zero Hub':category ? CITY_LABELS[category] : mode === 'worlds' ? 'Worlds' : 'Reboot'
  const tintCity = destination ?? category ?? 'AI'
  const accent = isCityId(tintCity) ? CITIES[tintCity].palette.accent : '#3DD8FF'
  useEffect(() => {
    if (!webgl && phase !== 'idle') {
      useUI.getState().advanceTravel(useUI.getState().travelId, phase === 'loading' ? 'departing' : phase === 'departing' ? 'crossing' : phase === 'crossing' ? 'arriving' : 'idle')
    }
  }, [webgl, phase])
  useEffect(() => {
    const escape = (event: KeyboardEvent) => {
      if (event.defaultPrevented || document.querySelector('dialog[open]') || event.key !== 'Escape' || /INPUT|TEXTAREA/.test((event.target as HTMLElement).tagName)) return
      const state = useUI.getState()
      if (useJourney.getState().introducing) { useJourney.getState().finishEntry(); return }
      if (state.travelPhase !== 'idle') state.cancelTravel()
      else if (state.exploring) state.setExploring(false)
      else if (state.selectedProjectId) state.selectProject(null)
      else if (state.mode==='personal') state.setMode('city')
      else if (state.cityCategory==='Graveyard')state.setMode('graveyard')
      else if (state.cityCategory) state.exitCity()
    }
    window.addEventListener('keydown', escape)
    return () => { window.removeEventListener('keydown', escape); document.body.style.cursor = '' }
  }, [])
  useEffect(() => { document.body.style.cursor = '' }, [key])
  const onMounted = useMemo(() => () => setMountedKey(key), [key])
  const onPainted = useMemo(() => () => setReadyKey(key), [key])
  const onProbeSlow = useMemo(() => () => setStalledKey(key), [key])
  const onProbeFailed = useMemo(() => () => setStalledKey(key), [key])
  const retryDrawing = useMemo(() => () => { setStalledKey(''); setProbeNonce(n => n + 1) }, [])
  const onLost = useMemo(() => () => {setWebgl(false); useUI.getState().setExploring(false); useUI.getState().cancelTravel('Graphics connection lost. Project navigation is still available.')}, [])
  const fallback = <div className="world-fallback"><h2>3D view unavailable</h2><p>You can still explore cities and open their projects using the controls below.</p></div>
  const walk = () => {
    if (!webgl || busy || readyKey !== key) return
    setViewpoint({view:'Entrance',request:0})
    useUI.getState().setExploring(true)
    if (useUI.getState().exploring) useJourney.getState().signal('walk')
  }
  const frameLandmark = () => {
    if (!webgl || busy || readyKey !== key) return
    setViewpoint(v => ({view:'Landmark',request:v.request+1})); useJourney.getState().signal('landmark')
  }
  const painted = readyKey === key
  const stalled = stalledKey === key
  const renderState = !webgl ? 'unavailable' : painted ? 'painted' : stalled ? 'failed' : mountedKey === key ? 'probing' : 'mounting'
  return <div className={`absolute inset-0 dawn-world ${hub ? 'is-orbital' : 'is-surface'}`} data-city={category ?? 'hub'} data-travel-phase={phase} data-introducing={introducing} data-reduced-motion={reduced} data-exploring={exploring} data-graphics={webgl} data-render-state={renderState} data-render-ready={readyKey === key}>
    {webgl ? <SceneBoundary onError={() => {setWebgl(false); useUI.getState().setExploring(false); useUI.getState().cancelTravel('The 3D scene could not load. Project navigation is still available.')}} fallback={fallback}>
      <Canvas camera={{position:[0,26,124], fov:50, near:.25, far:1200}}
        shadows={!lowEffects} dpr={[1, lowEffects ? 1 : 2]} gl={{toneMapping:ACESFilmicToneMapping,outputColorSpace:SRGBColorSpace,antialias:!lowEffects, powerPreference:'high-performance', preserveDrawingBuffer:true}} frameloop={reduced && !busy && !exploring && !introducing && !recording ? 'demand' : 'always'}>
        <color attach="background" args={[surfaceRig ? world.sky.ground : env.bg]} />
        <fogExp2 attach="fog" args={[surfaceRig ? world.atmosphere.fog : env.bg, surfaceRig ? world.atmosphere.fogDensity : .0032]} />
        {!lowEffects && <SoftShadows size={18} samples={12} focus={.2} />}
        <ReflectionLighting enabled={!lowEffects && surfaceRig} city={category && isCityId(category) ? category : 'AI'} />
        <ambientLight intensity={surfaceRig ? world.light.ambientIntensity : .9} color={surfaceRig ? world.light.ambient : '#ffffff'} />
        <hemisphereLight args={[surfaceRig ? world.sky.top : lighting.sky, surfaceRig ? world.palette.base : '#454339', surfaceRig ? world.light.fillIntensity : .65]} />
        <directionalLight position={[-45,35,-35]} intensity={surfaceRig ? world.light.keyIntensity * .22 : .2} color={surfaceRig ? world.light.fill : lighting.sky} />
        <directionalLight position={[-90, 40, -90]} intensity={surfaceRig ? world.light.fillIntensity * .8 : .12} color={surfaceRig ? world.light.fill : lighting.sky} />
        <directionalLight castShadow={!lowEffects && world.light.shadows} shadow-mapSize={[lowEffects?2048:4096,lowEffects?2048:4096]} shadow-camera-left={-72} shadow-camera-right={72} shadow-camera-top={72} shadow-camera-bottom={-72} shadow-camera-near={20} shadow-camera-far={320} shadow-bias={-.00012} shadow-normalBias={.025} position={surfaceRig ? world.light.keyFrom : [60,80,140]} intensity={surfaceRig ? world.light.keyIntensity : lighting.intensity*1.25} color={surfaceRig ? world.light.key : lighting.sun} />
        <EnvironmentSettings.Provider value={{reduced,lowEffects}}><Suspense fallback={null}>
          {Scene ? <Scene key={key} projects={rendered} selectedId={selectedId} onSelect={p => {if (!busy) selectProject(p.id)}} /> : mode === 'worlds' ? <WorldsScene projects={planet} /> : <OrbitalWorld reduced={reduced} lowEffects={lowEffects} />}
          {(category||mode==='zero')&&<Weather />}<>{mode==='zero'&&<CityLife city="Community" reduced={reduced} lowEffects={lowEffects}/>} {category && isCityId(category) && <CityLife key={category} city={category} reduced={reduced} lowEffects={lowEffects} />}</>
          <SceneMounted key={`mounted-${key}`} onMounted={onMounted} />
          <RenderProbe key={`probe-${key}`} active={webgl && mountedKey === key && readyKey !== key} nonce={probeNonce} onSlow={onProbeSlow} onPainted={onPainted} onFailed={onProbeFailed} />
          <Framing city={category && isCityId(category) ? category : 'AI'} active={!!category && isCityId(category) && readyKey === key} />
          {exploring && !busy && ((category && isCityId(category)) || mode==='personal') && <Suspense fallback={null}><Exploration key={key} city={category && isCityId(category) ? category : 'Community'} collisionRevision={collisionRevision} paused={!!selectedId || landmarkOpen} reduced={reduced} /></Suspense>}
        </Suspense></EnvironmentSettings.Provider>
        <PortalTransition color={accent} reduced={reduced} lowEffects={lowEffects} ready={readyKey === key} veil={veil} />
        {hub && <ArrivalCamera reduced={reduced} ready={readyKey === key} />}
        {!busy && !exploring && !introducing && <WorldControls key={key} city={!!category||mode==='zero'||mode==='personal'} reduced={reduced} />}
        {!busy && mode==='zero' && <ViewpointCamera city="Community" view="Entrance" request={0} reduced={reduced}/>}
        {!busy && !exploring && category && isCityId(category) && <ViewpointCamera city={category} view={viewpoint.view} request={viewpoint.request} reduced={reduced} />}
        {!lowEffects && category && isCityId(category) && <EffectComposer multisampling={0} frameBufferType={useHdr ? HalfFloatType : UnsignedByteType}>
          <N8AO quality="high" aoRadius={2.4} distanceFalloff={1.2} intensity={1.35} denoiseSamples={8} denoiseRadius={8} halfRes depthAwareUpsampling />
          <Bloom mipmapBlur intensity={.55} luminanceThreshold={useHdr ? 1 : .8} luminanceSmoothing={.22} radius={.72} />
          <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
          <SMAA />
          <HdrGuard active={useHdr} onFail={() => setHdrFailed(true)} />
        </EffectComposer>}
        <ContextHealth onLost={onLost} />
      </Canvas>
    </SceneBoundary> : fallback}
    <div className="dawn-vignette" />
    <div ref={veil} className="portal-veil" style={{opacity:0}} />
    <FlightDeck hub={hub} city={category && isCityId(category) ? category : null} ready={webgl ? readyKey === key : true} graphics={webgl} onLandmark={frameLandmark} onWalk={walk} />
    {/* A district's chunk and shaders compile before its first frame; say so
        instead of showing an unexplained black canvas. */}
    {webgl && surfaceRig && !painted && <div className="world-preparing" role="status" aria-live="polite"><div>
      <p>Preparing {name}</p>
      <i />
      {stalled && <p className="world-preparing-note">Still drawing after fifteen seconds. <button onClick={retryDrawing}>Retry drawing</button></p>}
    </div></div>}
    {exploring && <ExplorationHUD />}
    {!busy && !introducing && projectError && <div className="world-data-status" role="status">{projectError}<button disabled={projectsLoading} onClick={() => void useProjects.getState().fetchProjects()}>{projectsLoading ? 'Retrying…' : 'Retry project records'}</button></div>}
    <div className={`world-hud ${busy || introducing ? 'is-travelling' : ''}`}>
      <section className="world-plate" aria-live="polite" style={{'--world-accent':accent} as React.CSSProperties}>
        <p className="plate-kicker">{mode==='personal'?'PERSONAL BUILD DISTRICT':category ? 'CONNECTED DISTRICT' : `${CITY_CATEGORIES.length-1} DISTRICTS`}</p>
        <h1>{name}</h1>
        <p className="plate-purpose">{mode==='personal'?'Your persistent corner of Reboot. Place one free design, build with owned structures, and walk the streets you create.':category && isCityId(category) ? WORLD_PROFILES[category].copy : mode==='zero'?'A quiet home for ideas below 100 unique beta-member views. At 100, they join their category district.':'Explore a district, or visit Zero Hub for ideas finding their first audience.'}</p>
        <dl className="plate-rows">
          {category && isCityId(category) && <div><dt>LANDMARK</dt><dd>{CITIES[category].landmark}</dd></div>}
          <div><dt>RECORDS</dt><dd>{visible.length}</dd></div>
          <div><dt>REVIVING</dt><dd>{visible.filter(p=>p.status==='reviving').length}</dd></div>
          {mode==='personal' && <div><dt>PLACED</dt><dd>{placements.length}</dd></div>}
        </dl>
        <div className="plate-actions">
          {!exploring && (mode==='personal' || (!!category && isCityId(category))) && <button className="plate-primary" disabled={busy || !webgl || readyKey !== key} onClick={walk}>{mode==='personal'?'Explore my city':'Explore world'}</button>}
          {category && isCityId(category) && <button disabled={busy || !webgl || readyKey !== key} onClick={frameLandmark}>Frame landmark</button>}
          {category && isCityId(category) && <button aria-expanded={guideOpen} onClick={()=>setGuideOpen(!guideOpen)}>{guideOpen?'Close controls':'City controls'}</button>}
        </div>
      </section>
      {mode==='personal' && <button className="world-return btn" onClick={() => useUI.getState().setMode('city')} disabled={busy}>← Return to World Hub</button>}
      {category && <button className="world-return btn" onClick={() => category==='Graveyard'?useUI.getState().setMode('graveyard'):useUI.getState().exitCity()} disabled={busy}>← {category==='Graveyard'?'Return to planet':'Return to World Hub'}</button>}
      {guideOpen && category && isCityId(category) && !exploring && <section className="plate-drawer">
        <nav className="plate-views" aria-label="City viewpoints">{['Entrance','Path','Landmark','Skyline','Activity'].map(view=><button key={view} disabled={busy} aria-pressed={viewpoint.view===view} onClick={()=>setViewpoint(v=>({view,request:v.request+1}))}>{view}</button>)}</nav>
        <button className="plate-activate" onClick={()=>useDistrictSignals.getState().open(category)}>Activate landmark ↗</button>
        <p className="plate-story">{CITY_STORIES[category].atmosphere}</p>
        <ul className="plate-sites">{CITY_STORIES[category].sites.map(site=><li key={site}>{site}</li>)}</ul>
      </section>}
      {guideOpen && mode==='personal' && !exploring && <section className="plate-drawer">
        <p className="plate-story">{placements.length} {placements.length===1?'building':'buildings'} placed. Use the Building Shop to place, reposition or customize your structures. Owned buildings stay yours when removed from the grid.</p>
      </section>}
      {(category||mode==='zero')&&<WeatherControl />}<div className="world-quality"><label><input type="checkbox" checked={lowEffects} onChange={e => setLowEffects(e.target.checked)} /> Reduced effects</label></div>
      <nav className="city-destinations" aria-label="City destinations">{CITY_CATEGORIES.map(c => <button key={c} disabled={busy} aria-pressed={category === c} style={{'--city-color':CITIES[c].palette.accent} as React.CSSProperties} onClick={() => useUI.getState().enterCity(c)}>{CITY_LABELS[c]}</button>)}</nav>
      {mode!=='personal' && <section className="world-projects" data-empty={visible.length===0}><p className="muted">Up to 120 buildings shown. {useProjects.getState().hasMore&&<button onClick={()=>useProjects.getState().fetchProjects(true)}>Load more records</button>}</p><h2 className="label-mono">{visible.length} projects / {name}</h2><div>
        {visible.map(p => <button key={p.id} disabled={busy} aria-pressed={selectedId === p.id} onClick={() => selectProject(p.id)}><span style={{color:DISTRICT_MAP[p.category].theme.color}}>◆</span> {p.name}{mode==='zero'&&` · ${recordedViews(p)}/100`}</button>)}
        {!visible.length && <p>No projects match this district and filter.</p>}
      </div></section>}

      {!busy && mode!=='personal' && <LandmarkConsole />}
      {mode!=='personal' && selected && !busy && !landmarkOpen && <>{customizing !== selected.id && <ProjectDetail project={selected} canCustomize={!!(selected.temporary || (user && selected.ownerId === user.uid))} onClose={() => selectProject(null)} />}{canCustomize && <CustomizationPanel projectId={selected.id} projectName={selected.name} />}</>}
    </div>
    {error && <div className="world-error" role="alert">{error}<button onClick={() => window.location.reload()}>Reload</button><button onClick={() => useUI.getState().cancelTravel()}>Dismiss</button></div>}
  </div>
}
