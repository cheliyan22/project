import { useEffect } from 'react'
import { useThree } from '@react-three/fiber'
import * as THREE from 'three'
import type { CityId } from '../cityRegistry'
import { CITY_LIGHTING } from './cityDesign'
import { SKIES } from './CitySky'

const environmentVertex = `
  varying vec3 vDirection;
  void main() {
    vDirection = position;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`
const environmentFragment = `
  varying vec3 vDirection;
  uniform vec3 top;
  uniform vec3 horizon;
  void main() {
    vec3 direction = normalize(vDirection);
    vec3 color = mix(horizon, top, smoothstep(-0.18, 0.82, direction.y));
    color = mix(horizon * 0.48, color, smoothstep(-0.7, 0.02, direction.y));
    gl_FragColor = vec4(color, 1.0);
  }
`

/** District-matched reflections, generated locally from the visible sky palette. */
export function ReflectionLighting({ enabled, city }: { enabled: boolean; city: CityId }) {
  const { gl, scene, invalidate } = useThree()
  useEffect(() => {
    if (!enabled) return
    const generator = new THREE.PMREMGenerator(gl)
    const environment = new THREE.Scene()
    const skyGeometry = new THREE.SphereGeometry(50, 48, 24)
    const skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        top: { value: new THREE.Color(SKIES[city][0]) },
        horizon: { value: new THREE.Color(SKIES[city][1]) },
      },
      vertexShader: environmentVertex,
      fragmentShader: environmentFragment,
    })
    const sky = new THREE.Mesh(skyGeometry, skyMaterial)
    environment.add(sky)

    // A broad HDR sun and a cool opposing fill give metal and ceramic surfaces
    // readable reflections without introducing an unrelated studio environment.
    const sunGeometry = new THREE.SphereGeometry(4.5, 24, 12)
    const sunMaterial = new THREE.MeshBasicMaterial({ color: new THREE.Color(CITY_LIGHTING[city].sun).multiplyScalar(5) })
    const sun = new THREE.Mesh(sunGeometry, sunMaterial)
    sun.position.set(19, 22, 32)
    environment.add(sun)
    const fillGeometry = new THREE.PlaneGeometry(24, 12)
    const fillMaterial = new THREE.MeshBasicMaterial({ color: new THREE.Color(CITY_LIGHTING[city].sky).multiplyScalar(1.8), side: THREE.DoubleSide })
    const fill = new THREE.Mesh(fillGeometry, fillMaterial)
    fill.position.set(-28, 8, 12)
    fill.lookAt(0, 0, 0)
    environment.add(fill)

    const target = generator.fromScene(environment, 0.035)
    const previous = scene.environment, intensity = scene.environmentIntensity
    scene.environment = target.texture
    scene.environmentIntensity = 0.62
    skyGeometry.dispose()
    skyMaterial.dispose()
    sunGeometry.dispose()
    sunMaterial.dispose()
    fillGeometry.dispose()
    fillMaterial.dispose()
    generator.dispose()
    invalidate()
    return () => {
      scene.environment = previous
      scene.environmentIntensity = intensity
      target.dispose()
      invalidate()
    }
  }, [enabled, city, gl, scene, invalidate])
  return null
}
