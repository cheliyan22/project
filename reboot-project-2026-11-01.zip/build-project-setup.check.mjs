// Builds and validates the one-shot setup script for the user's own Supabase
// project (vsddqasvaesndomdfnrf), which is currently empty.
//
// Phase 1 runs every migration, in filename order, inside PGlite with Supabase's
// roles and auth schema stubbed the way the existing execution tests stub them.
// Phase 2 reads the real column types that came out of those migrations and only
// then generates the INSERTs for the content recovered from the old project, so
// arrays go to arrays and jsonb goes to jsonb instead of being guessed at.
// Phase 3 executes those INSERTs in the same database and checks the result.
//
// The file written out is the migration text plus the generated INSERTs, i.e.
// the same thing that was just proven to run.
//
// Badges are deliberately not re-seeded: 20260706154046 and 20260706155248
// insert them, so the migrations themselves must produce all 53.
import assert from 'node:assert/strict'
import { readFile, writeFile } from 'node:fs/promises'
import { readdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { PGlite } from '@electric-sql/pglite'

const root = dirname(fileURLToPath(import.meta.url))
const migrationsDir = join(root, 'supabase', 'migrations')
const outPath = join(root, '..', '70-full-project-setup.sql')

const files = readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort()
assert.equal(files.length, 14, `expected every migration, found ${files.length}`)
console.log(`migrations in order:\n${files.map((f, n) => `  ${n + 1}. ${f}`).join('\n')}`)

const migrationSql = (await Promise.all(
  files.map(async f => `-- ===== ${f} =====\n${(await readFile(join(migrationsDir, f), 'utf8')).trim()}\n`),
)).join('\n')

const db = new PGlite()
try {
  await db.exec(`
    CREATE ROLE anon NOLOGIN;
    CREATE ROLE authenticated NOLOGIN;
    CREATE SCHEMA auth;
    CREATE TABLE auth.users (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      email text,
      created_at timestamptz NOT NULL DEFAULT now(),
      raw_user_meta_data jsonb NOT NULL DEFAULT '{}'
    );
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
      SELECT nullif(current_setting('test.uid', true), '')::uuid
    $$;
    GRANT USAGE ON SCHEMA auth TO anon, authenticated;
    GRANT EXECUTE ON FUNCTION auth.uid() TO anon, authenticated;
    -- Supabase hands future public tables to the client roles automatically, so
    -- the migrations' own REVOKE statements are tested against the state they
    -- will really meet on a live project.
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO anon, authenticated, PUBLIC;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO anon, authenticated, PUBLIC;
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon, authenticated, PUBLIC;
  `)

  await db.exec(migrationSql)
  console.log(`phase 1: all ${files.length} migrations applied cleanly`)

  const columnsOf = async table => (await db.query(
    `SELECT column_name n, data_type t, udt_name u
       FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = $1
      ORDER BY ordinal_position`, [table],
  )).rows

  const backup = JSON.parse(await readFile(join(root, '..', 'supabase-backup-qctppiuemwuamhnlmcgm.json'), 'utf8'))

  const lit = (value, col) => {
    if (value === null || value === undefined) return 'null'
    if (col.t.toUpperCase() === 'ARRAY') {
      const elemType = col.u.startsWith('_') ? col.u.slice(1) : col.u
      const elems = (value || []).map(x => `"${String(x).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`)
      return `'{${elems.join(',')}}'::${elemType}[]`
    }
    if (col.t === 'json' || col.t === 'jsonb') {
      return `'${JSON.stringify(value).replace(/'/g, "''")}'::${col.u}`
    }
    if (typeof value === 'boolean') return value ? 'true' : 'false'
    if (typeof value === 'number') return String(value)
    return `'${String(value).replace(/'/g, "''")}'`
  }

  const insertsFor = async (table, rows) => {
    if (!rows.length) return ''
    const cols = await columnsOf(table)
    const known = new Set(cols.map(c => c.n))
    const missing = Object.keys(rows[0]).filter(k => !known.has(k))
    assert.deepEqual(missing, [], `${table}: backup has columns the new schema lacks: ${missing.join(', ')}`)
    const chosen = cols.filter(c => known.has(c.n))
    const head = `INSERT INTO public.${table} (${chosen.map(c => `"${c.n}"`).join(', ')}) VALUES\n`
    const body = rows.map(r => `  (${chosen.map(c => lit(r[c.n], c)).join(', ')})`).join(',\n')
    return `${head}${body}\nON CONFLICT (id) DO NOTHING;\n`
  }

  const seedSql =
    '-- ===== recovered content from project qctppiuemwuamhnlmcgm =====\n'
    + await insertsFor('projects', backup.tables.projects)
    + '\n'
    + await insertsFor('ideas', backup.tables.ideas)

  const sql = `${migrationSql}\n${seedSql}`
  await writeFile(outPath, sql)
  console.log(`wrote ${outPath} (${(sql.length / 1024).toFixed(0)} KB)`)

  await db.exec(seedSql)
  console.log('phase 2: recovered content inserted under the real column types')

  const count = async t => Number((await db.query(`SELECT count(*) n FROM public.${t}`)).rows[0].n)
  const projects = await count('projects')
  const ideas = await count('ideas')
  const badges = await count('badges')
  console.log(`phase 3: projects=${projects} ideas=${ideas} badges=${badges}`)
  assert.equal(projects, 8, 'all 8 recovered projects should be present')
  assert.equal(ideas, 8, 'all 8 recovered ideas should be present')
  assert.equal(badges, 53, 'the badge migrations should seed all 53 badges')

  const arrays = await db.query(
    "SELECT slug, tech_stack, surviving_assets, skills_required FROM public.ideas WHERE slug = 'moodboard'",
  )
  assert.ok(Array.isArray(arrays.rows[0].tech_stack), 'text[] column should come back as an array')
  assert.equal(typeof arrays.rows[0].surviving_assets, 'object', 'jsonb column should come back parsed')

  const tables = (await db.query(
    "SELECT table_name t FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name",
  )).rows.map(r => r.t)
  for (const required of ['beta_waitlist', 'profiles', 'feature_requests', 'planet_admins']) {
    assert.ok(tables.includes(required), `expected table ${required} after setup`)
  }
  console.log(`public schema now holds ${tables.length} tables`)

  // The waitlist RPC must behave for a signed-out visitor, which is the only
  // role the published /beta page ever uses.
  await db.exec('SET ROLE anon')
  assert.equal((await db.query("SELECT public.join_beta_waitlist('  Builder@Example.COM ') n")).rows[0].n, true)
  assert.equal((await db.query("SELECT public.join_beta_waitlist('builder@example.com') n")).rows[0].n, false)
  await assert.rejects(db.query("SELECT public.join_beta_waitlist('nope')"), /valid email/)
  await assert.rejects(db.query('SELECT email FROM public.beta_waitlist'), /permission denied/)
  await db.exec('RESET ROLE')
  console.log('beta waitlist RPC verified under the anon role')

  // The landing hero is allowed to count revival signals, and is not allowed to
  // read them: a revivals row carries the sender's name and email. The "rows stay
  // invisible" half of that sentence is not provable here — this harness grants the
  // client roles ALL on every table, the same default-privilege crutch a live
  // Supabase project has, which is why the lock-down left anon able to read
  // revivals unnoticed for so long. verify-new-project.mjs asserts it against the
  // real project, where only the migration's own GRANTs exist.
  const signalCounts = async () => (await db.query('SELECT authored_ideas, revival_signals FROM public.landing_signal_counts()')).rows[0]
  await db.exec('SET ROLE anon')
  const empty = await signalCounts()
  assert.equal(Number(empty.authored_ideas), 0, 'seed ideas carry no author, so the public count must be 0')
  assert.equal(Number(empty.revival_signals), 0, 'no revival rows exist yet, so the public count must be 0')
  await db.exec('RESET ROLE')

  // One real account, one idea it authored, one revival it sent. The profile row
  // comes from the handle_new_user trigger, so only auth.users is inserted.
  const BUILDER = '0b0b0b0b-0000-4000-8000-000000000001'
  await db.exec(`
    INSERT INTO auth.users (id, email) VALUES ('${BUILDER}', 'builder@reboot.test');
    INSERT INTO public.ideas (title, slug, user_id) VALUES ('Authored for the check', 'authored-for-the-check', '${BUILDER}');
    INSERT INTO public.revivals (idea_id, reviver_name, reviver_email, user_id)
      VALUES ((SELECT id FROM public.ideas WHERE slug = 'authored-for-the-check'), 'first builder', 'builder@reboot.test', '${BUILDER}');
  `)
  await db.exec('SET ROLE anon')
  const filled = await signalCounts()
  await db.exec('RESET ROLE')
  await db.exec('RESET ROLE')
  assert.equal(Number(filled.authored_ideas), 1, 'an account-authored idea must raise the public count by exactly one')
  assert.equal(Number(filled.revival_signals), 1, 'a revival signal must raise the public count by exactly one')
  console.log('landing signal counts verified: the public totals follow account-authored rows')

  console.log('\nFULL SETUP SCRIPT VALIDATED — safe to paste into the SQL Editor.')
} finally {
  await db.close()
}
