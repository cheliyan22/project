import { CITIES, CITY_CATEGORIES, type CityId } from './cityRegistry'
import type { Vec } from './environment/ScenePrimitives'

export type AtmosphereKind = 'ash' | 'dust' | 'celebration' | 'data' | 'pixels' | 'pages' | 'mist' | 'surreal' | 'solar' | 'steam' | 'leaves'
export interface ExplorationProfile {
  copy: string
  architecture: string
  paths: string
  weather: AtmosphereKind
  gravity: number
  speed: number
  lowGravityZone?: {min: [number,number]; max: [number,number]; gravity: number; jump: number}
  spawn: Vec
  soundscape: string | null
  portal: 'pull' | 'assembly' | 'orbit' | 'glide'
  npc: string
  discoveries: readonly [string, string]
  quality: { residents: number; particles: number }
}
const profile = (copy: string, architecture: string, paths: string, weather: AtmosphereKind, npc: string, discoveries: readonly [string, string], portal: ExplorationProfile['portal'] = 'glide'): ExplorationProfile => ({
  copy, architecture, paths, weather, npc, discoveries, portal, gravity: 22, speed: 5, spawn: [0,1.5,44], soundscape: null, quality: {residents: 12, particles: 180},
})
/** Historical project IDs remain the authoritative navigation and data keys. */
export const WORLD_PROFILES: Record<CityId, ExplorationProfile> = {
  Graveyard: profile('Every abandoned idea leaves something behind.', 'Torn frames, powerless machinery and containment ruins', 'Fractured causeways', 'ash', 'Corrupted maintenance prototypes', ['Disconnected relay', 'Unfinished launch'], 'pull'),
  IdeaHub: profile('Some ideas deserve another beginning.', 'Copper scaffolds, repair bays and assembly gantries', 'Construction pads and restored bridges', 'dust', 'Repair workers and cargo drones', ['Restoration station', 'Reconnected bridge'], 'assembly'),
  Legend: profile('The ideas that survived became landmarks.', 'Ivory colonnades, arches and commemorative terraces', 'Polished stone and grand stairs', 'celebration', 'Stewards and garden visitors', ['Legacy garden', 'Milestone terrace']),
  AI: profile('Connections can reveal possibilities no one noticed.', 'Organic neural core and connected laboratories', 'Hexagonal data platforms', 'data', 'Synthetic researchers', ['Memory exchange', 'Research pavilion']),
  Gaming: profile('Explore the worlds that ideas could become.', 'Voxel cliffs, chunky arcades and checkpoint gates', 'Stepped blocks and optional jumping route', 'pixels', 'Companion bots and level builders', ['Jumping route', 'Checkpoint arena']),
  Education: profile('A failed attempt can still teach something valuable.', 'Branching archive, paper shelves and study courtyards', 'Root bridges and reading terraces', 'pages', 'Curators and knowledge guardians', ['Reading garden', 'Lessons archive']),
  Health: profile('Give ideas the conditions they need to recover.', 'Cellular conservatories and restorative gardens', 'Curved garden paths and water channels', 'mist', 'Garden keepers and care robots', ['Water garden', 'Restoration dome']),
  Creator: profile('Impossible ideas belong somewhere.', 'Tilted galleries, suspended canvases and impossible sculptures', 'Fragmented decks and sculptural bridges', 'surreal', 'Artists and assembly sprites', ['Suspended gallery', 'Impossible stair']),
  Space: {...profile('The next possibility may be beyond the map.', 'Asteroid observatories, solar arrays and orbital habitats', 'Crater decks and protected bridges', 'solar', 'Astronauts and survey drones', ['Low gravity deck', 'Orbital lookout'], 'orbit'), gravity: 22, lowGravityZone: {min:[7,24],max:[22,39],gravity:6,jump:5.8}},
  Robotics: profile('Where unfinished machines find their purpose.', 'Assembly halls, conveyors, gantries and articulated tools', 'Steel service decks', 'steam', 'Inspection robots and mechanics', ['Sorting line', 'Testing gantry']),
  Community: {...profile('No project has to be forgotten alone.', 'Terracotta homes, workshops and warm public courtyards', 'Stone streets and garden bridges', 'leaves', 'Residents, collaborators and guides', ['Market courtyard', 'Common table']), quality: {residents: 16, particles: 160}},
}
export const WORLD_MANIFEST = Object.fromEntries(CITY_CATEGORIES.map(id => [id, {...CITIES[id], ...WORLD_PROFILES[id]}])) as Record<CityId, typeof CITIES[CityId] & ExplorationProfile>
export function validateWorldManifest() {
  for (const id of CITY_CATEGORIES) {
    const world = WORLD_MANIFEST[id]
    if (world.id !== id || world.projectCategory !== id || !world.copy || !world.discoveries.length || !world.spawn.every(Number.isFinite) || !(world.gravity > 0 && world.speed > 0 && world.quality.residents > 0)) throw new Error(`Invalid world definition: ${id}`)
  }
}
validateWorldManifest()

export function physicsAt(city:CityId,x:number,z:number) {
 const profile=WORLD_PROFILES[city],zone=profile.lowGravityZone
 const low=!!zone&&x>zone.min[0]&&x<zone.max[0]&&z>zone.min[1]&&z<zone.max[1]
 return {lowGravity:low,gravity:low?zone!.gravity:profile.gravity,jump:low?zone!.jump:8.8}
}
