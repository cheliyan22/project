import type { CityId } from '@/planet/modules/cityworld/cityRegistry'
import type { ProjectCategory } from '@/planet/types/project'
import type { WorldProfile } from './types'

/* One profile per district. Accent colours are the registry's, so the city's
 * signal colour still matches the beacon, the district rail and the HUD rule.
 * Everything else — terrain, mass colours, sky, light logic, air — is authored
 * per world. */

export const WORLDS: Record<CityId, WorldProfile> = {
  Graveyard: {
    id: 'Graveyard',
    terrain: 'crater',
    sky: { top: '#06070d', horizon: '#3a3743', ground: '#05060a', sun: '#d09a6e', sunDir: [-0.7, 0.18, 0.5], night: true, stars: 0.45, clouds: 0.22, haze: 0.85 },
    light: { key: '#c98f6a', keyIntensity: 1.9, keyFrom: [-130, 44, -70], fill: '#5a5d78', fillIntensity: 0.75, ambient: '#1b1e28', ambientIntensity: 0.8, shadows: true },
    palette: { base: '#2b2f3a', mass: '#3f4454', trim: '#6f6470', accent: '#FF5959', secondary: '#a58ba0', glow: '#f2a189' },
    atmosphere: { fog: '#0b0d16', fogDensity: 0.0072, mistColor: '#6a6474', mistOpacity: 0.16, motion: 'ash', shafts: 0 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  IdeaHub: {
    id: 'IdeaHub',
    terrain: 'canyon',
    sky: { top: '#4f6d7a', horizon: '#dcc9a4', ground: '#20282a', sun: '#fff0d2', sunDir: [0.55, 0.62, 0.55], night: false, stars: 0, clouds: 0.55, haze: 0.3 },
    light: { key: '#fff2d8', keyIntensity: 2.3, keyFrom: [100, 130, 70], fill: '#a8c4b8', fillIntensity: 0.85, ambient: '#39433f', ambientIntensity: 0.4, shadows: true },
    palette: { base: '#3a4a4a', mass: '#56736c', trim: '#c49a6b', accent: '#5aebbf', secondary: '#cfe6d8', glow: '#ffe2ac' },
    atmosphere: { fog: '#4e625f', fogDensity: 0.0048, mistColor: '#cfe0cf', mistOpacity: 0.1, motion: 'sparks', shafts: 3 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Legend: {
    id: 'Legend',
    terrain: 'cliff',
    sky: { top: '#283a56', horizon: '#e8bd7d', ground: '#171c26', sun: '#ffd79a', sunDir: [-0.5, 0.4, 0.75], night: false, stars: 0.05, clouds: 0.55, haze: 0.26 },
    light: { key: '#ffdca8', keyIntensity: 2.2, keyFrom: [-90, 80, 100], fill: '#b9cfe6', fillIntensity: 0.7, ambient: '#2b2a28', ambientIntensity: 0.35, shadows: true },
    palette: { base: '#7c7360', mass: '#cfc2a2', trim: '#d8b878', accent: '#FFD27A', secondary: '#fff8e8', glow: '#fff0c8' },
    atmosphere: { fog: '#6f6152', fogDensity: 0.0024, mistColor: '#e8d7bb', mistOpacity: 0.045, motion: 'cloudsea', shafts: 2 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  AI: {
    id: 'AI',
    terrain: 'plate',
    sky: { top: '#03060e', horizon: '#0b1c28', ground: '#02040a', sun: '#a8e4ff', sunDir: [0.45, 0.5, 0.74], night: true, stars: 0.85, clouds: 0.04, haze: 0.15 },
    light: { key: '#9fd8ff', keyIntensity: 1.5, keyFrom: [70, 110, 90], fill: '#1d4b60', fillIntensity: 0.65, ambient: '#0a1620', ambientIntensity: 0.7, shadows: true },
    palette: { base: '#0d1e28', mass: '#18333f', trim: '#3f6d7c', accent: '#3DD8FF', secondary: '#327dff', glow: '#8fe6ff' },
    atmosphere: { fog: '#061018', fogDensity: 0.0062, mistColor: '#3f7f96', mistOpacity: 0.07, motion: 'pulse', shafts: 0 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Gaming: {
    id: 'Gaming',
    terrain: 'cascade',
    sky: { top: '#07040d', horizon: '#2a1740', ground: '#05030a', sun: '#ffcf8a', sunDir: [-0.55, 0.45, 0.7], night: true, stars: 0.55, clouds: 0.08, haze: 0.2 },
    light: { key: '#ffcf8a', keyIntensity: 1.5, keyFrom: [-70, 90, 80], fill: '#7a4fc0', fillIntensity: 0.6, ambient: '#1a0f26', ambientIntensity: 0.75, shadows: true },
    palette: { base: '#241a33', mass: '#402c56', trim: '#8a6ba8', accent: '#FFB547', secondary: '#B44DFF', glow: '#ffd88a' },
    atmosphere: { fog: '#0d0716', fogDensity: 0.0068, mistColor: '#5b3a86', mistOpacity: 0.09, motion: 'coins', shafts: 0 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Education: {
    id: 'Education',
    terrain: 'grove',
    sky: { top: '#7f9fb0', horizon: '#e8dcc0', ground: '#2a2f26', sun: '#ffeecb', sunDir: [0.62, 0.5, 0.6], night: false, stars: 0, clouds: 0.5, haze: 0.35 },
    light: { key: '#ffeecb', keyIntensity: 2.2, keyFrom: [80, 120, 50], fill: '#b7cfb5', fillIntensity: 0.8, ambient: '#31392f', ambientIntensity: 0.4, shadows: true },
    palette: { base: '#3c4a3c', mass: '#6c7f63', trim: '#b08b5c', accent: '#8fd9ff', secondary: '#e6c79a', glow: '#ffe9b8' },
    atmosphere: { fog: '#5f6f5c', fogDensity: 0.005, mistColor: '#d8e4c8', mistOpacity: 0.1, motion: 'pages', shafts: 4 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Health: {
    id: 'Health',
    terrain: 'tidal',
    sky: { top: '#9fc4c6', horizon: '#e8f2ea', ground: '#35544e', sun: '#e8fff4', sunDir: [-0.6, 0.5, 0.62], night: false, stars: 0, clouds: 0.45, haze: 0.5 },
    light: { key: '#e8fff4', keyIntensity: 1.95, keyFrom: [-80, 90, 70], fill: '#cfe8e0', fillIntensity: 0.85, ambient: '#3c5a54', ambientIntensity: 0.45, shadows: true },
    palette: { base: '#7a9a92', mass: '#cfe6dc', trim: '#a8c8b8', accent: '#68e7bd', secondary: '#b5f3df', glow: '#d8fff0' },
    atmosphere: { fog: '#a9c6bd', fogDensity: 0.0046, mistColor: '#e4f4ec', mistOpacity: 0.14, motion: 'mist', shafts: 3 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Creator: {
    id: 'Creator',
    terrain: 'void',
    sky: { top: '#05030b', horizon: '#1b0f2a', ground: '#03020a', sun: '#ffd0f0', sunDir: [-0.4, 0.6, 0.7], night: true, stars: 0.7, clouds: 0.04, haze: 0.15 },
    light: { key: '#ffd0f0', keyIntensity: 1.05, keyFrom: [-50, 100, 70], fill: '#4d6fd0', fillIntensity: 0.55, ambient: '#120a1e', ambientIntensity: 0.65, shadows: true },
    palette: { base: '#2a1e38', mass: '#3d2b4c', trim: '#8d6f9c', accent: '#FF4DD8', secondary: '#4D8CFF', glow: '#ffb8ef' },
    atmosphere: { fog: '#0a0613', fogDensity: 0.0064, mistColor: '#7a4f8f', mistOpacity: 0.06, motion: 'fragments', shafts: 0 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Space: {
    id: 'Space',
    terrain: 'shelf',
    sky: { top: '#01030a', horizon: '#0a1030', ground: '#01030a', sun: '#dfe9ff', sunDir: [-0.75, 0.35, -0.5], night: true, stars: 1, clouds: 0, haze: 0.03 },
    light: { key: '#dfe9ff', keyIntensity: 2.5, keyFrom: [-120, 70, -60], fill: '#2a3560', fillIntensity: 0.35, ambient: '#070c1a', ambientIntensity: 0.35, shadows: true },
    palette: { base: '#151a30', mass: '#2a3352', trim: '#6a7ba8', accent: '#7bb8ff', secondary: '#a58bff', glow: '#bfe0ff' },
    atmosphere: { fog: '#040818', fogDensity: 0.0035, mistColor: '#3d4c86', mistOpacity: 0.04, motion: 'starlight', shafts: 0 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Robotics: {
    id: 'Robotics',
    terrain: 'trench',
    sky: { top: '#2b3438', horizon: '#a8865f', ground: '#14181a', sun: '#ffd6a0', sunDir: [0.3, 0.55, 0.78], night: true, stars: 0.15, clouds: 0.3, haze: 0.6 },
    light: { key: '#ffd6a0', keyIntensity: 1.75, keyFrom: [55, 80, -70], fill: '#6f8f96', fillIntensity: 0.55, ambient: '#1c2224', ambientIntensity: 0.5, shadows: true },
    palette: { base: '#262f33', mass: '#3c4a4c', trim: '#a8875f', accent: '#54efc0', secondary: '#ffad53', glow: '#ffca8a' },
    atmosphere: { fog: '#1a2023', fogDensity: 0.0062, mistColor: '#7d7a6c', mistOpacity: 0.12, motion: 'forge', shafts: 4 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
  Community: {
    id: 'Community',
    terrain: 'hill',
    sky: { top: '#6f9cb4', horizon: '#f0cf9f', ground: '#3a2f22', sun: '#ffe0ae', sunDir: [-0.6, 0.42, 0.68], night: false, stars: 0, clouds: 0.5, haze: 0.4 },
    light: { key: '#ffe0ae', keyIntensity: 2.3, keyFrom: [-100, 70, 80], fill: '#cfe0d8', fillIntensity: 0.85, ambient: '#42382c', ambientIntensity: 0.45, shadows: true },
    palette: { base: '#8a6a55', mass: '#c08a68', trim: '#8f7457', accent: '#50ddc5', secondary: '#ffc88a', glow: '#ffd9a0' },
    atmosphere: { fog: '#8f7a5e', fogDensity: 0.0044, mistColor: '#e8d3ae', mistOpacity: 0.1, motion: 'lanterns', shafts: 2 },
    fabric: { density: 1, height: 1, spread: 1 },
  },
}

export const worldOf = (city: ProjectCategory | CityId | null | undefined): WorldProfile =>
  WORLDS[city && city in WORLDS ? (city as CityId) : 'AI']
