import { Vector3 } from 'three'
import { CITIES, CITY_CATEGORIES, type CityId } from './cityRegistry'

export const ORBIT_POSITION = [0, 19, 112] as const
export const ORBIT_TARGET = [0, 0, 0] as const
export const FLIGHT_SECONDS = { introduction: 5.2, departing: 1.9, crossing: .35, arriving: 3.8 }
export const smoother = (value: number) => {
  const t = Math.max(0, Math.min(1, value))
  return t * t * t * (t * (t * 6 - 15) + 10)
}

/** Front-facing atlas locations. These are designed landmarks, not user activity. */
export function districtAnchor(city: CityId, radius = 31.5): Vector3 {
  const index = CITY_CATEGORIES.indexOf(city)
  const longitude = (-64 + (index % 4) * 39) * Math.PI / 180
  const latitude = (41 - Math.floor(index / 4) * 34) * Math.PI / 180
  return new Vector3(Math.sin(longitude) * Math.cos(latitude), Math.sin(latitude), Math.cos(longitude) * Math.cos(latitude)).multiplyScalar(radius).add(new Vector3(12, 0, 0))
}

export function landingPose(city: CityId | null) {
  return {
    position: city ? new Vector3(...CITIES[city].overview) : new Vector3(...ORBIT_POSITION),
    target: city ? new Vector3(0, 8, 0) : new Vector3(...ORBIT_TARGET),
  }
}

/** Smoothstep path sampling has zero velocity at both ends, including camera handoff. */
export function flightProgress(elapsed: number, duration: number, reduced: boolean) {
  return smoother(elapsed / (reduced ? .18 : duration))
}
