// MegaTitles — planet-scale extruded 3D wordmarks. Every district carries a floating
// hologram sign over its skyline, the orbital atlas carries a REBOOT arch, and the
// personal city greets its pilot by name. Glyph geometry is generated once from the
// bundled MIT typeface (public/fonts, see LICENSE); materials feed the HDR bloom path.
import { Suspense, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Sparkles, Text, Text3D } from '@react-three/drei'
import * as THREE from 'three'
import { CITIES, type CityId } from '../cityRegistry'
import { useEnvironment } from './ScenePrimitives'

const TYPEFACE = '/fonts/helvetiker_bold.typeface.json'

/** Approximate helvetiker-bold advance widths (fraction of cap height) for manual tracking. */
const LETTER_WIDTH: Record<string, number> = {
  A: .72, B: .70, C: .74, D: .72, E: .64, F: .60, G: .76, H: .74, I: .32, J: .56,
  K: .72, L: .60, M: .86, N: .74, O: .78, P: .68, Q: .78, R: .72, S: .66, T: .64,
  U: .72, V: .70, W: .96, X: .70, Y: .66, Z: .64, ' ': .3,
}

interface LetterLayout { ch: string; left: number; width: number }

function wordLayout(word: string, size: number): { letters: LetterLayout[]; total: number } {
  const track = size * .14
  let cursor = 0
  const letters = word.split('').map(ch => {
    const width = (LETTER_WIDTH[ch] ?? .7) * size
    const letter = { ch, left: cursor, width }
    cursor += width + track
    return letter
  })
  return { letters, total: Math.max(cursor - track, 1) }
}

/** One floating wordmark: per-glyph extruded meshes on a shallow concave arc facing the viewer. */
export function MegaLetters({ word, size, accent, arc = 160, lowEffects = false, reduced = false }: {
  word: string
  size: number
  accent: string
  arc?: number
  lowEffects?: boolean
  reduced?: boolean
}) {
  const group = useRef<THREE.Group>(null)
  const layout = useMemo(() => wordLayout(word, size), [word, size])
  useFrame((state) => {
    if (reduced || !group.current) return
    const t = state.clock.elapsedTime
    group.current.children.forEach((child, i) => {
      if (!child.userData.letter) return
      child.position.y = Math.sin(t * .55 + i * .8) * .5
      child.rotation.z = Math.sin(t * .4 + i) * .014
    })
  })
  return <group ref={group}>
    {layout.letters.map((letter, i) => {
      if (letter.ch === ' ') return null
      const a = letter.left / arc
      return <group key={i} userData={{ letter: true }}
        position={[Math.sin(a) * arc, 0, arc - Math.cos(a) * arc]} rotation={[0, -a, 0]}>
        <Suspense fallback={null}>
          <Text3D font={TYPEFACE} size={size} height={size * .3} curveSegments={lowEffects ? 3 : 5}
            bevelEnabled bevelThickness={size * .035} bevelSize={size * .028} bevelSegments={lowEffects ? 1 : 3}>
            {letter.ch}
            {/* Darker base + gentler emissive: pale silver at 1.45 blew out to white in bright-fog districts. */}
            <meshStandardMaterial color="#8ea6b4" metalness={.86} roughness={.3} emissive={accent} emissiveIntensity={.9} />
          </Text3D>
        </Suspense>
      </group>
    })}
  </group>
}

function TitleHalo({ width, accent }: { width: number; accent: string }) {
  const { lowEffects } = useEnvironment()
  return <group position={[width / 2, -6.5, 3.5]}>
    <mesh rotation={[-Math.PI / 2, 0, 0]}>
      <torusGeometry args={[width / 2 + 5, .15, 6, lowEffects ? 60 : 150]} />
      <meshBasicMaterial color={accent} transparent opacity={.5} blending={THREE.AdditiveBlending} depthWrite={false} />
    </mesh>
    <mesh position={[0, -.7, 0]}>
      <boxGeometry args={[width * 1.02, .24, 1.2]} />
      <meshStandardMaterial color="#0d1b24" emissive={accent} emissiveIntensity={2.6} metalness={.6} roughness={.4} toneMapped={false} />
    </mesh>
  </group>
}

/** The district monument: word + halo + sparkle veil, floating above the skyline. */
export function DistrictMegaTitle({ city }: { city: CityId }) {
  const { lowEffects, reduced } = useEnvironment()
  const palette = CITIES[city].palette
  const word = useMemo(() => CITIES[city].name.replace(/\s*(City|Hub)$/i, '').toUpperCase(), [city])
  const layout = useMemo(() => wordLayout(word, megaSize(word.length)), [word])
  return <group name={`${city}-mega-title`} position={[-layout.total / 2, 56, -62]}>
    <MegaLetters word={word} size={megaSize(word.length)} accent={palette.accent} lowEffects={lowEffects} reduced={reduced} />
    <TitleHalo width={layout.total} accent={palette.accent} />
    {!lowEffects && !reduced && <Sparkles count={110} position={[layout.total / 2, megaSize(word.length), 4]}
      scale={[layout.total * 1.2, 14, 26]} size={megaSize(word.length) * .09} speed={.32} color={palette.accent} opacity={.8} />}
  </group>
}

function megaSize(len: number) { return len <= 2 ? 14 : len <= 4 ? 15 : len <= 6 ? 12 : 9.6 }

/** Planet-scale REBOOT arch for the orbital atlas (hub and the public gate preview).
 * Sized for the hub camera at [0,26,124] fov 50: at z=52 the frame is ~67 units tall,
 * so a size-13 arch clipped off-screen; 8 keeps the full word plus halo inside. */
export function OrbitalRebootTitle({ reduced, lowEffects }: { reduced: boolean; lowEffects: boolean }) {
  const size = 8
  const layout = useMemo(() => wordLayout('REBOOT', size), [])
  return <group name="orbital-reboot-arch" position={[12 - layout.total / 2, 24, 52]}>
    <MegaLetters word="REBOOT" size={size} accent="#f2c17d" arc={1e6} lowEffects={lowEffects} reduced={reduced} />
    <TitleHaloStatic width={layout.total} accent="#e7bb7b" low={lowEffects} />
    <Suspense fallback={null}>
      <Text font="/fonts/Orbitron-Bold.ttf" position={[layout.total / 2, -11, 4]} fontSize={1.2} color="#bfe7f2"
        anchorX="center" outlineWidth={.02} outlineColor="#122332" letterSpacing={.3}>SECOND DAWN · ORBITAL ATLAS</Text>
    </Suspense>
    {!lowEffects && !reduced && <Sparkles count={80} position={[layout.total / 2, -4, 0]} scale={[layout.total * 1.5, 12, 18]} size={.9} speed={.25} color="#ffe1a8" opacity={.7} />}
  </group>
}

function TitleHaloStatic({ width, accent, low }: { width: number; accent: string; low: boolean }) {
  return <group position={[width / 2, -6, 3]}>
    <mesh rotation={[-Math.PI / 2, 0, 0]}>
      <torusGeometry args={[width / 2 + 4, .14, 6, low ? 60 : 150]} />
      <meshBasicMaterial color={accent} transparent opacity={.55} blending={THREE.AdditiveBlending} depthWrite={false} />
    </mesh>
  </group>
}

/** Personal city greeting: the pilot's own name under the MY CITY monument. */
export function PersonalMegaTitle({ pilot }: { pilot: string | null }) {
  const { lowEffects, reduced } = useEnvironment()
  const layout = useMemo(() => wordLayout('MY CITY', 12), [])
  const name = (pilot ?? '').trim().toUpperCase().slice(0, 24)
  return <group name="personal-mega-title" position={[-layout.total / 2, 30, -30]}>
    <MegaLetters word="MY CITY" size={12} accent="#3dd8ff" lowEffects={lowEffects} reduced={reduced} />
    <TitleHalo width={layout.total} accent="#3dd8ff" />
    <Suspense fallback={null}>
      <Text font="/fonts/Inter-Medium.ttf" position={[layout.total / 2, -14, 4]} fontSize={2.2} color="#9ed4df"
        anchorX="center" letterSpacing={.3}>{name ? `WELCOME, ${name}` : 'CLAIM THIS CITY'}</Text>
    </Suspense>
  </group>
}
