import { Architecture } from '@/planet/modules/cityworld/environment/ScenePrimitives'
import type { CityId } from '@/planet/modules/cityworld/cityRegistry'
import type { WorldProfile } from '../types'
import { hash, mixHex, shade, TAU } from './math'

/* Every district keeps a level, walkable civic deck near the origin so walking
 * mode, project selection and camera viewpoints keep working. A place's identity
 * is carried by what surrounds and rises above that deck: cliff faces, trenches,
 * terraces, floating strata, crater rims, shelves and groves. */

const DECK = 52

function civicDeck(a: Architecture, p: WorldProfile, radius = DECK) {
  const c = p.palette
  a.add('pillar', [0, -1.4, 0], [radius, 2.8, radius], c.base, undefined, false, 'stone')
  a.add('pillar', [0, -3.6, 0], [radius + 3, 3, radius + 3], shade(c.base, -0.22), undefined, false, 'stone')
  a.ring([0, 0.02, 0], radius - 0.6, c.accent, undefined, false)
  a.ring([0, 0.03, 0], radius - 7, mixHex(c.accent, c.base, 0.6), undefined, false)
}

function rim(a: Architecture, p: WorldProfile, radius: number, low: number, high: number, tint: string) {
  const c = p.palette
  const count = 32
  for (let i = 0; i < count; i++) {
    const r = hash(i, 3)
    const angle = (i / count) * TAU + hash(i, 7) * 0.08
    const dist = radius + hash(i, 11) * 16
    const h = low + r * (high - low)
    const x = Math.cos(angle) * dist
    const z = Math.sin(angle) * dist
    a.add(
      'rock',
      [x, h * 0.42 - 2, z],
      [7 + r * 9, h, 6 + r * 8],
      mixHex(c.base, tint, 0.2 + hash(i, 13) * 0.5),
      [hash(i, 17) * 0.18, angle, (hash(i, 19) - 0.5) * 0.2],
      false,
      'stone',
    )
  }
}

export function buildTerrain(_city: CityId, p: WorldProfile): Architecture {
  const a = new Architecture()
  const c = p.palette

  switch (p.terrain) {
    case 'crater': {
      // A civic shelf inside a dead sea basin: broken terraces fall away from the
      // plaza into black water, and a shattered rim fills the horizon.
      civicDeck(a, p)
      rim(a, p, DECK + 46, 12, 32, '#6a6470')
      for (let ring = 0; ring < 4; ring++) {
        const radius = DECK + 42 + ring * 14
        const y = -4 - ring * 5
        const segments = 24 - ring * 3
        for (let i = 0; i < segments; i++) {
          if (hash(ring, i, 31) < 0.2 + ring * 0.07) continue
          const t = (i / segments) * TAU
          const w = ((TAU * radius) / segments) * 1.12
          a.box(
            [Math.cos(t) * radius, y, Math.sin(t) * radius],
            [w, 3.4 + ring * 1.2, w * 0.62],
            shade(c.base, -0.14 - ring * 0.06),
            [0, -t, 0],
            false,
            'stone',
          )
        }
      }
      a.add('pillar', [0, -19, 0], [DECK + 40, 1.4, DECK + 40], '#060a12')
      // Collapsed roadway leaving the plaza, and a leaning archive tower.
      for (let i = 0; i < 7; i++) {
        a.box([0, -0.35 - i * 0.42, 50 + i * 7], [5.4, 0.9, 6.4], shade(c.base, -0.18), [0.03 * i, 0.02 * i, 0], false, 'stone')
      }
      a.add('pillar', [-38, 7, -34], [2.6, 28, 2.6], mixHex(c.base, '#9a93a0', 0.45), [0.07, 0, 0.11], false, 'stone')
      a.add('cone', [-38, 22, -34], [3.4, 8, 3.4], mixHex(c.base, '#8d8492', 0.5), [0.06, 0, 0.1], false, 'stone')
      break
    }
    case 'canyon': {
      // Two construction shelves across an unjoined canyon, crane rails overhead.
      civicDeck(a, p)
      for (const side of [-1, 1]) {
        for (let i = 0; i < 12; i++) {
          const z = -50 + i * 9
          const h = 16 + hash(i, side, 5) * 26
          a.box([side * (DECK + 26), h * 0.5 - 2, z], [34, h, 26], shade(c.base, -0.04 - hash(i, 3, side) * 0.12), [0, 0, side * 0.02], false, 'stone')
          a.box([side * (DECK + 8), h * 0.34 - 2, z], [6, h * 0.6, 24], shade(c.base, -0.3), [0, 0, -side * 0.06], false, 'stone')
        }
        a.box([side * (DECK + 34), -30, 0], [46, 32, 124], shade(c.base, -0.42), undefined, false, 'stone')
        a.beam([side * (DECK + 10), 34, -60], [side * (DECK + 10), 26, 30], 0.7, c.trim, false, 'metal')
      }
      a.box([0, -34, 0], [130, 3, 124], shade(c.base, -0.5))
      // The bridge that never closed: two cantilevered halves.
      for (const side of [-1, 1]) {
        for (let i = 0; i < 5; i++) {
          const x = side * (DECK - 2 - i * 4)
          a.box([x, 12 + i * 0.7, -18], [4.4, 0.7, 9], shade(c.trim, -i * 0.04), [0, 0, side * 0.03], false, 'metal')
          a.beam([x, 0, -18], [x, 12 + i * 0.7, -18], 0.35, c.trim, false, 'metal')
        }
      }
      break
    }
    case 'cliff': {
      // A ceremonial plateau above a cloud sea.
      civicDeck(a, p, DECK + 4)
      for (let i = 0; i < 24; i++) {
        const t = (i / 24) * TAU
        const r = DECK + 9 + hash(i, 2) * 3
        a.box([Math.cos(t) * r, -10, Math.sin(t) * r], [17, 20, 9], shade(c.base, -0.16 - hash(i, 5) * 0.1), [0, -t, 0.02], false, 'stone')
      }
      a.add('pillar', [0, -30, 0], [DECK + 26, 38, DECK + 26], shade(c.base, -0.58), undefined, false, 'stone')
      for (let i = 0; i < 6; i++) {
        a.box([0, -1.1, 22 + i * 26], [15, 1.2, 24], shade(c.base, -0.02), undefined, false, 'ceramic')
      }
      break
    }
    case 'plate': {
      // A computation plate over the void, with parallel strata above and below.
      for (let i = 0; i < 7; i++) {
        const angle = (i / 7) * TAU
        for (let r = 0; r < DECK; r += 13) {
          const x = Math.cos(angle) * (r + 8)
          const z = Math.sin(angle) * (r + 8)
          a.add('hex', [x, -1.2, z], [7.2, 2.4, 7.2], i % 2 ? mixHex(c.base, c.mass, 0.45) : c.base, undefined, false, 'metal')
        }
      }
      a.add('hex', [0, -1.3, 0], [DECK * 0.7, 2.6, DECK * 0.7], c.base, undefined, false, 'metal')
      a.ring([0, 0.05, 0], DECK * 0.58, c.accent, undefined, false)
      a.add('hex', [0, -26, 0], [DECK * 0.72, 1.6, DECK * 0.72], shade(c.base, -0.25), [0, 0.4, 0], false, 'metal')
      a.ring([0, -25, 0], DECK * 0.6, mixHex(c.accent, c.base, 0.55), undefined, false)
      a.add('hex', [6, 30, -10], [DECK * 0.42, 1.4, DECK * 0.42], shade(c.base, -0.12), [0.05, 0.7, 0.04], false, 'metal')
      break
    }
    case 'cascade': {
      // Stacked playfield cliffs with a descending run of platforms.
      civicDeck(a, p, DECK - 4)
      const cliffs: [number, number, number, number][] = [
        [-62, -40, 24, 46],
        [66, -28, 34, 40],
        [-12, -74, 18, 60],
        [58, 44, 22, 34],
      ]
      for (const [x, z, h, w] of cliffs) {
        a.box([x, h * 0.5 - 2, z], [w, h, w * 0.8], shade(c.base, -0.06), [0, 0.1, 0], false, 'stone')
        for (let i = 0; i < 3; i++) a.box([x, h + i * 1.5, z], [w - i * 6, 1.4, w * 0.8 - i * 6], shade(c.base, 0.05 * i), undefined, false, 'metal')
      }
      for (let i = 0; i < 10; i++) {
        const t = (i / 10) * TAU
        const x = Math.cos(t) * (DECK + 12)
        const z = Math.sin(t) * (DECK + 12)
        a.box([x, -3 + (i % 4) * 1.7, z], [9, 7 + (i % 3) * 5, 9], shade(c.base, -0.08), [0, hash(i, 2) * 0.6, 0], false, 'stone')
      }
      a.box([0, -20, 0], [230, 2, 190], shade(c.base, -0.45))
      break
    }
    case 'grove': {
      // Root plateaus and reading shelves spiralling around a great trunk.
      civicDeck(a, p)
      for (let i = 0; i < 9; i++) {
        const angle = i * 2.1
        const radius = 18 + hash(i, 4) * 26
        a.add('pillar', [Math.cos(angle) * radius, -3, Math.sin(angle) * radius], [6 + hash(i, 8) * 5, 6, 5 + hash(i, 9) * 4], shade(c.base, -0.22), [0.1, 0, 0.1], false, 'wood')
      }
      for (let i = 0; i < 6; i++) {
        const t = (i / 6) * TAU
        a.add('orb', [Math.cos(t) * (DECK + 16), 2 + hash(i, 2) * 6, Math.sin(t) * (DECK + 16)], [28, 11, 24], mixHex(c.base, c.trim, 0.4), undefined, false, 'foliage')
      }
      for (const [y, radius] of [[17, 30], [25, 22]] as const) {
        for (let i = 0; i < 14; i++) {
          const t = (i / 14) * TAU
          a.box([Math.cos(t) * radius, y, Math.sin(t) * radius], [9, 0.5, 7], shade(c.base, -0.1), [0, -t, 0], false, 'wood')
        }
      }
      break
    }
    case 'tidal': {
      // Healing terraces stepping into shallow water.
      civicDeck(a, p)
      for (let ring = 0; ring < 4; ring++) {
        const radius = DECK + 6 + ring * 11
        a.add('pillar', [0, -2 - ring * 2.2, 0], [radius, 2.4, radius], shade(c.base, -0.05 * ring), undefined, false, 'ceramic')
        a.ring([0, -0.75 - ring * 2.2, 0], radius, mixHex(c.trim, c.base, 0.5), undefined, false)
      }
      a.add('pillar', [0, -16, 0], [DECK + 64, 34, DECK + 64], mixHex(c.base, '#0a2a30', 0.6))
      for (let i = 0; i < 10; i++) {
        const t = (i / 10) * TAU
        const r = DECK + 20 + hash(i, 3) * 12
        a.add('orb', [Math.cos(t) * r, -3, Math.sin(t) * r], [7, 2.4, 6], mixHex(c.base, c.trim, 0.55), undefined, false, 'foliage')
      }
      break
    }
    case 'void': {
      // Gallery strata occupying different planes; nothing reaches the ground.
      a.add('hex', [0, -1.2, 0], [DECK * 0.76, 2.6, DECK * 0.76], c.base, undefined, false, 'ceramic')
      a.ring([0, 0.05, 0], DECK * 0.68, c.accent, undefined, false)
      const strata: [number, number, number, number, number][] = [
        [-46, -14, -18, 34, 0.18],
        [48, -26, 12, 30, -0.12],
        [-28, 20, -44, 40, 0.3],
        [30, 30, 34, 26, -0.2],
      ]
      for (const [x, y, z, w, rot] of strata) {
        a.box([x, y, z], [w, 1.6, w * 0.6], shade(c.base, -0.05), [0, rot, 0.03], false, 'ceramic')
        a.box([x, y - 6, z], [w * 0.5, 10, w * 0.3], shade(c.base, -0.22), [0, rot, 0], false, 'stone')
      }
      break
    }
    case 'shelf': {
      // A crescent asteroid shelf with a hard drop into open space.
      civicDeck(a, p, DECK + 2)
      for (let i = 0; i < 26; i++) {
        const t = (i / 26) * TAU
        const r = DECK + 6 + hash(i, 6) * 26
        const h = 8 + hash(i, 2) * 24
        a.add('rock', [Math.cos(t) * r, h * 0.5 - 8, Math.sin(t) * r], [14 + hash(i, 3) * 16, h, 12 + hash(i, 4) * 14], mixHex(c.base, '#6a6274', hash(i, 8) * 0.6), [hash(i, 9) * 0.3, t, 0], false, 'stone')
      }
      a.add('rock', [0, -52, 0], [DECK + 30, 56, DECK + 10], shade(c.base, -0.4), [0.05, 0, 0], false, 'stone')
      for (let i = 0; i < 5; i++) {
        const t = 0.6 + i * 0.72
        a.add('pillar', [Math.cos(t) * (DECK + 14), 3, Math.sin(t) * (DECK + 14)], [3, 9, 3], c.trim, [0.1, 0, 0.12], false, 'metal')
      }
      break
    }
    case 'trench': {
      // Foundry trench: walkable deck, hard cuts either side, crane rails above.
      civicDeck(a, p)
      for (const side of [-1, 1]) {
        a.box([side * (DECK + 14), -20, 0], [24, 42, 132], shade(c.base, -0.26), undefined, false, 'metal')
        for (let i = 0; i < 14; i++) {
          const z = -58 + i * 9
          a.box([side * (DECK + 7), -6 - hash(i, 2) * 12, z], [13, 15, 7], shade(c.base, -0.1), undefined, false, 'metal')
        }
        a.beam([side * (DECK - 4), 36, -70], [side * (DECK - 4), 36, 70], 0.5, c.trim, false, 'metal')
        for (let i = 0; i < 5; i++) a.beam([side * (DECK - 4), 36, -58 + i * 29], [side * 20, 43, -58 + i * 29], 0.18, c.trim, false, 'metal')
      }
      a.box([0, -32, 0], [DECK * 2, 2, 132], shade(c.base, -0.55))
      break
    }
    case 'hill':
    default: {
      // Hearth terraces climbing away from a central courtyard.
      civicDeck(a, p, DECK - 2)
      for (let ring = 0; ring < 5; ring++) {
        const radius = DECK + 3 + ring * 12
        const y = ring * 4.5
        for (let i = 0; i < 22; i++) {
          const t = (i / 22) * TAU + ring * 0.06
          a.box([Math.cos(t) * radius, y - 1, Math.sin(t) * radius], [15, 4 + ring * 1.8, 10], shade(c.base, -0.05 + ring * 0.02), [0, -t, 0.02], false, 'stone')
        }
        a.ring([0, y + 1.3, 0], radius, mixHex(c.trim, c.base, 0.6), undefined, false)
        for (let i = 0; i < 5; i++) {
          const t = hash(ring, i, 7) * TAU
          a.box([Math.cos(t) * (radius + 4), y + 3, Math.sin(t) * (radius + 4)], [5, 4, 5], c.mass, [0, -t, 0], false, 'stone')
        }
      }
      a.add('pillar', [0, -9, 0], [DECK + 72, 26, DECK + 72], shade(c.base, -0.5))
      break
    }
  }

  // Approach path: every district keeps a clear route in from the entrance.
  if (p.terrain !== 'void') {
    a.box([0, 0.08, 34], [7, 0.16, 46], mixHex(c.base, c.trim, 0.35), undefined, false, 'stone')
    for (const side of [-1, 1]) {
      for (let i = 0; i < 9; i++) {
        a.add('pillar', [side * 5, 1.4, 16 + i * 5], [0.22, 2.8, 0.22], c.trim, undefined, false, 'metal')
        a.add('orb', [side * 5, 3.1, 16 + i * 5], [0.3, 0.4, 0.22], c.glow, undefined, true)
      }
    }
  }
  return a
}
