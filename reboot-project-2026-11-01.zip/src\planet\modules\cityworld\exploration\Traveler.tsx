import { Component, useEffect, useMemo, useRef, type MutableRefObject, type ReactNode } from 'react'
import { useGLTF } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { AnimationMixer, LoopOnce } from 'three'
import { SkeletonUtils } from 'three-stdlib'
export type TravelerAction='Idle'|'Walking_A'|'Running_A'|'Jump_Start'|'Jump_Idle'|'Jump_Land'|'Interact'|'Sit_Chair_Idle'|'Cheer'
export class TravelerBoundary extends Component<{children:ReactNode;fallback:ReactNode},{failed:boolean}> {
 state={failed:false}
 static getDerivedStateFromError(){return {failed:true}}
 render(){return this.state.failed?this.props.fallback:this.props.children}
}
/** Each clone owns its skeleton and mixer; geometry/textures remain shared in the GLTF cache. */
export function Traveler({action,paused=false}: {action:MutableRefObject<TravelerAction>;paused?:boolean}) {
 const gltf=useGLTF('/models/traveler.glb'),model=useMemo(()=>{const clone=SkeletonUtils.clone(gltf.scene);clone.traverse(object=>{if(['Knife','Knife_Offhand','1H_Crossbow','2H_Crossbow','Throwable'].includes(object.name))object.visible=false});return clone},[gltf.scene]),mixer=useMemo(()=>new AnimationMixer(model),[model])
 const actions=useMemo(()=>Object.fromEntries(gltf.animations.map(clip=>[clip.name,mixer.clipAction(clip)])),[gltf.animations,mixer]),current=useRef('')
 useEffect(()=>()=>{mixer.stopAllAction();mixer.uncacheRoot(model)},[mixer,model])
 useFrame((_,delta)=>{
  if(current.current!==action.current){
   actions[current.current]?.fadeOut(.15)
   const next=actions[action.current]??actions.Idle
   next.reset().fadeIn(.15)
   if(['Jump_Start','Jump_Land','Interact','Cheer'].includes(action.current)){next.setLoop(LoopOnce,1);next.clampWhenFinished=true}
   next.play();current.current=action.current
  }
  if(!paused)mixer.update(Math.min(delta,.08))
 })
 return <primitive object={model} scale={1.15} dispose={null}/>
}
