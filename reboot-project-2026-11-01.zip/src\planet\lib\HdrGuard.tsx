// Guards HDR (half-float) EffectComposer buffers: after the chain has rendered a few
// frames, it samples the composer's own scene buffer. Some software drivers (e.g.
// SwiftShader) advertise EXT_color_buffer_float and pass micro-probes yet still produce
// blank output for real scene renders, so the composer must verify the live pipeline and
// let the host fall back to byte buffers. Renders nothing; place inside <EffectComposer>.
import { useContext, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { EffectComposerContext } from '@react-three/postprocessing'
import { HalfFloatType, type WebGLRenderTarget } from 'three'
import { decodeHalf } from './hdrSupport'

type ComposerLike = { inputBuffer: { width: number; height: number; texture: { type: number } } }

export function HdrGuard({ active, onFail }: { active: boolean; onFail: () => void }) {
  const ctx = useContext(EffectComposerContext)
  const gl = useThree(s => s.gl)
  const frames = useRef(0)
  const settled = useRef(false)
  useFrame(() => {
    if (settled.current || !active || !ctx) return
    frames.current++
    // Give the pipeline time to mount, compile and render the first real frames.
    if (frames.current < 8) return
    settled.current = true
    try {
      const rt = (ctx.composer as unknown as ComposerLike).inputBuffer
      if (!rt) { onFail(); return }
      const half = rt.texture.type === HalfFloatType
      const buf: Uint8Array | Uint16Array = half ? new Uint16Array(4 * 4) : new Uint8Array(4 * 4)
      // The composer owns a real WebGLRenderTarget; the structural ComposerLike view above
      // only describes the fields the guard reads.
      gl.readRenderTargetPixels(rt as unknown as WebGLRenderTarget, (rt.width >> 1) - 1, (rt.height >> 1) - 1, 2, 2, buf as never)
      const values = Array.from(buf, v => (half ? decodeHalf(v) : v / 255))
      const rgb = values[0] + values[1] + values[2]
      // District skies always cover the viewport center with a non-black, opaque
      // pixel. A half-float buffer reading pure black therefore proves the HDR
      // path silently dropped the scene render (byte buffers may legitimately
      // read very dark values, so they never trip the guard).
      const failed = !Number.isFinite(rgb) || (half && rgb < 0.01)
      if (failed) onFail()
    } catch {
      onFail()
    }
  }, 2)
  return null
}
