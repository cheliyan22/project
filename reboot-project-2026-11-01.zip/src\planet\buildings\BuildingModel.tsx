import { useMemo } from 'react'
import { Architecture, Motion, Parts, useEnvironment, type Vec } from '../modules/cityworld/environment/ScenePrimitives'
import type { Finish } from '../modules/cityworld/environment/SurfaceMaterials'
import {
  getBuildingDefinition,
  normalizeBuildingCustomization,
  type BuildingCustomization,
  type BuildingId,
} from './catalog'
import { NEXUS_ANCHORS, NEXUS_GLASS_PANELS, buildNexusGate } from './NexusGate'

export interface BuildingModelProps {
  definitionId: BuildingId
  customization?: Partial<BuildingCustomization>
  detailed?: boolean
  preview?: boolean
  selected?: boolean
}

type ModelStyle = { exterior: string; lighting: string; finish: Finish }
type Builder = (solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) => void

const FINISH_MAP: Record<BuildingCustomization['finish'], Finish> = {
  metal: 'metal',
  concrete: 'stone',
  obsidian: 'metal',
  wood: 'wood',
  glass: 'ceramic',
}

const BASE_STYLES: Record<BuildingId, ModelStyle> = {
  'starter-shack': { exterior: '#8a684b', lighting: '#ffcf8f', finish: 'wood' },
  brickbox: { exterior: '#a65f4b', lighting: '#ffd9a8', finish: 'stone' },
  'abandoned-shed': { exterior: '#6d746f', lighting: '#e6a56d', finish: 'metal' },
  'modern-cube': { exterior: '#dfe4e0', lighting: '#9fdcea', finish: 'ceramic' },
  'mini-warehouse': { exterior: '#87959d', lighting: '#f2c77d', finish: 'metal' },
  'research-pod': { exterior: '#cfe0de', lighting: '#64e6dc', finish: 'ceramic' },
  'neon-corner': { exterior: '#3a3c52', lighting: '#ff4fc3', finish: 'stone' },
  'stackhouse-mini': { exterior: '#b99f80', lighting: '#ffd39a', finish: 'wood' },
  'hackers-den-mini': { exterior: '#2a313a', lighting: '#8dff78', finish: 'metal' },
  'concrete-tower': { exterior: '#9aa09c', lighting: '#cfe6e0', finish: 'stone' },
  'reboot-nexus': { exterior: '#20242d', lighting: '#36e4ff', finish: 'metal' },
}

/** Where rooftop accessories (antenna / solar) land, per redesigned silhouette. */
const ROOF_HEIGHT: Record<BuildingId, number> = {
  'starter-shack': 3.45,
  brickbox: 3.85,
  'abandoned-shed': 3.15,
  'modern-cube': 3.9,
  'mini-warehouse': 4.25,
  'research-pod': 4.25,
  'neon-corner': 5.25,
  'stackhouse-mini': 5.55,
  'hackers-den-mini': 2.1,
  'concrete-tower': 6.45,
  'reboot-nexus': 10.28,
}

function block(a: Architecture, p: Vec, s: Vec, color: string, finish: Finish = 'metal', r: Vec = [0, 0, 0]) {
  a.box(p, s, color, r, false, finish)
}

function glow(a: Architecture, p: Vec, s: Vec, color: string, r: Vec = [0, 0, 0]) {
  a.box(p, s, color, r, true)
}

/** Recessed dark window opening with a lit pane set slightly deeper. */
function win(a: Architecture, p: Vec, s: Vec, light: string, frame = '#141a1f', r: Vec = [0, 0, 0]) {
  a.box([p[0], p[1], p[2]], [s[0] + .1, s[1] + .1, s[2] + .02], frame, r, false, 'metal')
  glow(a, [p[0], p[1], p[2] + (r[1] === 0 ? .045 : 0)], s, light, r)
}

/* 1 · STARTER SHACK — steep gable cabin on a stone footing, front porch. */
function buildShack(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .16, 0], [5.1, .32, 4.7], '#4a4640', 'stone')
  block(solid, [0, 1.45, 0], [4.1, 2.3, 3.5], style.exterior, style.finish)
  block(solid, [0, 2.72, 0], [2.1, .5, 3.52], style.exterior, style.finish)
  // crossed roof panels meeting at a ridge
  block(solid, [-1.06, 3.0, 0], [2.8, .16, 4.15], '#4f3a30', 'wood', [0, 0, .62])
  block(solid, [1.06, 3.0, 0], [2.8, .16, 4.15], '#4f3a30', 'wood', [0, 0, -.62])
  block(solid, [0, 3.78, 0], [.34, .2, 4.3], '#3b2c24', 'wood')
  block(solid, [1.35, 3.35, -.95], [.5, 1.9, .5], '#5b554e', 'stone')
  block(solid, [1.35, 4.34, -.95], [.66, .12, .66], '#453f3a', 'stone')
  // porch deck, canopy, posts
  block(solid, [0, .42, 2.4], [3.5, .16, 1.2], '#6b543f', 'wood')
  block(solid, [0, 2.52, 2.45], [3.6, .12, 1.35], '#4f3a30', 'wood', [-.1, 0, 0])
  solid.beam([-1.55, .5, 2.92], [-1.55, 2.46, 2.86], .12, '#5d4437', false, 'wood')
  solid.beam([1.55, .5, 2.92], [1.55, 2.46, 2.86], .12, '#5d4437', false, 'wood')
  block(solid, [-.95, 1.32, 1.78], [.9, 1.9, .12], '#33271f', 'wood')
  glow(solid, [-.95, 1.4, 1.86], [.62, 1.45, .04], style.lighting)
  win(solid, [.85, 1.72, 1.78], [.85, .7, .05], style.lighting)
  if (detailed) {
    for (let y = .62; y < 2.55; y += .38) block(detail, [0, y, 1.77], [4.05, .05, .05], '#5d4437', 'wood')
    block(detail, [2.07, 1.72, 0], [.06, .8, 1.1], '#141a1f', 'wood')
    glow(detail, [2.03, 1.72, 0], [.04, .62, .8], style.lighting, [0, Math.PI / 2, 0])
    for (const x of [-1.35, -1.05, -.75, -.45]) block(detail, [x, .78, 3.02], [.06, .5, .06], '#57463a', 'wood')
    block(detail, [0, 1.06, 3.02], [3.3, .07, .07], '#57463a', 'wood')
    detail.add('orb', [1.55, 2.24, 2.9], [.13, .16, .13], '#ffdf9e', [0, 0, 0], true)
    for (const [x, z] of [[-2.3, 1.4], [-2.3, .9], [-2.3, .4]]) detail.add('rock', [x, .55 + (z === .9 ? .18 : 0), z], [.34, .5, .34], '#6a5340', [x, z, 0], false, 'wood')
    block(detail, [-2.05, .32, 2.4], [1.0, .14, .55], '#625044', 'wood')
  }
}

/* 2 · BRICKBOX — two-storey stepped townhouse, hip roof, recessed porch. */
function buildBrickbox(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .18, 0], [5.2, .36, 4.9], '#5c554e', 'stone')
  block(solid, [-.2, 1.85, 0], [4.5, 3.3, 3.9], style.exterior, style.finish)
  block(solid, [.85, 4.4, -.15], [2.6, 1.8, 3.2], style.exterior, style.finish)
  block(solid, [-.2, 3.62, 0], [4.85, .22, 4.25], '#4e5450', 'stone')
  block(solid, [.85, 5.42, -.15], [2.95, .18, 3.55], '#4e5450', 'stone')
  solid.add('rock', [.85, 5.95, -.15], [1.85, .75, 2.15], '#3f4a52', [0, .4, 0], false, 'metal')
  // corner pilasters + string course
  for (const x of [-2.32, 1.92]) block(solid, [x, 1.85, 1.92], [.3, 3.35, .3], '#c4b49a', 'stone')
  block(solid, [-.2, 2.28, 0], [4.62, .14, 4.02], '#8f8577', 'stone')
  // recessed entrance with canopy on posts
  block(solid, [-1.5, 1.42, 1.94], [1.15, 2.45, .18], '#2c3136', 'metal')
  glow(solid, [-1.5, 1.5, 2.05], [.78, 1.75, .04], style.lighting)
  block(solid, [-1.5, 2.78, 2.28], [1.6, .14, .72], '#59605c', 'stone')
  solid.beam([-2.12, 2.72, 2.55], [-2.12, .38, 2.55], .08, '#6f675d', false, 'metal')
  // first-floor windows + upper storey windows
  win(solid, [.6, 1.5, 1.96], [.8, .95, .05], style.lighting)
  win(solid, [1.85, 1.5, 1.96], [.55, .95, .05], style.lighting)
  win(solid, [.3, 4.42, 1.46], [.7, .8, .05], style.lighting)
  win(solid, [1.5, 4.42, 1.46], [.7, .8, .05], style.lighting)
  // rooftop tank on legs
  solid.add('pillar', [-1.5, 4.28, -1.25], [.42, .8, .42], '#6e7570', [0, 0, 0], false, 'metal')
  block(solid, [-1.5, 4.76, -1.25], [.56, .12, .56], '#4e5450', 'metal')
  if (detailed) {
    for (let row = 0; row < 6; row++) block(detail, [-.2, .68 + row * .52, 1.97], [4.45, .045, .04], '#8a4f3f', 'stone')
    for (const x of [-2.32, 1.92]) for (let row = 0; row < 3; row++) block(detail, [x, .9 + row * 1.1, 2.09], [.3, .1, .05], '#d0c2a6', 'stone')
    block(detail, [-.2, 3.86, 1.9], [1.3, .3, .5], '#717673', 'metal')
    for (const z of [-1.25, -1.75]) solid.beam([-1.5 + (z < -1.5 ? .3 : -.3), 3.86, z], [-1.5, 3.98, z], .07, '#5d6660', false, 'metal')
    detail.add('rock', [-2.5, .55, .6], [.4, .5, .4], '#55604f', [1, 2, 0], false, 'foliage')
    block(detail, [0, .34, 2.6], [2.4, .2, .7], '#776f66', 'stone')
  }
}

/* 3 · ABANDONED SHED — half-round barrel vault with ribs, lean-to, rubble. */
function buildShed(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .12, 0], [5, .24, 4.7], '#4b4f4b', 'stone')
  solid.add('pillar', [0, 1.15, 0], [2.15, 4.3, 2.15], style.exterior, [Math.PI / 2, 0, 0], false, style.finish)
  for (const z of [-1.45, -.35, .75, 1.75]) solid.add('pillar', [0, 1.15, z], [2.28, .16, 2.28], '#5a5f5a', [Math.PI / 2, 0, 0], false, 'metal')
  // front end wall with sliding door and one dim window
  block(solid, [0, 1.28, 2.06], [2.6, 2.35, .14], '#3a3f3e', 'metal')
  block(solid, [-.55, 1.12, 2.16], [1.15, 1.9, .06], '#2c3231', 'metal')
  glow(solid, [.75, 1.55, 2.16], [.5, .5, .04], style.lighting)
  // patched replacement panel on the crown
  block(solid, [.85, 2.95, .35], [1.7, .08, 2.3], '#6d5747', 'metal', [.06, .12, -.32])
  // lean-to on the west side
  block(solid, [-2.15, 1.05, .35], [1.0, 1.5, 3.1], '#545a57', 'metal', [0, 0, .2])
  solid.beam([-2.62, .25, 1.85], [-2.62, 1.6, 1.85], .1, '#4e5350', false, 'metal')
  solid.beam([-2.62, .25, -1.1], [-2.62, 1.9, -1.1], .1, '#4e5350', false, 'metal')
  // rusted tank and pipe
  solid.add('pillar', [2.2, .78, -1.55], [.5, 1.2, .5], '#6e5847', [0, 0, 0], false, 'metal')
  solid.beam([2.2, 1.4, -1.55], [.6, 2.3, -1.55], .12, '#5d5347', false, 'metal')
  if (detailed) {
    for (const x of [-.9, -.1, .7, 1.4]) block(detail, [x, 1.0, 2.2], [.16, 1.6, .05], '#7a6a52', 'wood', [0, 0, x > 0 ? .1 : -.08])
    detail.add('rock', [-1.7, .35, 2.5], [.5, .45, .5], '#585e58', [1, .6, 0], false, 'stone')
    detail.add('rock', [-.7, .3, 2.85], [.42, .35, .42], '#4f544f', [2, .2, 1], false, 'stone')
    block(detail, [1.6, .35, 2.6], [.9, .55, .7], '#575d58', 'metal', [0, .4, .06])
    glow(detail, [0, 2.9, -2.18], [.6, .12, .05], '#8a6d4d')
  }
}

/* 4 · MODERN CUBE — cantilevered pavilion: open colonnade below, floating glass volume above. */
function buildModernCube(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .1, 0], [5.3, .2, 5.2], '#8d958f', 'stone')
  block(solid, [0, .32, .05], [4.85, .24, 4.7], '#b8bdb4', 'stone')
  for (const x of [-2.05, 2.05]) for (const z of [-1.95, 1.95]) solid.beam([x, .44, z], [x, 3.62, z], .14, '#7f8a86', false, 'metal')
  // floating living volume, cantilevered toward the entrance
  block(solid, [.3, 2.55, 0], [4.0, 1.95, 3.4], '#23333a', 'metal')
  glow(solid, [.3, 2.62, 1.72], [3.3, 1.3, .05], style.lighting)
  glow(solid, [2.32, 2.62, 0], [.05, 1.3, 2.5], style.lighting)
  // opaque service core
  block(solid, [1.85, 2.4, -1.15], [1.4, 2.25, 1.5], style.exterior, style.finish)
  for (const z of [-1.55, -1.15, -.75]) block(solid, [2.6, 2.4, z], [.06, 2.1, .16], '#9aa49e', 'ceramic')
  // thin roof plate with warm soffit line
  block(solid, [.2, 3.78, 0], [5.15, .18, 4.55], '#eef0e9', 'ceramic')
  glow(solid, [.2, 3.62, 0], [4.7, .05, 4.1], '#ffe9c0')
  // ground-level entry: recessed glass wall, door, steps
  block(solid, [-1.35, 1.32, 1.8], [1.7, 1.75, .1], '#1d2a30', 'metal')
  glow(solid, [-1.35, 1.32, 1.87], [1.3, 1.4, .04], style.lighting)
  block(solid, [-1.35, .46, 2.62], [2.3, .18, .95], '#c4cac5', 'stone')
  if (detailed) {
    for (const x of [-.85, .3, 1.45]) block(detail, [x, 2.55, 1.74], [.06, 1.85, .06], '#4d666f', 'metal')
    for (const x of [-1.9, -.8, .3, 1.4]) block(detail, [x, 1.15, 2.06], [.05, 1.4, .05], '#93a6ad', 'metal')
    block(detail, [-2.28, 1.5, 0], [.05, .9, 2.6], '#4d666f', 'metal')
    detail.add('rock', [2.3, .75, 1.9], [.4, .55, .4], '#4d8e5f', [1, 1, 0], false, 'foliage')
    detail.add('rock', [1.55, .68, 2.15], [.3, .4, .3], '#5ba06d', [2, .4, 1], false, 'foliage')
  }
}

/* 5 · MINI WAREHOUSE — sawtooth factory roof with glazed risers plus twin silos and a catwalk. */
function buildWarehouse(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .2, 0], [5.7, .4, 5], '#565d5f', 'stone')
  block(solid, [-.3, 1.75, 0], [4.6, 2.9, 4.2], style.exterior, style.finish)
  for (let i = 0; i < 3; i++) {
    const x = -1.95 + i * 1.55
    block(solid, [x + .58, 3.5, 0], [2.05, .12, 4.3], '#46545c', 'metal', [0, 0, -.52])
    block(solid, [x - .32, 3.78, 0], [.16, 1.0, 4.05], '#2c3a44', 'metal')
    glow(solid, [x - .24, 3.82, 0], [.05, .78, 3.7], style.lighting)
  }
  // twin silos on pads
  for (const [z, r, h] of [[-1.4, .78, 3.6], [.9, .62, 3.0]] as const) {
    block(solid, [2.35, .42, z], [1.15, .22, 1.15], '#4d5456', 'stone')
    solid.add('pillar', [2.35, .55 + h / 2, z], [r, h, r], '#7b868b', [0, 0, 0], false, 'metal')
    solid.add('cone', [2.35, .55 + h + r * .45, z], [r + .06, r * .9, r + .06], '#5d686e', [0, .5, 0], false, 'metal')
    for (const y of [1.5, 2.7]) if (y < h) solid.add('pillar', [2.35, .55 + y, z], [r + .05, .1, r + .05], '#59636a', [0, 0, 0], false, 'metal')
  }
  // catwalk from silo tops onto the roof
  block(solid, [1.35, 3.35, -.25], [1.9, .12, .8], '#5d6a70', 'metal')
  solid.beam([2.35, 3.5, -1.4], [1.6, 3.45, -.6], .07, '#6e7b81', false, 'metal')
  solid.beam([2.35, 2.9, .9], [1.6, 3.42, .3], .07, '#6e7b81', false, 'metal')
  // loading bay: recess, ramp, canopy, lamps
  block(solid, [-.6, 1.35, 2.08], [2.3, 2.3, .14], '#2c363b', 'metal')
  block(solid, [-.6, .55, 2.6], [2.4, .5, .95], '#6a716f', 'stone')
  block(solid, [-.6, 2.72, 2.55], [2.9, .14, .95], '#4d5b62', 'metal', [-.12, 0, 0])
  if (detailed) {
    glow(detail, [-2.35, 2.35, 2.2], [.14, .3, .1], '#f5b94e')
    glow(detail, [1.15, 2.35, 2.2], [.14, .3, .1], '#f5b94e')
    for (let x = -2.5; x <= 1.9; x += .42) block(detail, [x, 1.3, 2.12], [.05, 2.6, .05], '#75838a', 'metal')
    glow(detail, [-.6, 2.5, 2.16], [1.6, .12, .05], style.lighting)
    for (const z of [-1.4, .9]) block(detail, [2.35, 1.0, z + .85], [.3, .1, .3], '#59636a', 'metal')
    detail.add('rock', [-2.55, .5, 1.6], [.45, .6, .45], '#5c676c', [1, .7, 0], false, 'stone')
  }
}

/* 6 · RESEARCH POD — twin hexagonal pods on legs, joined by a glazed sky bridge. */
function buildResearchPod(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [-1.35, .16, .3], [2.3, .32, 2.3], '#4e5c60', 'stone')
  block(solid, [1.55, .16, -.7], [1.8, .32, 1.8], '#4e5c60', 'stone')
  for (const [px, pz, spread] of [[-1.35, .3, 1.05], [1.55, -.7, .8]] as const) {
    for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]] as const) {
      solid.beam([px + dx * spread * .72, 2.1, pz + dz * spread * .72], [px + dx * spread * 1.25, .32, pz + dz * spread * 1.25], .11, '#5f7176', false, 'metal')
    }
  }
  // lower pod
  solid.add('hex', [-1.35, 3.05, .3], [1.2, 1.7, 1.2], style.exterior, [0, .35, 0], false, style.finish)
  solid.add('hex', [-1.35, 4.0, .3], [1.3, .2, 1.3], '#70858a', [0, .35, 0], false, 'metal')
  solid.add('cone', [-1.35, 4.62, .3], [1.0, .9, 1.0], '#3f5257', [0, .35, 0], false, 'metal')
  glow(solid, [-1.35, 3.05, 1.46], [1.05, .85, .06], style.lighting)
  // upper pod
  solid.add('hex', [1.55, 3.6, -.7], [.9, 1.4, .9], style.exterior, [0, .1, 0], false, style.finish)
  solid.add('orb', [1.55, 4.5, -.7], [.62, .5, .62], '#8fb0b3', [0, 0, 0], false, 'ceramic')
  solid.beam([1.55, 4.95, -.7], [1.55, 5.9, -.7], .06, '#9fb4b6', false, 'metal')
  glow(solid, [1.55, 5.95, -.7], [.12, .12, .12], style.lighting)
  // sky bridge with lit glazing and a diagonal strut
  block(solid, [.1, 3.35, -.2], [2.5, .55, .95], '#54666b', 'metal', [0, .5, 0])
  glow(solid, [.1, 3.42, -.2], [2.1, .26, .98], style.lighting, [0, .5, 0])
  solid.beam([.1, 2.0, -.2], [.1, 3.1, -.2], .09, '#5f7176', false, 'metal')
  // ground entry stair into the lower pod
  for (let s = 0; s < 4; s++) block(solid, [-1.35, .42 + s * .32, 1.62 - s * .3], [.9, .14, .34], '#5c6d70', 'metal')
  if (detailed) {
    solid.ring([-1.35, 4.22, .3], 1.45, style.lighting, [Math.PI / 2, 0, 0], true)
    for (const side of [-1, 1]) {
      block(detail, [-1.35 + side * 1.32, 2.75, .3], [.5, 1.0, .9], '#64787b', 'metal')
      glow(detail, [-1.35 + side * 1.6, 2.85, .3], [.05, .5, .55], style.lighting)
    }
    detail.add('rock', [2.2, .5, 1.3], [.42, .55, .42], '#4d8e79', [1, .5, 0], false, 'foliage')
    detail.add('rock', [-2.4, .45, -.9], [.36, .45, .36], '#437e6b', [2, .8, 1], false, 'foliage')
  }
}

/* 7 · NEON CORNER — corner block on an arcade colonnade with bay turret and mansard crown. */
function buildNeonCorner(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .14, 0], [5.4, .28, 5.2], '#23263a', 'stone')
  for (const x of [-2.35, -.8, .75, 2.3]) for (const z of [-2.35, 2.3]) solid.add('pillar', [x, 1.18, z], [.18, 2.05, .18], '#3c4054', [0, 0, 0], false, 'stone')
  for (const z of [-.85, .7]) for (const x of [-2.35, 2.3]) solid.add('pillar', [x, 1.18, z], [.18, 2.05, .18], '#3c4054', [0, 0, 0], false, 'stone')
  // mezzanine slab with warm fascia light
  block(solid, [0, 2.34, 0], [5.25, .26, 5.05], '#2c2f45', 'metal')
  glow(solid, [0, 2.22, 2.56], [5.0, .1, .06], '#ffb85f')
  // upper volume pushed to the rear
  block(solid, [-.55, 3.8, -.5], [4.3, 2.65, 3.7], style.exterior, style.finish)
  block(solid, [-.55, 5.2, -.5], [4.75, .24, 4.15], '#453a5c', 'metal')
  solid.add('rock', [-.55, 5.55, -.5], [2.15, .5, 1.9], '#3a3350', [0, .35, 0], false, 'metal')
  // corner turret with beacon band
  solid.add('hex', [1.95, 3.3, 1.95], [.66, 3.6, .66], '#2a2d42', [0, .4, 0], false, style.finish)
  solid.ring([1.95, 4.6, 1.95], .78, '#58d9e8', [Math.PI / 2, 0, 0], true)
  solid.add('cone', [1.95, 5.45, 1.95], [.72, .95, .72], '#573f6e', [0, .4, 0], false, 'metal')
  // shopfront glazing between the columns + marquee over the door
  block(solid, [.7, 1.3, 2.42], [2.7, 1.6, .1], '#151827', 'metal')
  glow(solid, [.7, 1.38, 2.48], [2.35, 1.15, .04], '#ffd9a0')
  block(solid, [-1.55, 1.25, 2.42], [1.1, 1.85, .1], '#151827', 'metal')
  glow(solid, [-1.55, 1.25, 2.48], [.72, 1.45, .04], style.lighting)
  block(solid, [-1.55, 2.3, 2.75], [1.7, .12, .7], '#453a5c', 'metal', [-.14, 0, 0])
  if (detailed) {
    for (const x of [-.2, .8, 1.8]) block(detail, [x, 1.3, 2.53], [.05, 1.3, .04], '#c0f5f3', 'metal')
    glow(detail, [-.55, 5.08, 1.36], [3.4, .06, .05], '#ff65cb')
    block(detail, [2.62, 3.9, -.5], [.06, 1.6, 2.2], '#1d2030', 'metal')
    glow(detail, [2.66, 3.9, -.5], [.04, 1.2, 1.7], '#61ecff')
    for (const x of [-2.35, -.8]) block(detail, [x, .55, 2.42], [.5, .8, .5], '#262a40', 'stone')
  }
}

/* 8 · STACKHOUSE MINI — pinwheel stack of rotated levels with balconies and a roof pergola. */
function buildStackhouse(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .12, 0], [5.2, .24, 4.9], '#4d4741', 'stone')
  const levels = [
    { y: 1.15, h: 1.45, w: 3.9, d: 3.5, rot: 0, color: style.exterior, finish: style.finish },
    { y: 2.55, h: 1.3, w: 3.5, d: 3.1, rot: .42, color: '#7d8b88', finish: 'metal' as Finish },
    { y: 3.8, h: 1.15, w: 3.1, d: 2.8, rot: .85, color: style.exterior, finish: style.finish },
    { y: 4.95, h: .95, w: 2.6, d: 2.4, rot: 1.3, color: '#8a8f94', finish: 'ceramic' as Finish },
  ]
  levels.forEach((L, i) => {
    block(solid, [0, L.y, 0], [L.w, L.h, L.d], L.color, L.finish, [0, L.rot, 0])
    block(solid, [0, L.y - L.h / 2 - .1, 0], [L.w + .5, .2, L.d + .5], '#3f4746', 'metal', [0, L.rot + .2, 0])
    const fx = Math.sin(L.rot) * (L.d / 2 + .04), fz = Math.cos(L.rot) * (L.d / 2 + .04)
    glow(solid, [fx, L.y + .08, fz], [1.15, .5, .06], style.lighting, [0, L.rot, 0])
    if (i % 2 === 1) {
      const bx = Math.sin(L.rot + Math.PI / 2) * (L.w / 2 + .45), bz = Math.cos(L.rot + Math.PI / 2) * (L.w / 2 + .45)
      block(solid, [bx, L.y - L.h / 2 - .22, bz], [1.3, .1, 1.3], '#5a534b', 'wood', [0, L.rot, 0])
    }
  })
  // external zigzag stair up the east face
  for (let s = 0; s < 7; s++) solid.beam([1.6 - s * .07, .3 + s * .66, 1.9 - s * .55], [2.35 - s * .07, .55 + s * .66, 1.55 - s * .55], .1, '#57615f', false, 'metal')
  // pergola crown
  for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]] as const) block(solid, [dx * .95, 5.75, dz * .95], [.1, .65, .1], '#6a706b', 'metal')
  block(solid, [0, 6.12, 0], [2.3, .1, .12], '#6a706b', 'metal')
  block(solid, [0, 6.12, .55], [2.3, .1, .12], '#6a706b', 'metal')
  block(solid, [0, 6.12, -.55], [2.3, .1, .12], '#6a706b', 'metal')
  if (detailed) {
    levels.forEach(L => {
      const sx = Math.sin(L.rot + Math.PI / 2), sz = Math.cos(L.rot + Math.PI / 2)
      block(detail, [sx * (L.w / 2 + .03), L.y, sz * (L.w / 2 + .03)], [.85, .42, .05], '#a9e1df', 'metal', [0, L.rot, 0])
    })
    detail.add('rock', [.5, 5.85, .3], [.35, .4, .35], '#4d8e5f', [1, .4, 0], false, 'foliage')
    detail.add('rock', [-.4, 5.8, -.25], [.3, .34, .3], '#5ba06d', [2, .9, 0], false, 'foliage')
    for (const x of [-1.2, -.4, .4, 1.2]) block(detail, [x, 1.95, 1.85], [.06, .5, .06], '#454e4e', 'metal')
  }
}

/* 9 · HACKERS DEN MINI — buried composite mound, wedge blast entry, antenna field. */
function buildHackersDen(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  solid.add('orb', [0, .45, 0], [2.75, 1.75, 2.55], style.exterior, [0, 0, 0], false, style.finish)
  solid.add('orb', [-.4, .35, .5], [2.2, 1.5, 2.3], '#232a33', [0, .6, 0], false, 'stone')
  // angled concrete entry wedge
  block(solid, [-.5, 1.1, 1.55], [1.5, .42, 2.7], '#454f57', 'stone', [.16, .06, -.05])
  block(solid, [-.5, .6, 2.55], [1.15, 1.2, .55], '#1a2126', 'metal', [.1, 0, 0])
  glow(solid, [-.5, .68, 2.86], [.7, .85, .05], style.lighting)
  block(solid, [-1.35, .5, 2.35], [.2, 1.5, .2], '#4b565e', 'metal', [0, 0, .25])
  // antenna field along the ridge
  for (const [x, h, z] of [[1.1, 3.5, -1.5], [1.85, 2.7, -1.0], [.3, 2.3, -1.9], [-1.5, 2.9, -1.35]] as const) {
    solid.beam([x, 1.2, z], [x + .12, 1.2 + h, z - .1], .06, '#6a747c', false, 'metal')
    glow(solid, [x + .12, 1.25 + h, z - .1], [.11, .11, .11], '#8dff78')
  }
  // dish on a short mast
  solid.beam([1.85, 2.4, -.4], [1.85, 3.0, -.4], .07, '#6a747c', false, 'metal')
  solid.add('pillar', [1.85, 3.15, -.42], [.55, .08, .55], '#8a949c', [.95, .3, 0], false, 'metal')
  // exhaust stacks with red bands
  for (const x of [-2.05, 2.35]) {
    solid.add('pillar', [x, 1.05, .4], [.2, 1.3, .2], '#39434b', [0, 0, 0], false, 'metal')
  }
  if (detailed) {
    for (const x of [-2.05, 2.35]) glow(detail, [x, 1.62, .4], [.24, .08, .24], '#ff5a4d')
    for (const [x, z] of [[-2.2, 1.6], [-2.7, .6], [2.4, 1.5]] as const) block(detail, [x, .2, z], [.7, .34, .5], '#333d45', 'metal', [0, x * .4, 0])
    solid.beam([-2.2, .12, 2.3], [2.3, .12, 2.0], .05, '#3d464e', false, 'metal')
    glow(detail, [-.5, 1.36, 1.28], [.9, .05, .05], style.lighting)
    detail.add('rock', [2.55, .4, -.6], [.4, .45, .4], '#3a444c', [1, .8, 0], false, 'stone')
  }
}

/* 10 · CONCRETE TOWER — stepped ziggurat pierced by a portal void, fin corners, beacon crown. */
function buildConcreteTower(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  block(solid, [0, .2, 0], [5.3, .4, 5.1], '#6e746f', 'stone')
  // tier 1
  block(solid, [0, 1.4, 0], [4.9, 2.3, 4.7], style.exterior, style.finish)
  block(solid, [0, 2.62, 0], [5.15, .18, 4.95], '#767e7b', 'stone')
  // tier 2 split around a through-portal void
  block(solid, [-1.6, 3.75, 0], [1.55, 2.1, 3.9], style.exterior, style.finish)
  block(solid, [1.6, 3.75, 0], [1.55, 2.1, 3.9], style.exterior, style.finish)
  block(solid, [0, 4.62, 0], [4.15, .42, 3.9], style.exterior, style.finish)
  block(solid, [0, 3.75, -1.86], [1.35, 1.7, .18], '#232b2c', 'metal')
  glow(solid, [0, 3.75, -1.78], [1.05, 1.3, .05], '#7fa8ad')
  block(solid, [0, 4.9, 0], [4.35, .16, 4.15], '#656e6c', 'stone')
  // tier 3
  block(solid, [0, 5.65, 0], [3.0, 1.4, 2.85], style.exterior, style.finish)
  block(solid, [0, 6.42, 0], [3.3, .14, 3.15], '#656e6c', 'stone')
  // corner fins full height
  for (const x of [-2.36, 2.36]) for (const z of [-2.28, 2.28]) block(solid, [x, 2.0, z], [.22, 4.4, .22], '#858c87', 'stone')
  // deep window bays on each tier face
  for (const y of [1.1, 1.95]) for (const x of [-1.5, 0, 1.5]) win(solid, [x, y, 2.4], [.62, .5, .05], style.lighting)
  for (const x of [-1.62, 1.62]) win(solid, [x, 3.85, 2.0], [.55, 1.2, .05], style.lighting)
  win(solid, [0, 5.75, 1.48], [1.6, .55, .05], style.lighting)
  // portal entrance with lintel
  block(solid, [0, 1.05, 2.42], [1.0, 1.9, .12], '#3f4b4c', 'metal')
  block(solid, [0, 2.16, 2.5], [1.6, .22, .35], '#858c87', 'stone')
  if (detailed) {
    // crown observation deck + beacon
    for (const [x, z] of [[-1.1, -1], [1.1, -1], [-1.1, 1], [1.1, 1]] as const) block(detail, [x, 6.85, z], [.12, .75, .12], '#7d8581', 'metal')
    block(detail, [0, 7.28, 0], [2.8, .12, 2.4], '#8b928d', 'stone')
    detail.add('orb', [0, 7.62, 0], [.2, .26, .2], style.lighting, [0, 0, 0], true)
    solid.ring([0, 7.36, 0], 1.5, '#9fd8d2', [Math.PI / 2, 0, 0], true)
    for (const y of [1.5, 3.75, 5.65]) for (const x of [-2.42, 2.42]) block(detail, [x, y, 0], [.06, .8, 3.4], '#c0c2b9', 'stone')
    block(detail, [0, .34, 3.0], [2.6, .22, .95], '#888e88', 'stone')
    block(detail, [0, .62, 2.75], [2.0, .16, .5], '#7c827d', 'stone')
  }
}

/* 11 · REBOOT NEXUS — "The Canopied Gate". A complete replacement of the
      previous twin-tower design; the geometry lives in NexusGate.ts. */
function buildNexus(solid: Architecture, detail: Architecture, style: ModelStyle, detailed: boolean) {
  buildNexusGate(solid, detail, style, detailed)
}

const BUILDERS: Record<BuildingId, Builder> = {
  'starter-shack': buildShack,
  brickbox: buildBrickbox,
  'abandoned-shed': buildShed,
  'modern-cube': buildModernCube,
  'mini-warehouse': buildWarehouse,
  'research-pod': buildResearchPod,
  'neon-corner': buildNeonCorner,
  'stackhouse-mini': buildStackhouse,
  'hackers-den-mini': buildHackersDen,
  'concrete-tower': buildConcreteTower,
  'reboot-nexus': buildNexus,
}

function NexusGlass({ lighting }: { lighting: string }) {
  return <group name="nexus-layered-glass">
    {NEXUS_GLASS_PANELS.map((panel, index) => <mesh key={index} position={panel.p} scale={panel.s} renderOrder={2 + index}>
      <boxGeometry />
      <meshPhysicalMaterial color={lighting} transparent opacity={panel.opacity} roughness={.16} metalness={.3} depthWrite={false} />
    </mesh>)}
  </group>
}

function NexusEffects({ lighting, animated, detailed, preview, lowEffects }: {
  lighting: string
  animated: boolean
  detailed: boolean
  preview: boolean
  lowEffects: boolean
}) {
  // One threshold ring and one lamp, both inside the gate void. No free-floating objects.
  return <>
    {animated && <Motion position={[0, 2.4, 3.1]} axis="z" speed={.32}>
      <mesh><torusGeometry args={[1.3, .05, 6, 32]} /><meshBasicMaterial color={lighting} toneMapped={false} /></mesh>
    </Motion>}
    {detailed && !preview && !lowEffects && <pointLight position={[0, 2.6, 2.4]} color={lighting} intensity={7} distance={11} decay={2} />}
  </>
}

function buildAccessories(id: BuildingId, customization: BuildingCustomization) {
  const a = new Architecture()
  const nexus = id === 'reboot-nexus'
  const height = ROOF_HEIGHT[id]
  if (customization.accessories.includes('antenna')) {
    const x = nexus ? NEXUS_ANCHORS.antenna.x : -.8
    const z = nexus ? NEXUS_ANCHORS.antenna.z : -.5
    const rise = nexus ? NEXUS_ANCHORS.antenna.spread : 1.4
    a.beam([x, height, z], [x, height + rise, z], nexus ? NEXUS_ANCHORS.antenna.stem : .09, '#9aa8ad', false, 'metal')
    a.ring([x, height + rise * .68, z], nexus ? .5 : .32, customization.lightingColor, [0, 0, 0], true)
    glow(a, [x, height + rise + .05, z], [.16, .16, .16], customization.lightingColor)
  }
  if (customization.accessories.includes('holo-sign')) {
    const anchor = NEXUS_ANCHORS['holo-sign']
    const x = nexus ? anchor.x : 2.35
    const y = nexus ? anchor.y : 2.75
    const z = nexus ? anchor.z : 1.35
    const w = nexus ? anchor.w : .85
    const h = nexus ? anchor.h : 1.25
    block(a, [x, y, z], [w, h, .12], '#23323c', 'metal')
    glow(a, [x, y, z + .08], [w - .25, h - .3, .04], customization.lightingColor)
    for (const offset of [-.25, 0, .25]) glow(a, [x, y + offset * h, z + .12], [w * .53, .055, .025], '#f2ffff')
  }
  if (customization.accessories.includes('garden')) {
    const anchor = NEXUS_ANCHORS.garden
    const x = nexus ? anchor.x : 2.15
    const z = nexus ? anchor.z : 1.75
    const y = nexus ? anchor.y : .3
    const w = nexus ? anchor.w : 1.25
    const d = nexus ? anchor.d : 1.25
    block(a, [x, y, z], [w, .55, d], '#5e6460', 'stone')
    block(a, [x, y + .3, z], [w - .25, .12, d - .25], '#344c3d', 'foliage')
    for (const offset of [-.45, .1, .5]) a.add('rock', [x + offset, y + .65, z + offset * .4], [.42, .65, .42], '#64a474', [0, offset, 0], false, 'foliage')
  }
  if (customization.accessories.includes('solar-array')) {
    const anchor = NEXUS_ANCHORS['solar-array']
    const x = nexus ? anchor.x : 0
    const z = nexus ? anchor.z : 0
    const y = (nexus ? anchor.y : height) + .35
    const w = nexus ? anchor.w : 1.8
    const d = nexus ? anchor.d : 1.25
    block(a, [x, y - .23, z], [.12, .45, .12], '#717e83', 'metal')
    block(a, [x, y, z], [w, .1, d], '#244b63', 'metal', [-.25, 0, 0])
    for (const offset of [-.55, 0, .55]) glow(a, [x + offset * (w - .5), y + .065, z - .03], [.025, .025, d - .2], '#6aa9c0', [-.25, 0, 0])
  }
  return a
}

export function BuildingModel({
  definitionId,
  customization,
  detailed = true,
  preview = false,
  selected = false,
}: BuildingModelProps) {
  const { reduced, lowEffects } = useEnvironment()
  const custom = useMemo(() => normalizeBuildingCustomization(customization), [customization])
  const personalized = definitionId === 'reboot-nexus' || customization !== undefined
  const style = useMemo<ModelStyle>(() => {
    const base = BASE_STYLES[definitionId]
    return personalized ? {
      exterior: custom.exteriorColor,
      lighting: custom.lightingColor,
      finish: FINISH_MAP[custom.finish],
    } : base
  }, [custom, definitionId, personalized])
  const architecture = useMemo(() => {
    const solid = new Architecture()
    const detail = new Architecture()
    BUILDERS[definitionId](solid, detail, style, detailed)
    return { solid, detail }
  }, [definitionId, detailed, style])
  const accessories = useMemo(
    () => detailed ? buildAccessories(definitionId, custom) : new Architecture(),
    [custom, definitionId, detailed],
  )
  const selection = useMemo(() => {
    if (!selected) return null
    const definition = getBuildingDefinition(definitionId)
    const worldDiameter = Math.max(definition.footprint.width, definition.footprint.depth) * 6
    return new Architecture().ring([0, .045, 0], worldDiameter * .53, custom.lightingColor)
  }, [custom.lightingColor, definitionId, selected])
  const animated = detailed && !preview && !reduced && !lowEffects

  return <group name={`building-${definitionId}`} userData={{ buildingId: definitionId }}>
    <Parts solid data={architecture.solid} name={`${definitionId}-solid`} />
    <Parts data={architecture.detail} name={`${definitionId}-detail`} />
    {detailed && <Parts data={accessories} name={`${definitionId}-accessories`} />}
    {definitionId === 'reboot-nexus' && <>
      <NexusGlass lighting={style.lighting} />
      <NexusEffects lighting={style.lighting} animated={animated} detailed={detailed} preview={preview} lowEffects={lowEffects} />
    </>}
    {selection && <Parts data={selection} name="building-selection" />}
  </group>
}
