import { useMemo, Suspense } from 'react'
import { Text } from '@react-three/drei'
import { CITIES, type CityId } from '../cityRegistry'
import { WORLD_PROFILES } from '../worldManifest'
import { Architecture, Parts, Motion, type Vec } from './ScenePrimitives'

const MATERIALS: Record<CityId,[string,string,string]> = {
  Graveyard:['#424c62','#6b596f','#323947'], IdeaHub:['#739e97','#b38c68','#4e706d'], Legend:['#dad1b8','#ae9161','#f0e7cf'],
  AI:['#416d85','#87afbd','#233e59'], Gaming:['#796298','#d6a06a','#526984'], Education:['#b2b29a','#d1b98a','#729b90'],
  Health:['#9ccbb4','#c1dfd1','#538c78'], Creator:['#b487a7','#d2a987','#668cae'], Space:['#79829b','#a6adc1','#424d74'],
  Robotics:['#747e86','#be9463','#445961'], Community:['#b5a288','#b27963','#77a08a'],
}
function columns(a:Architecture,x:number,z:number,color:string,h=5) {
  for(const side of [-1,1]) {a.box([x+side*3,h/2,z],[.6,h,.6],color);a.box([x+side*3,.2,z],[1,.4,1],color)}
  a.box([x,h,z],[7,.6,1],color)
}
function planter(a:Architecture,x:number,z:number,color:string) {
  a.box([x,.25,z],[2.6,.5,2.6],color);a.box([x,.53,z],[2.3,.1,2.3],'#4e5f46')
  a.add('pillar',[x,1.5,z],[.2,2,.2],'#8c7761');a.add('rock',[x,3,z],[1.8,2,1.6],'#5b9477')
}
/** Foreground districts are authored separately and share only construction helpers. */
export function explorationArchitecture(city:CityId) {
  const a=new Architecture(),[stone,trim,dark]=MATERIALS[city]
  const deck=(p:Vec,size:Vec,color=stone,r:Vec=[0,0,0])=>a.box(p,size,color,r)
  // Solid approach and satellite pads connect the older diorama's discontinuous ground.
  deck([0,-.16,34],[6,.4,40]);deck([-14,-.16,32],[17,.4,16]);deck([14,-.16,32],[17,.4,16])
  deck([-6,-.16,32],[13,.4,4]);deck([6,-.16,32],[13,.4,4])
  for(const [x,z] of [[-30,8],[29,4],[-22,-34],[25,-32]]) {deck([x,-.18,z],[18,.4,17]);a.beam([0,-.18,9],[x,-.18,z+4],3.5,stone)}
  // Project landings keep the actual records reachable on the central district floor.
  a.add('pillar',[0,-.7,0],[42,1.3,42],dark)
  switch(city) {
    case 'Graveyard':
      for(const x of [-19,19]) {
        deck([x,2,31],[.55,4,9],dark,[0,0,x<0?.12:-.18]);deck([x,4.8,31],[.7,2.5,9],stone,[0,0,.28])
        for(let i=0;i<3;i++){a.beam([x-2+i*2,0,26],[x-2+i*2,8-i,26],.2,trim);deck([x-2+i*2,.4,28+i*2],[2,.5,1.5],trim,[0,.2,.4])}
      }
      columns(a,-14,36,'#667086',4);deck([-14,2,36],[5,3,.3],dark);deck([-14,2,36.2],[3,.1,.1],'#bd617a',undefined)
      for(let i=0;i<6;i++) {const x=12+i%3*2,z=28+Math.floor(i/3)*3;a.add('rock',[x,.5,z],[.6,.9,.7],trim,[i,.2,i])}
      a.ring([14,2,36],3,'#786587',[0,0,0],false);break
    case 'IdeaHub':
      for(const x of [-19,-9]){a.beam([x,0,26],[x,10,26],.35,trim);a.beam([x,0,26],[x,5,36],.2,trim)}
      deck([-14,10,26],[12,.6,2],trim);a.beam([-10,10,26],[-10,3,26],.07,'#d2cec2')
      for(let i=0;i<5;i++) {deck([-18,1+i*.8,30],[3,.6,4],i<2?dark:stone);deck([-11,.5,28+i*2],[2,1,1.5],i%2?trim:stone)}
      for(let i=0;i<8;i++)deck([14,-.1+i*.22,27+i*1.2],[8,.3,1.3],stone)
      columns(a,14,36,trim,7);deck([14,6,36],[8,.3,5],stone);break
    case 'Legend':
      for(const x of [-20,-8,8,20]) {a.add('pillar',[x,3,29],[.6,6,.6],stone);a.add('pillar',[x,6.2,29],[1,.4,1],trim)}
      deck([-14,6.6,29],[14,.8,2],stone);deck([14,6.6,29],[14,.8,2],stone)
      for(let i=0;i<7;i++) {deck([-14,.15+i*.2,31+i],[10,.3,1.1],stone);deck([14,.15+i*.2,31+i],[10,.3,1.1],stone)}
      for(const x of [-20,-8,8,20])planter(a,x,37,trim)
      a.add('rock',[-14,4,37],[1,1.8,1],trim);a.add('pillar',[-14,2,37],[1.5,2,1.5],stone)
      for(const x of [-10,10]) {a.beam([x,0,10],[x,8,10],.6,stone);a.beam([x,8,10],[0,13,10],.5,stone)}break
    case 'AI':
      for(const x of [-14,14]) {
        a.add('hex',[x,.5,32],[5,1,5],stone)
        for(let i=0;i<3;i++){deck([x+(i-1)*2.3,2.5,28],[1.5,4,1.5],dark);deck([x+(i-1)*2.3,3,28.8],[.7,2,.06],'#6ec6d8')}
        a.beam([x-5,0,33],[x-3,8,33],.35,trim);a.beam([x+5,0,33],[x+3,8,33],.35,trim);deck([x,8,33],[7,.4,4],stone)
        a.beam([x,.15,32],[0,.15,10],.07,'#7bbac8',true)
      }break
    case 'Gaming':
      for(let i=0;i<6;i++) {
        deck([-20+i*2.4,.25+i*.52,29],[2.2,.5,3],i%2?trim:stone)
        deck([12+i%3*2,1+Math.floor(i/3),37],[1.9,2+Math.floor(i/3)*2,1.9],i%2?dark:stone)
      }
      columns(a,14,28,trim,5);a.box([14,5.7,28],[6,.8,1],dark)
      for(let i=0;i<5;i++){deck([-19+i*2.4,1+i*.5,36],[1.7,.4,1.7],i%2?trim:stone)}
      deck([-8,3.4,36],[3,.4,3],trim);deck([-8,3.8,36],[1,.4,1],dark)
      break
    case 'Education':
      for(const x of [-19,-9,9,19])planter(a,x,28,dark)
      for(const x of [-14,14]) {
        columns(a,x,36,trim,5);deck([x,5.3,36],[8,.3,5],stone)
        for(let level=0;level<3;level++) {
          deck([x,1+level*1.4,37.5],[5,.15,1],trim)
          for(let j=0;j<8;j++)deck([x-2+j*.55,1.5+level*1.4,37.5],[.35,.75,.7],['#d0ba96','#629d9b','#8c789e'][j%3],[0,0,j%3===0?.1:0])
        }
        deck([x,1,32],[4,.2,2],trim)
      }break
    case 'Health':
      for(const x of [-14,14]) {
        for(let i=0;i<5;i++) {const angle=i*1.25;a.add('orb',[x+Math.cos(angle)*4,1.1,32+Math.sin(angle)*4],[1.4,1.4,1.4],i%2?dark:stone)}
        a.add('pillar',[x,.4,32],[3.3,.7,3.3],'#5b9fa7');a.ring([x,.78,32],3.3,trim,undefined,false)
        for(const dx of [-5,5])planter(a,x+dx,36,trim)
      }
      for(let i=0;i<8;i++)a.add('orb',[-19+i*1.5,.5,25],[.9,.6,1.3],dark)
      break
    case 'Creator':
      columns(a,-14,37,trim,6)
      for(let i=0;i<3;i++)deck([-18+i*4,4.5+i*.4,37],[3,5,.2],[stone,trim,dark][i],[0,(i-1)*.4,(i-1)*.1])
      for(let i=0;i<8;i++)deck([14,.15+i*.38,26+i*1.4],[7,.4,1.5],i%2?stone:dark)
      a.beam([10,0,37],[12,9,37],.6,trim);a.beam([18,0,37],[16,9,37],.6,trim)
      a.box([14,9,37],[6,.5,3],stone,[0,.3,.15])
      break
    case 'Space':
      for(const x of [-19,-9,9,19]) {a.beam([x,0,29],[x,3,29],.3,trim);deck([x,3.2,29],[4,.2,4],dark,[.2,0,.15])}
      a.add('pillar',[14,.12,32],[6,.15,6],trim);a.ring([14,.23,32],5.9,'#99c6ec')
      for(let i=0;i<6;i++) {const angle=i*Math.PI/3;a.add('rock',[14+Math.cos(angle)*7,.4,32+Math.sin(angle)*7],[1,1.4,1.2],dark)}
      columns(a,-14,36,trim,5);a.add('orb',[-14,5.2,36],[3,1.5,3],stone)
      a.beam([-14,5.2,36],[-14,6.8,31],.8,trim);a.ring([-14,6.8,31],1.4,'#81bfdc',[.25,0,0],false)
      break
    case 'Robotics':
      for(const x of [-14,14]) {
        columns(a,x,28,trim,7);deck([x,1.4,33],[6,.4,2],dark)
        for(let i=0;i<8;i++)a.add('pillar',[x-2.5+i*.7,1.7,33],[.17,2.1,.17],stone,[0,0,Math.PI/2])
        a.add('pillar',[x+4,2,36],[.8,4,.8],trim);a.beam([x+4,4,36],[x+1,6,36],.7,stone)
        for(let i=0;i<3;i++)deck([x-3+i*2,1,37],[1.5,2,1.5],i%2?dark:stone)
        a.beam([x-4,.2,26],[x+4,.2,26],.14,trim)
      }break
    case 'Community':
      for(const x of [-19,19]) {
        deck([x,2.2,29],[5,4.4,5],stone);a.add('cone',[x,5.3,29],[4,2.6,4],trim,[0,Math.PI/4,0])
        deck([x,1.9,31.55],[1.2,2.5,.1],dark)
        for(const dx of [-1.5,1.5])deck([x+dx,3,31.6],[.8,.85,.06],'#edcca0')
        deck([x,3.9,32.5],[5,.2,2],trim);for(const dx of [-2,2])a.beam([x+dx,0,33],[x+dx,4,33],.15,dark)
      }
      for(const x of [-12,12]) {deck([x,1,36],[4,.3,2],dark);columns(a,x,37,trim,3);deck([x,3.3,37],[7,.3,4],['#c68e77','#7fafa0'][x<0?0:1]);planter(a,x,27,stone)}
      deck([14,1,32],[3,.3,2],trim);for(const x of [12,16])deck([x,.55,32],[.6,1.1,2.5],dark)
      break
  }
  // Benches and edge guards give each route readable scale without enclosing the city.
  for(const x of [-3.3,3.3])for(const z of [22,42]) {
    a.beam([x,0,z],[x,1.1,z],.14,trim);a.beam([x,1.1,z],[x,1.1,z+5],.14,trim)
  }
  return a
}
export function ExplorationSites({city}: {city:CityId}) {
  const data=useMemo(()=>explorationArchitecture(city),[city]),p=CITIES[city].palette,profile=WORLD_PROFILES[city]
  const sign=useMemo(()=>new Architecture().box([0,4.6,48.8],[18,2.3,.35],MATERIALS[city][2]).box([-9,2.3,48.8],[.4,4.6,.4],MATERIALS[city][1]).box([9,2.3,48.8],[.4,4.6,.4],MATERIALS[city][1]),[city])
  return <group name={`${city}-exploration-sites`}>
    <Parts solid data={data}/>
    <Suspense fallback={null}><Text font="/fonts/Inter-Medium.ttf" position={[0,4.6,49]} fontSize={1.25} color={MATERIALS[city][1]} anchorX="center" outlineWidth={.015} outlineColor="#122332">{CITIES[city].name}</Text></Suspense>
    <Parts solid data={sign}/>
    {profile.discoveries.map((label,i)=><group key={label} position={[i?14:-14,0,32]} userData={{discovery:label}}>
      <Motion position={[0,2.7,0]} speed={city==='Creator'?.25:.08} bob={.1}><mesh><octahedronGeometry args={[.3]}/><meshStandardMaterial color={p.secondary} roughness={.4} emissive={p.accent} emissiveIntensity={.2}/></mesh></Motion>
    </group>)}
  </group>
}
