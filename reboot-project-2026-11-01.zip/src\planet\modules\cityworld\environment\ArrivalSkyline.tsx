import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Group, DoubleSide, AdditiveBlending } from 'three'
import { CITIES, CITY_CATEGORIES, type CityId } from '../cityRegistry'
import { useEnvironment } from './ScenePrimitives'

const ARC:Record<CityId,number>={Graveyard:.78,IdeaHub:1.35,Legend:1.08,AI:1.65,Gaming:.9,Education:.65,Health:1.25,Creator:1.8,Space:1.75,Robotics:1.35,Community:1.15}
/** District-scale silhouettes echo each city's architecture, outside all walkable space. */
export function ArrivalSkyline({ city }: {city: CityId}) {
  const { reduced, lowEffects } = useEnvironment()
  const index = CITY_CATEGORIES.indexOf(city),palette = CITIES[city].palette,satellites = useRef<Group>(null)
  const ribs = useMemo(() => Array.from({length: lowEffects ? 10 : 18}, (_, i) => i / (lowEffects ? 10 : 18) * Math.PI * ARC[city]), [city,lowEffects])
  useFrame((_, delta) => { if (satellites.current && !reduced) satellites.current.rotation.z += Math.min(delta, .05) * .014 })
  return <group name={`${city}-orbital-silhouette`} position={[index % 2 ? 36 : -32, 64, -126]} rotation={[.08, 0, index % 2 ? -.28 : .3]}>
    <mesh rotation={[0, 0, -.6]}><torusGeometry args={[44, city==='Gaming'?.7:1.15, 6, 96, Math.PI * ARC[city]]} /><meshStandardMaterial color={city==='Legend'?'#a88f64':city==='Community'?'#526f64':'#263d48'} roughness={.6} metalness={city==='Community'?.15:.7} /></mesh>
    <mesh rotation={[0, 0, -.6]}><torusGeometry args={[42.6, .12, 5, 96, Math.PI * ARC[city]]} /><meshBasicMaterial color={palette.accent} fog={false} /></mesh>
    {city!=='Education'&&<mesh rotation={[0, 0, -.6]}><torusGeometry args={[45.4, .07, 5, 96, Math.PI * ARC[city]]} /><meshBasicMaterial color={palette.secondary} fog={false} /></mesh>}
    {ribs.map((a, i) => <mesh key={i} position={[Math.cos(a - .6) * 44, Math.sin(a - .6) * 44, 0]} rotation={[city==='Graveyard'?(i%3-1)*.25:0, 0, a - .6+(city==='Creator'?(i%2?.3:-.3):0)]}>
      {city==='Gaming'?<boxGeometry args={[4,4+i%4*2,2.5]}/>:city==='Legend'?<cylinderGeometry args={[.7,.9,10,12]}/>:<boxGeometry args={[4, city==='Graveyard'?.25:.42, 2]} />}
      <meshStandardMaterial color={city==='Gaming'?['#c17c6c','#67558b','#4e8190'][i%3]:city==='Legend'?'#d6c49e':'#6d7c7c'} metalness={.55} roughness={.6} />
    </mesh>)}
    {city==='Education'&&<group position={[0,-5,0]} rotation={[0,0,-.6]}>{[-1,1].map(side=><mesh key={side} position={[side*16,0,0]} rotation={[0,side*.18,side*.24]}><boxGeometry args={[33,24,.8]}/><meshStandardMaterial color={side<0?'#cbb88e':'#7fa69b'} roughness={.75}/></mesh>)}{Array.from({length:lowEffects?3:7},(_,i)=><mesh key={i} position={[(i-3)*7,20+Math.sin(i)*5,2]} rotation={[0,0,(i-3)*.15]}><boxGeometry args={[4,5,.15]}/><meshStandardMaterial color="#e4d5af"/></mesh>)}</group>}
    {(city==='Health'||city==='Community')&&<group>{ribs.filter((_,i)=>i%3===0).map((a,i)=><mesh key={i} position={[Math.cos(a-.6)*44,Math.sin(a-.6)*44,0]} scale={[6,3,4]}><sphereGeometry args={[1,16,10]}/><meshStandardMaterial color={city==='Health'?'#7fb79b':['#7b9c75','#b1b784','#6d9987'][i%3]} roughness={.9}/></mesh>)}</group>}
    {city==='Creator'&&<group>{[-1,1].map(side=><mesh key={side} position={[side*25,side*12,4]} rotation={[.2,.3,side*.4]}><boxGeometry args={[18,25,.5]}/><meshStandardMaterial color={side<0?'#c17c9c':'#6e9db7'} roughness={.5}/></mesh>)}<mesh rotation={[.7,.4,.9]}><torusGeometry args={[30,.3,6,64]}/><meshBasicMaterial color={palette.secondary}/></mesh></group>}
    {city==='Graveyard'&&<group>{[-1,1].map(side=><mesh key={side} position={[side*24,8,0]} rotation={[0,0,side*.35]}><coneGeometry args={[3,24,5]}/><meshStandardMaterial color="#4c4b5d"/></mesh>)}</group>}
    <group ref={satellites}>{[0, 2.1, 4.2].map(a => <mesh key={a} position={[Math.cos(a) * 49, Math.sin(a) * 49, 0]} rotation={[Math.PI/2,0,0]}>{city==='Gaming'?<cylinderGeometry args={[1.1,1.1,.25,16]}/>:<octahedronGeometry args={[.65]} />}<meshBasicMaterial color={city==='Gaming'?'#f2c365':palette.accent} /></mesh>)}</group>
    {!lowEffects && <mesh position={[0, 0, -3]}><planeGeometry args={[130, 130]} /><shaderMaterial transparent depthWrite={false} side={DoubleSide} blending={AdditiveBlending} vertexShader="varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}" fragmentShader="varying vec2 vUv;void main(){float d=length(vUv-.5)*2.;float a=pow(max(0.,1.-d),3.)*.16;gl_FragColor=vec4(.15,.5,.65,a);}" /></mesh>}
  </group>
}
