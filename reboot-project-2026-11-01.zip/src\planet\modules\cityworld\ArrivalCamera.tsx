import { useLayoutEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { CubicBezierCurve3, PerspectiveCamera, Vector3 } from 'three'
import { useJourney } from '@/planet/stores/journey'
import { FLIGHT_SECONDS, ORBIT_POSITION, flightProgress } from './flightMath'

export function ArrivalCamera({ reduced, ready }: { reduced: boolean; ready: boolean }) {
  const camera = useThree(s => s.camera) as PerspectiveCamera
  const active = useJourney(s => s.introducing)
  const id = useJourney(s => s.introId)
  const time = useRef(0)
  const path = useMemo(() => new CubicBezierCurve3(new Vector3(-90, 48, 166), new Vector3(-44, 64, 158), new Vector3(6, 28, 128), new Vector3(...ORBIT_POSITION)), [])
  const look = useMemo(() => new Vector3(), [])
  useLayoutEffect(() => {
    time.current = 0
    if (active) { camera.position.copy(path.v0); camera.lookAt(12, 0, 0) }
    else { camera.position.set(...ORBIT_POSITION); camera.lookAt(0, 0, 0) }
    return () => { camera.fov = 50; camera.updateProjectionMatrix() }
  }, [active, id, camera, path])
  useFrame((_, delta) => {
    if (!active || !ready) return
    time.current += Math.max(0, delta)
    const t = flightProgress(time.current, FLIGHT_SECONDS.introduction, reduced)
    path.getPoint(reduced ? 1 : t, camera.position)
    look.set(reduced ? 0 : 12 * (1 - t), 0, 0)
    camera.lookAt(look)
    camera.fov = reduced ? 50 : 54 - 4 * t
    camera.updateProjectionMatrix()
    if (t === 1) useJourney.getState().finishEntry()
  })
  return null
}
