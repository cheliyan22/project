// Detects whether this GPU/driver can actually render into half-float (RGBA16F) color
// targets. Some software renderers advertise EXT_color_buffer_float yet produce blank
// output, so we clear-and-read-back a 1px probe framebuffer instead of trusting the
// extension string. Without this, EffectComposer's HDR buffers can silently render black.
let cached: boolean | null = null

export function decodeHalf(h: number): number {
  const sign = h & 0x8000 ? -1 : 1
  const exp = (h & 0x7c00) >> 10
  const frac = h & 0x03ff
  if (exp === 0) return sign * (frac / 1024) * 2 ** -14
  if (exp === 31) return Number.NaN
  return sign * (1 + frac / 1024) * 2 ** (exp - 15)
}

export function supportsHdrBuffers(): boolean {
  if (cached !== null) return cached
  cached = false
  let gl: WebGL2RenderingContext | null = null
  try {
    const canvas = document.createElement('canvas')
    canvas.width = canvas.height = 2
    gl = canvas.getContext('webgl2')
    if (gl && gl.getExtension('EXT_color_buffer_float')) {
      const texture = gl.createTexture()
      const buffer = gl.createFramebuffer()
      if (texture && buffer) {
        gl.bindTexture(gl.TEXTURE_2D, texture)
        gl.texStorage2D(gl.TEXTURE_2D, 1, gl.RGBA16F, 1, 1)
        gl.bindFramebuffer(gl.FRAMEBUFFER, buffer)
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0)
        if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE) {
          // Some software renderers advertise 16F framebuffers yet drop real draw
          // calls, so render a constant-color quad instead of only clearing.
          const program = gl.createProgram()
          const vertex = gl.createShader(gl.VERTEX_SHADER)
          const fragment = gl.createShader(gl.FRAGMENT_SHADER)
          if (program && vertex && fragment) {
            gl.shaderSource(vertex, '#version 300 es\nvoid main(){float x=float((gl_VertexID&1)*2-1);float y=float(((gl_VertexID>>1)&1)*2-1);gl_Position=vec4(x,y,0.,1.);}')
            gl.compileShader(vertex)
            gl.shaderSource(fragment, '#version 300 es\nprecision highp float;out vec4 o;void main(){o=vec4(0.25,0.5,0.75,1.0);}')
            gl.compileShader(fragment)
            gl.attachShader(program, vertex)
            gl.attachShader(program, fragment)
            gl.linkProgram(program)
            if (gl.getProgramParameter(program, gl.LINK_STATUS)) {
              gl.viewport(0, 0, 1, 1)
              gl.useProgram(program)
              gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
              const pixel = new Uint16Array(4)
              gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.HALF_FLOAT, pixel)
              cached = gl.getError() === 0
                && Math.abs(decodeHalf(pixel[0]) - 0.25) < 0.05
                && Math.abs(decodeHalf(pixel[1]) - 0.5) < 0.05
                && Math.abs(decodeHalf(pixel[2]) - 0.75) < 0.05
            }
          }
          gl.deleteProgram(program)
          gl.deleteShader(vertex)
          gl.deleteShader(fragment)
        }
        gl.deleteFramebuffer(buffer)
        gl.deleteTexture(texture)
      }
    }
  } catch {
    cached = false
  }
  gl?.getExtension('WEBGL_lose_context')?.loseContext()
  return cached
}
