import { useMemo, useRef, useState } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { BuildingModel } from '@/planet/buildings/BuildingModel'
import { useEconomy, type PlacementRecord } from '@/planet/stores/economy'
import { useAuth } from '@/planet/stores/auth'
import { PersonalMegaTitle } from './environment/MegaTitles'
import { Architecture, Parts, useEnvironment } from './environment/ScenePrimitives'
import { SurfaceProvider } from './environment/SurfaceMaterials'
import { CitySky } from './environment/CitySky'
import { FillerSkyline } from './cities/cityKit'
import { CITIES } from './cityRegistry'

const GRID_SIZE = 6

function PersonalCamera() {
  const camera = useThree(s => s.camera)
  const initialized = useRef(false)
  useFrame(() => {
    if (initialized.current) return
    camera.position.set(58, 46, 72)
    camera.lookAt(0, 5, 0)
    initialized.current = true
  })
  return null
}

function OwnedBuilding({ placement }: { placement: PlacementRecord }) {
  const group = useRef<THREE.Group>(null)
  const [detailed, setDetailed] = useState(true)
  const ownership = useEconomy(s => s.ownership.find(o => o.id === placement.ownership_id))
  const definitionId = placement.free_definition_id ?? ownership?.definition_id
  const lastCheck = useRef(0)
  useFrame(state => {
    if (!group.current || state.clock.elapsedTime - lastCheck.current < .5) return
    lastCheck.current = state.clock.elapsedTime
    const distance = state.camera.position.distanceTo(group.current.getWorldPosition(new THREE.Vector3()))
    const next = distance < 85
    if (next !== detailed) setDetailed(next)
  })
  if (!definitionId) return null
  return <group ref={group} position={[placement.grid_x * GRID_SIZE, 0, placement.grid_z * GRID_SIZE]} rotation={[0, placement.rotation * Math.PI / 2, 0]}>
    <BuildingModel definitionId={definitionId} customization={ownership?.customization} detailed={detailed} />
  </group>
}

function CityFoundation({ low }: { low: boolean }) {
  const architecture = useMemo(() => {
    const a = new Architecture()
    a.box([0, -.65, 0], [164, 1.2, 164], '#101922', [0, 0, 0], false, 'stone')
    a.box([0, -.02, 0], [156, .08, 156], '#172630')
    for (let i = -12; i <= 12; i++) {
      a.box([i * GRID_SIZE, .035, 0], [.035, .025, 150], i % 4 === 0 ? '#285b6b' : '#1d3d49', [0, 0, 0], i % 4 === 0)
      a.box([0, .035, i * GRID_SIZE], [150, .025, .035], i % 4 === 0 ? '#285b6b' : '#1d3d49', [0, 0, 0], i % 4 === 0)
    }
    for (const side of [-1, 1]) {
      a.box([side * 78, .2, 0], [1.4, .4, 158], '#26343e')
      a.box([0, .2, side * 78], [158, .4, 1.4], '#26343e')
      for (let i = -6; i <= 6; i++) {
        a.box([side * 77, 2.2, i * 12], [.22, 4.4, .22], '#314651')
        a.box([side * 77, 4.5, i * 12], [.45, .12, .45], i % 2 ? '#3dd8ff' : '#ff4fd8', [0, 0, 0], true)
      }
    }
    if (!low) {
      for (const x of [-60, 60]) for (const z of [-60, 60]) {
        a.box([x, .35, z], [8, .7, 8], '#25353d')
        a.box([x, 1.4, z], [5.5, 1.4, 5.5], '#1b4a45')
        for (let i = 0; i < 5; i++) a.add('rock', [x - 2 + i, 2.5 + (i % 2) * .4, z], [.55, 1.4, .55], '#4d8e79')
      }
    }
    return a
  }, [low])
  return <Parts data={architecture} name="personal-city-foundation" solid />
}

export function PersonalCityScene() {
  const placements = useEconomy(s => s.placements)
  const pilot = useAuth(s => s.user?.displayName ?? null)
  const { lowEffects } = useEnvironment()
  return <SurfaceProvider city="AI" low={lowEffects}><group name="Community-district">
    <PersonalCamera />
    <CitySky city="AI" />
    <PersonalMegaTitle pilot={pilot} />
    <CityFoundation low={lowEffects} />
    <FillerSkyline palette={CITIES.AI.palette} count={lowEffects ? 16 : 34} seed="personal-reboot-skyline" heightScale={.72} />
    {placements.slice(0, 25).map(placement => <OwnedBuilding key={placement.id} placement={placement} />)}
    {!placements.length && <group position={[0, .1, 0]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[5.7, 6, 6]} /><meshBasicMaterial color="#3dd8ff" transparent opacity={.5} /></mesh>
    </group>}
  </group></SurfaceProvider>
}
