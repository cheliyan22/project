import type { Architecture, Vec } from '../modules/cityworld/environment/ScenePrimitives'
import type { Finish } from '../modules/cityworld/environment/SurfaceMaterials'

/* ─────────────────────────────────────────────────────────────────────────────
   REBOOT NEXUS · second design — "The Canopied Gate"
   A from-scratch architectural concept. It shares nothing with the previous
   design, whose identity was two slender vertical towers joined by sky bridges.

   Design idea, in one sentence:
     A heavy mass that WIDENS as it rises, hovering over a walk-through gate,
     with its negative space carved rather than decorated.

   Five moves carry the whole composition:
     1. GATE     — the building stands on two piers. The ground level is a void
                   you can see and walk through, 4 x 4 units, lit only by rungs
                   in its floor and a seam in each cheek.
     2. INVERSION— every tier is wider than the one below it, so the silhouette
                   reads as a protected overhang, never as a skyscraper.
     3. VALUE    — the mass gets lighter as it rises and the slab bands are a
                   fixed design tone, so the layers stay readable even when the
                   owner picks a near-black exterior colour.
     4. OCULUS   — the crown is a ring frame with a hole cut through the roof.
     5. TWO LINES— one grounded leaning blade west and one cantilevered shade
                   blade east break the orthogonal stack.

   Negative space is the subject: the gate, the roof aperture, a hairline slit
   in the upper tier. Lighting is limited to reveals inside those voids — no
   applied neon, no free-floating objects, no repeated pattern.
   ─────────────────────────────────────────────────────────────────────────── */

const TONE = {
  pad: '#141a22',
  floor: '#2a3746',
  plate: '#48596b',
  rim: '#6b7f93',
  deep: '#080c11',
}

/** Value step a fixed tone, so hierarchy survives any owner colour. */
function shade(hex: string, factor: number) {
  const value = hex.replace('#', '')
  const full = value.length === 3 ? [...value].map(c => c + c).join('') : value.padEnd(6, '0').slice(0, 6)
  const channel = (offset: number) => Math.min(255, Math.round(parseInt(full.slice(offset, offset + 2), 16) * factor))
    .toString(16).padStart(2, '0')
  return `#${channel(0)}${channel(2)}${channel(4)}`
}

const mass = (a: Architecture, p: Vec, s: Vec, color: string, finish: Finish, r: Vec = [0, 0, 0]) => a.box(p, s, color, r, false, finish)
const voidIn = (a: Architecture, p: Vec, s: Vec, r: Vec = [0, 0, 0]) => a.box(p, s, TONE.deep, r, false, 'metal')
const seam = (a: Architecture, p: Vec, s: Vec, light: string, r: Vec = [0, 0, 0]) => a.box(p, s, light, r, true)

export function buildNexusGate(solid: Architecture, detail: Architecture, style: { exterior: string; lighting: string; finish: Finish }, detailed: boolean) {
  const light = style.lighting
  const foot = shade(style.exterior, .72)    // piers: the heaviest, darkest value
  const lower = shade(style.exterior, 1.05)  // tier 1
  const upper = shade(style.exterior, 1.55)  // tier 2
  const crest = shade(style.exterior, 2.15)  // keystone

  /* 1 · GROUND — a low pad, split by a trench that runs front to back. */
  mass(solid, [0, .16, 0], [11.4, .32, 9.2], TONE.pad, 'stone')
  mass(solid, [-3.85, .46, 0], [3.7, .28, 8.0], foot, style.finish)
  mass(solid, [3.85, .46, 0], [3.7, .28, 8.0], foot, style.finish)
  mass(solid, [0, .36, 0], [3.9, .08, 8.4], TONE.floor, 'stone')
  for (const z of [-2.6, 0, 2.6]) seam(solid, [0, .42, z], [3.2, .02, .12], light)

  /* 2 · PIERS — two massive legs, shouldered where the canopy springs. */
  for (const side of [-1, 1]) {
    mass(solid, [side * 3.7, 2.3, 0], [3.4, 3.4, 6.8], foot, style.finish)
    mass(solid, [side * 3.7, 4.2, 0], [3.0, .4, 6.2], TONE.plate, 'metal')
    voidIn(solid, [side * 2.03, 2.3, 0], [.06, 3.0, 5.6])
    voidIn(solid, [side * 2.0, 2.3, 2.7], [.05, 2.6, .5])
    seam(solid, [side * 1.97, 2.3, 2.7], [.04, 2.2, .16], light)
  }

  /* 3 · CANOPY PLATE A — the first cantilever, biased toward the approach.
       The rim bands are embedded in the slab, never standing off it. */
  mass(solid, [0, 4.7, .2], [10.6, .6, 8.8], TONE.plate, 'metal')
  mass(solid, [0, 4.7, 4.6], [10.6, .6, .16], TONE.rim, 'metal')
  mass(solid, [-5.34, 4.7, .2], [.16, .6, 8.8], TONE.rim, 'metal')
  mass(solid, [5.34, 4.7, .2], [.16, .6, 8.8], TONE.rim, 'metal')

  /* 4 · TIER 1 — set back inside the overhang, shadow gap at its foot. */
  voidIn(solid, [-.2, 5.08, -.1], [8.4, .16, 6.8])
  mass(solid, [-.2, 6.05, -.1], [8.2, 2.1, 6.6], lower, style.finish)
  voidIn(solid, [-.2, 5.95, 3.1], [6.4, .9, .22])
  for (const x of [-2.15, -.75, .65, 2.05]) seam(solid, [x, 5.95, 3.245], [1.05, .3, .03], light)

  /* 5 · CANOPY PLATE B — wider again; the mass now overhangs its own base. */
  voidIn(solid, [.15, 6.36, .15], [9.6, .12, 7.8])
  mass(solid, [.15, 6.5, .15], [9.4, .4, 7.6], TONE.plate, 'metal')
  mass(solid, [.15, 6.5, 3.95], [9.4, .4, .14], TONE.rim, 'metal')
  mass(solid, [-4.59, 6.5, .15], [.14, .4, 7.6], TONE.rim, 'metal')
  mass(solid, [4.89, 6.5, .15], [.14, .4, 7.6], TONE.rim, 'metal')

  /* 6 · TIER 2 — split by a hairline slit, offset in depth left to right. */
  voidIn(solid, [-.2, 6.76, .1], [8.8, .16, 7.2])
  mass(solid, [-2.775, 7.9, -.25], [4.45, 2.4, 7.0], upper, style.finish)
  mass(solid, [2.25, 7.9, .45], [4.2, 2.4, 6.0], upper, style.finish)
  voidIn(solid, [-.2, 7.9, .4], [.68, 2.2, .2])
  seam(solid, [-.2, 6.98, .5], [.2, .5, .03], light)

  /* 7 · CROWN — a flat ring frame with a real aperture cut through the roof. */
  voidIn(solid, [0, 9.06, 0], [10.9, .14, 8.8])
  mass(solid, [0, 9.36, -1.85], [10.8, .52, 4.5], TONE.plate, 'metal')
  mass(solid, [0, 9.36, 4.0], [10.8, .52, 1.2], TONE.plate, 'metal')
  mass(solid, [-3.3, 9.36, 1.9], [4.2, .52, 3.0], TONE.plate, 'metal')
  mass(solid, [4.0, 9.36, 1.9], [2.8, .52, 3.0], TONE.plate, 'metal')
  mass(solid, [0, 9.36, 4.6], [10.8, .52, .18], TONE.rim, 'metal')
  mass(solid, [-5.44, 9.36, 0], [.18, .52, 9.2], TONE.rim, 'metal')
  mass(solid, [5.44, 9.36, 0], [.18, .52, 9.2], TONE.rim, 'metal')
  // light lining the back edge of the aperture, so the hole reads from below
  seam(solid, [.7, 9.5, .46], [2.6, .08, .04], light)

  /* 8 · KEYSTONE — a small volume caught on the cantilever, over the aperture. */
  mass(solid, [3.4, 9.95, 1.9], [2.2, .66, 3.0], crest, style.finish)
  seam(solid, [3.4, 10.4, 1.9], [.14, .14, .14], light)

  /* 9 · THE TWO LINES — a grounded leaning blade west, a shade blade east.
       The buttress is sunk through the pad and stopped at crown height, so it
       reads as a structure the canopy leans on rather than a free-standing fin,
       and its rotated envelope stays inside the 2 x 2 placement block. */
  mass(solid, [-5.4, 4.66, 0], [.6, 9.92, 5.6], TONE.plate, 'metal', [0, 0, -.06])
  mass(solid, [4.6, 5.6, 1.0], [1.6, .34, 4.6], TONE.plate, 'metal', [0, 0, -.05])

  if (detailed) {
    // approach: the pad steps down toward the visitor, twice
    mass(detail, [0, .16, 5.05], [4.2, .32, 1.0], TONE.floor, 'stone')
    mass(detail, [0, .08, 5.95], [4.9, .16, 1.0], TONE.floor, 'stone')
    // guard rails on the approach side of the trench — thin enough to stay out of collision
    for (const side of [-1, 1]) {
      for (const z of [1.2, 3.0]) mass(detail, [side * 2.24, .78, z], [.07, .5, .07], TONE.rim, 'metal')
      mass(detail, [side * 2.24, 1.02, 2.1], [.05, .05, 3.6], TONE.plate, 'metal')
    }
    // soffit ribs under the front overhang of plate A
    for (let i = 0; i < 5; i++) mass(detail, [-4.0 + i * 2.0, 4.38, 4.3], [.14, .05, .9], TONE.rim, 'metal')
    // terrace paving on the crown, so the roof plane reads from above
    mass(detail, [0, 9.66, -1.9], [10.2, .06, 4.2], TONE.floor, 'stone')
    // parapet teeth on the rear of the crown, uneven by design
    for (const [x, w] of [[-4.4, .5], [-3.1, .32], [-1.6, .62], [3.2, .44]] as const) mass(detail, [x, 9.75, -3.9], [w, .28, .28], TONE.rim, 'metal')
  }
}

/** Where each optional accessory lands on this silhouette. */
export const NEXUS_ANCHORS = {
  antenna: { x: 3.4, y: 10.28, z: 1.9, spread: 1.9, stem: .16 },
  'holo-sign': { x: 3.0, y: 3.2, z: 3.5, w: 1.5, h: 1.9 },
  garden: { x: 3.0, y: .86, z: 3.6, w: 2.2, d: 2.2 },
  'solar-array': { x: -3.3, y: 9.62, z: -1.9, w: 2.6, d: 1.8 },
} as const

/** Transparent layers for the same concept — glazing sits in the carved voids. */
export const NEXUS_GLASS_PANELS: Array<{ p: Vec; s: Vec; opacity: number }> = [
  { p: [.7, 9.5, 1.9], s: [3.8, .04, 3.0], opacity: .16 },    // sealed aperture in the crown
  { p: [-.2, 5.95, 3.16], s: [6.2, .74, .03], opacity: .1 },  // tier 1 reveal
  { p: [-.2, 7.4, .42], s: [.6, 1.2, .03], opacity: .12 },    // the hairline slit
]
