/** Exponential angular smoothing follows the shortest arc across the ±PI seam. */
export function dampAngle(current: number, target: number, smoothing: number, delta: number) {
  const difference = Math.atan2(Math.sin(target-current), Math.cos(target-current))
  return current + difference * (1-Math.exp(-smoothing*delta))
}
