import { MotionConfig } from 'framer-motion'
import { createRoot } from 'react-dom/client'
import { CityWorldManager } from '@/planet/modules/cityworld/CityWorldManager'
import { useProjects } from '@/planet/stores/auth'
import { useJourney } from '@/planet/stores/journey'
import { useUI } from '@/planet/stores/ui'
import type { Project, ProjectCategory, ProjectStatus } from '@/planet/types/project'
import './index.css'
import './planet/planet.css'
import './planet/second-dawn.css'

// Local recording entry point only. It renders the real public project world
// without mounting PlanetPage's authentication and access-control flow.
try { localStorage.setItem('reboot-reduced-effects', 'false') } catch { /* storage optional */ }

const requested = new URLSearchParams(window.location.search).get('city')
const startCategory = requested && requested !== 'hub' ? (requested as ProjectCategory) : null

useUI.setState({
  mode: 'city',
  cityCategory: startCategory,
  destination: null,
  categoryFilter: null,
  travelPhase: 'idle',
  travelError: null,
  exploring: false,
  selectedProjectId: null,
})
useJourney.getState().finishEntry()
useJourney.getState().skipTutorial()

/* The capture harness needs buildings to photograph. When Supabase is not
 * configured this seeds representative records into the store only — the app's
 * own data path is never modified. */
const NAMES: Record<string, string[]> = {
  AI: ['DeepLearn IDE', 'VoiceNote AI', 'CodeReview Bot', 'Chat Widget SDK'],
  Gaming: ['Arena Forge', 'Pixel Dungeon X', 'GameFi Protocol'],
  Education: ['Lesson Loop', 'Study Atlas', 'Classroom Relay'],
  Health: ['Vitals Bridge', 'Restwise', 'Care Route'],
  Creator: ['Canvas Reel', 'Sculpt Stream', 'Palette Sync'],
  IdeaHub: ['Second Draft', 'Rebuild Kit', 'Halfway House'],
  Graveyard: ['CryptoVault Pro', 'SocialVR Alpha', 'MetaShop 2023', 'TaskFlow App'],
  Legend: ['Founder Ledger', 'Handoff Notes', 'Long Table'],
  Space: ['Orbital Relay', 'Lunar Cartography', 'Quiet Sky'],
  Robotics: ['Assembly Line 4', 'Grip Controller', 'Bench Robot'],
  Community: ['Common Table', 'Neighbour Map', 'Open Studio'],
}
const STATUSES: ProjectStatus[] = ['abandoned', 'reviving', 'alive', 'decaying']

function demoProjects(): Project[] {
  const now = Date.now()
  return Object.entries(NAMES).flatMap(([category, names]) =>
    names.map((name, i) => {
      const status = STATUSES[(i + category.length) % STATUSES.length]
      return {
        id: `demo-${category}-${i}`,
        name,
        tagline: 'Archived project record',
        description: 'Captured record used for visual verification.',
        category: category as ProjectCategory,
        status,
        stage: 1 + ((i + category.length) % 5),
        momentum: 20 + ((i * 17) % 70),
        founder: 'Unknown',
        foundedYear: 2020,
        failureYear: null,
        failureReason: null,
        tags: [],
        connections: [],
        viewCount: 120 + i * 90,
        followers: 30 + i * 40,
        createdAt: new Date(now - i * 86400000).toISOString(),
        updatedAt: new Date(now).toISOString(),
      } satisfies Project
    }),
  )
}

void useProjects.getState().fetchProjects()
window.setTimeout(() => {
  const state = useProjects.getState()
  if (!state.projects.length) useProjects.setState({ projects: demoProjects(), loading: false, error: null })
  else useProjects.setState({ error: null })
}, 2200)

createRoot(document.getElementById('root')!).render(
  <MotionConfig reducedMotion="user">
    <div className="planet-page reboot-shell">
      <CityWorldManager />
    </div>
  </MotionConfig>,
)
