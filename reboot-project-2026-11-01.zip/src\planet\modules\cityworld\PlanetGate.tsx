import { Component, Suspense, useRef, type ReactNode } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import { OrbitalWorld } from './OrbitalWorld'
import { useMotionSettings } from './hooks/useCityNavigation'

function PreviewReady() {
  const frames = useRef(0)
  useFrame(({gl, invalidate}) => {
    frames.current++
    if (frames.current === 3) gl.domElement.dataset.previewReady = 'true'
    if (frames.current < 3) invalidate()
  })
  return null
}

class GateGraphicsBoundary extends Component<{children: ReactNode}, {failed: boolean}> {
  state = {failed: false}
  static getDerivedStateFromError() { return {failed:true} }
  render() { return this.state.failed ? null : this.props.children }
}
/** Public visual prologue only. Districts, account data and the economy remain gated. */
export function PlanetGate({ children }: {children: ReactNode}) {
  const { reduced, lowEffects } = useMotionSettings()
  return <div className="planet-page planet-access dawn-access">
    <div className="dawn-access-scene" aria-label="Reboot orbital planet preview">
      <GateGraphicsBoundary><Canvas camera={{position:[0,19,112],fov:50,far:1200}} dpr={[1,lowEffects ? 1 : 1.5]} frameloop={reduced ? 'demand' : 'always'} gl={{antialias:!lowEffects}} fallback={<div />}>
        <color attach="background" args={['#03090f']} /><ambientLight intensity={1} />
        <directionalLight position={[-45,40,65]} intensity={3} color="#b8ebed" />
        <directionalLight position={[65,20,-30]} intensity={4} color="#edba7d" />
        <Suspense fallback={null}><OrbitalWorld reduced={reduced} lowEffects={lowEffects} interactive={false} /><PreviewReady /></Suspense>
        <OrbitControls enablePan={false} enableZoom={false} enableRotate={false} autoRotate={!reduced} autoRotateSpeed={.3} />
      </Canvas></GateGraphicsBoundary>
    </div>
    <div className="dawn-vignette" />
    <p className="dawn-access-brand">REBOOT / SECOND DAWN</p>
    <section className="planet-access-card">{children}</section>
    <p className="dawn-access-note">ORBITAL PREVIEW · YOUR ARCHIVE REMAINS UNCHANGED</p>
  </div>
}
