import { useEffect, useRef, useState, type CSSProperties } from 'react'
import { ArrowDownRight, ArrowUpRight, Check, Compass, Globe2, Loader2, MousePointer2, Move, Play, Share2, Video, X } from 'lucide-react'
import { CITIES, CITY_CATEGORIES, type CityId } from './cityRegistry'
import { CITY_STORIES } from './environment/cityDesign'
import { loadCity } from './cityScenes'
import { shareView } from '@/lib/shareCard'
import { clipSupported, recordClip } from '@/lib/clipRecorder'
import { useUI } from '@/planet/stores/ui'
import { useJourney, type Lesson } from '@/planet/stores/journey'

const CHAPTERS = ['Find your orbit', 'Choose a district', 'Meet the city', 'Make it yours']
const LESSONS: Record<Lesson, {index: number; title: string; text: string}> = {
  orbit: {index: 0, title: 'Take the planet for a spin.', text: 'Drag the world to orbit. Scroll or pinch to zoom. On a keyboard, focus the world and use the arrow keys.'},
  destination: {index: 1, title: 'Find your kind of unfinished.', text: 'Choose a district below, then hit Descend. Each city has its own architecture, atmosphere, and real project archive.'},
  landmark: {index: 2, title: 'Every city has a heart.', text: 'Frame the landmark to get your bearings. You can interrupt any viewpoint glide by dragging the scene.'},
  walk: {index: 3, title: 'Now get off the map.', text: 'Enter walking mode. Use WASD or the on-screen controls to move. Escape releases the camera. My City and the shop stay in the dock.'},
  complete: {index: 3, title: 'This is your second beginning.', text: 'You’re ready. Find a project worth reviving, or build your own corner of Reboot. Replay this guide from Flight school anytime.'},
}

export function FlightDeck({ hub, city, ready, graphics, onLandmark, onWalk }: {hub: boolean; city: CityId | null; ready: boolean; graphics: boolean; onLandmark: () => void; onWalk: () => void}) {
  const selected = useJourney(s => s.selectedCity)
  const introducing = useJourney(s => s.introducing)
  const lesson = useJourney(s => s.lesson)
  const phase = useUI(s => s.travelPhase)
  const destination = useUI(s => s.destination)
  const exploring = useUI(s => s.exploring)
  const busy = phase !== 'idle'
  const info = CITIES[selected]
  const guide = lesson ? LESSONS[lesson] : null
  const skipRef = useRef<HTMLButtonElement>(null)
  const [sharing, setSharing] = useState(false)
  const [clipState, setClipState] = useState<'idle' | 'recording'>('idle')
  const [clipElapsed, setClipElapsed] = useState(0)
  const [clipNote, setClipNote] = useState('')
  const share = async () => {
    setSharing(true)
    try { await shareView(hub ? 'Reboot Planet' : city ? CITIES[city].name : 'Reboot') } finally { setSharing(false) }
  }
  /* Captures the live canvas for a few seconds. The HUD is not in frame (a canvas
     capture sees only the WebGL surface), so this is a clip of the world, and the
     world keeps rendering because `recording` forces continuous frames. */
  const record = async () => {
    if (clipState === 'recording') return
    setClipState('recording')
    setClipElapsed(0)
    setClipNote('')
    const label = hub ? 'orbit' : city ? CITIES[city].name : 'Reboot'
    useUI.getState().setRecording(true)
    try {
      const result = await recordClip({ label, seconds: 8, onTick: (seconds) => setClipElapsed(Math.floor(seconds)) })
      setClipNote(result.outcome === 'recorded'
        ? `Clip saved as ${result.filename}.`
        : result.outcome === 'unsupported'
          ? 'This browser cannot record the world.'
          : 'The world was not ready to record.')
    } finally {
      useUI.getState().setRecording(false)
      setClipState('idle')
    }
  }
  useEffect(() => { if (introducing) skipRef.current?.focus({preventScroll:true}) }, [introducing])
  useEffect(() => {
    // Prepare only the selected destination while the visitor reads its story.
    // Navigation retains its own error handling; a failed prefetch is retryable.
    if (hub && ready && graphics) void loadCity(selected).catch(() => {})
  }, [hub, ready, graphics, selected])
  const startLesson = () => {
    if (!hub) useUI.getState().setMode('city')
    useJourney.getState().startTutorial()
  }
  return <>
    {introducing && <div className="dawn-intro" aria-label="Planet arrival cinematic">
      <div className="dawn-intro-top"><span>REBOOT / ORBITAL ARCHIVE</span><span>CHAPTER 01</span></div>
      <div className="dawn-intro-copy"><p>NOT EVERYTHING LOST IS GONE.</p><h1>A second<br /><em>beginning.</em></h1><div className="dawn-intro-rule" /><span>A world built from what comes next.</span></div>
      <button ref={skipRef} className="dawn-skip" onClick={() => useJourney.getState().finishEntry()}>Skip intro <ArrowUpRight size={14} /></button>
    </div>}
    {!introducing && !busy && !exploring && <>
      {hub && <div className="orbital-editorial"><p className="dawn-eyebrow"><span /> REBOOT PLANET · SECOND DAWN</p><h1>Nothing ends.<br /><em>It transforms.</em></h1><p className="orbital-manifesto">Abandoned projects finally get a home.<br />Find your city. Give an idea its next life.</p></div>}
      <div className="flight-utilities"><span><Globe2 size={13} /> {!graphics ? 'PROJECT DIRECTORY' : hub ? 'ORBITAL VIEW' : 'SURFACE VIEW'}</span><span className="flight-utility-actions">{graphics && <button disabled={sharing} onClick={share}>{sharing ? <><Loader2 size={13} className="dawn-spin" /> PREPARING CARD…</> : <><Share2 size={13} /> Share view</>}</button>}{graphics && <button className="flight-record" disabled={clipState === 'recording' || !clipSupported()} aria-live="polite" onClick={() => void record()}>{clipState === 'recording' ? <><i className="rec-dot" aria-hidden /> REC {clipElapsed}s</> : <><Video size={13} /> Record clip</>}</button>}{graphics && <button onClick={startLesson}><Compass size={13} /> Flight school</button>}</span>{clipNote && <span className="flight-clip-note" role="status">{clipNote}</span>}</div>
      {hub && <section className="descent-card" style={{'--district-accent':info.palette.accent} as CSSProperties} aria-label="Selected destination">
        <div className="descent-meta"><span>DESTINATION / {String(CITY_CATEGORIES.indexOf(selected) + 1).padStart(2, '0')}</span><span>{CITY_CATEGORIES.length} DISTRICTS</span></div>
        <h2>{info.name}<ArrowDownRight size={30} strokeWidth={1} /></h2>
        <p>{CITY_STORIES[selected].purpose}</p>
        <div className="descent-landmark"><span>LANDMARK</span>{info.landmark}</div>
        <button className="descent-launch" disabled={!ready} onClick={() => useUI.getState().enterCity(selected)}>{!graphics ? 'Open district archive' : ready ? 'Descend into city' : 'Preparing the world'}<ArrowUpRight size={18} /></button>
        {graphics && <span className="descent-note">Or click the planet to begin your descent.</span>}
      </section>}
      {hub && <nav className="orbital-districts" aria-label="Orbital destinations">{CITY_CATEGORIES.map((c, i) => <button key={c} aria-pressed={c === selected} style={{'--district-accent':CITIES[c].palette.accent} as CSSProperties} onClick={() => useJourney.getState().selectCity(c)}><small>{String(i + 1).padStart(2, '0')}</small><span>{CITIES[c].name.replace(' City', '')}</span><i /></button>)}</nav>}
      {guide && graphics && !exploring && <aside className="flight-school" aria-label="Flight school tutorial" aria-live="polite">
        <div className="flight-school-top"><span><Compass size={14} /> FLIGHT SCHOOL</span><button aria-label="Skip tutorial" onClick={() => useJourney.getState().skipTutorial()}><X size={15} /></button></div>
        <div className="lesson-track">{CHAPTERS.map((name, i) => <span key={name} title={name} data-active={i <= guide.index} />)}</div>
        <p className="lesson-number">{String(guide.index + 1).padStart(2, '0')} / 04 — {CHAPTERS[guide.index]}</p><h3>{guide.title}</h3><p>{guide.text}</p>
        {lesson === 'orbit' && <div className="lesson-controls"><Move size={16} /><span>DRAG TO ORBIT</span><MousePointer2 size={16} /><span>SCROLL TO ZOOM</span><button onClick={() => useJourney.getState().signal('orbit')}>Got it →</button></div>}
        {lesson === 'destination' && !hub && <button className="lesson-action" onClick={() => useUI.getState().setMode('city')}>Return to orbit <ArrowUpRight size={14} /></button>}
        {lesson === 'landmark' && city && <button className="lesson-action" disabled={!ready} onClick={onLandmark}>Frame the landmark <Compass size={14} /></button>}
        {(lesson === 'landmark' || lesson === 'walk') && !city && <button className="lesson-action" onClick={() => { useJourney.setState({lesson:'destination'}); useUI.getState().setMode('city') }}>Choose a district <ArrowUpRight size={14} /></button>}
        {lesson === 'walk' && city && <button className="lesson-action" disabled={!ready} onClick={onWalk}>Enter walking mode <Play size={14} /></button>}
        {lesson === 'complete' && <button className="lesson-action" onClick={() => useJourney.getState().dismiss()}>Start exploring <Check size={14} /></button>}
      </aside>}
    </>}
    {busy && <div className="flight-cinema" data-phase={phase} role="status">
      <div className="flight-letterbox top"><span>REBOOT / TRANSIT SEQUENCE</span><span>{destination && destination in CITIES ? CITIES[destination as CityId].landmark : 'ORBITAL ARCHIVE'}</span></div>
      <div className="flight-caption"><p>{phase === 'loading' ? 'PREPARING DESTINATION' : phase === 'departing' ? 'LEAVING ORBIT' : phase === 'crossing' ? 'CROSSING THE THRESHOLD' : 'WELCOME TO'}</p><h2>{destination && destination in CITIES ? CITIES[destination as CityId].name : 'Reboot Planet'}</h2><div className="flight-sequence"><span data-lit={true} /><span data-lit={phase !== 'loading'} /><span data-lit={phase === 'crossing' || phase === 'arriving'} /><span data-lit={phase === 'arriving'} /></div></div>
      <div className="flight-letterbox bottom"><span>ORBIT → ATMOSPHERE → CITY</span><button onClick={() => useUI.getState().cancelTravel()}>Cancel journey · Esc <X size={13} /></button></div>
    </div>}
  </>
}
