import { beforeEach, describe, expect, it, vi } from 'vitest'
import { useJourney } from './journey'
import { useUI, type TravelPhase } from './ui'
import { CITY_CATEGORIES } from '@/planet/modules/cityworld/cityRegistry'
import { districtAnchor, flightProgress, landingPose, smoother } from '@/planet/modules/cityworld/flightMath'

beforeEach(() => {
  const memory = new Map<string,string>()
  vi.stubGlobal('localStorage', {getItem:(key:string)=>memory.get(key) ?? null, setItem:(key:string,value:string)=>memory.set(key,value)})
  useJourney.setState({introducing:true, introId:0, learned:false, lesson:null, selectedCity:'AI'})
  useUI.setState({mode:'city',cityCategory:null,categoryFilter:null,destination:null,travelPhase:'idle',travelId:0,travelError:null,exploring:false})
})

describe('Second Dawn interactive flight school', () => {
  it('starts on arrival and advances only on the relevant action', () => {
    const journey = useJourney.getState()
    journey.finishEntry()
    expect(useJourney.getState().lesson).toBe('orbit')
    journey.signal('walk')
    expect(useJourney.getState().lesson).toBe('orbit')
    journey.signal('orbit')
    expect(useJourney.getState().lesson).toBe('destination')
    journey.signal('arrival')
    expect(useJourney.getState().lesson).toBe('landmark')
    journey.signal('landmark')
    expect(useJourney.getState().lesson).toBe('walk')
    journey.signal('walk')
    expect(useJourney.getState()).toMatchObject({lesson:'complete',learned:true})
    expect(localStorage.getItem('reboot-second-dawn-tutorial-v1')).toBe('complete')
  })
  it('does not strand users who descend without orbiting first', () => {
    useJourney.getState().finishEntry()
    useJourney.getState().signal('arrival')
    expect(useJourney.getState().lesson).toBe('landmark')
  })
  it('can skip, return without forcing a lesson, and explicitly replay', () => {
    useJourney.getState().skipTutorial()
    useJourney.getState().startEntry()
    useJourney.getState().finishEntry()
    expect(useJourney.getState().lesson).toBeNull()
    useJourney.getState().startTutorial()
    expect(useJourney.getState()).toMatchObject({lesson:'orbit',introducing:false})
  })
  it('works if browser storage is blocked', () => {
    vi.stubGlobal('localStorage', {setItem:()=>{throw new Error('blocked')}})
    expect(() => useJourney.getState().skipTutorial()).not.toThrow()
    expect(useJourney.getState().learned).toBe(true)
  })
})

describe('cinematic camera paths', () => {
  it('clamps progress and eases to rest at both endpoints', () => {
    expect(smoother(-1)).toBe(0)
    expect(smoother(2)).toBe(1)
    expect(smoother(.0001)).toBeLessThan(.00000001)
    expect(1-smoother(.9999)).toBeLessThan(.00000001)
    for(let i=1;i<=100;i++) expect(smoother(i/100)).toBeGreaterThanOrEqual(smoother((i-1)/100))
  })
  it('reduces all flight movement to a short dissolve', () => {
    expect(flightProgress(.18,5.2,true)).toBe(1)
    expect(flightProgress(.18,5.2,false)).toBeLessThan(.01)
  })
  it('gives every city a distinct finite atlas anchor and valid landing pose', () => {
    const positions = CITY_CATEGORIES.map(city=>districtAnchor(city).toArray())
    expect(new Set(positions.map(p=>p.join(','))).size).toBe(CITY_CATEGORIES.length)
    for(const city of CITY_CATEGORIES) {
      const {position,target}=landingPose(city)
      expect(position.distanceTo(target)).toBeGreaterThan(40)
      expect([...position.toArray(),...districtAnchor(city).toArray()].every(Number.isFinite)).toBe(true)
    }
  })
})

describe('readiness-aware navigation state machine', () => {
  it('ignores double-clicks and stale loading completions', () => {
    useUI.getState().enterCity('AI')
    const id=useUI.getState().travelId
    useUI.getState().enterCity('Gaming')
    expect(useUI.getState().destination).toBe('AI')
    useUI.getState().advanceTravel(id+1,'departing')
    expect(useUI.getState().travelPhase).toBe('loading')
    useUI.getState().advanceTravel(id,'arriving')
    expect(useUI.getState().travelPhase).toBe('loading')
  })
  it('only swaps the city behind the crossing veil', () => {
    useUI.getState().enterCity('AI')
    const id=useUI.getState().travelId
    useUI.getState().advanceTravel(id,'departing')
    expect(useUI.getState().cityCategory).toBeNull()
    useUI.getState().advanceTravel(id,'crossing')
    expect(useUI.getState()).toMatchObject({mode:'cityworld',cityCategory:'AI'})
    useUI.getState().advanceTravel(id,'arriving')
    useUI.getState().advanceTravel(id,'idle')
    useUI.getState().exitCity()
    const returnId=useUI.getState().travelId
    for(const phase of ['departing','crossing','arriving','idle'] as TravelPhase[]) useUI.getState().advanceTravel(returnId,phase)
    expect(useUI.getState()).toMatchObject({mode:'city',cityCategory:null,travelPhase:'idle'})
  })
  it.each(['loading','departing','crossing','arriving'] as const)('cancels %s without accepting late callbacks or leaving input locked', phase => {
    useUI.getState().enterCity('Gaming')
    const id=useUI.getState().travelId
    const stages: TravelPhase[]=['loading','departing','crossing','arriving']
    for(const step of stages.slice(1,stages.indexOf(phase)+1)) useUI.getState().advanceTravel(id,step)
    useUI.getState().cancelTravel()
    useUI.getState().advanceTravel(id,'arriving')
    expect(useUI.getState().travelPhase).toBe('idle')
    expect(useUI.getState().destination).toBe(useUI.getState().cityCategory)
    useUI.getState().enterCity('Health')
    expect(useUI.getState().travelPhase).toBe('loading')
  })
  it('blocks walking while the cinematic owns the camera', () => {
    useUI.getState().enterCity('AI')
    useUI.getState().setExploring(true)
    expect(useUI.getState().exploring).toBe(false)
  })
})
