import { useEffect, useState } from 'react'
import { useUI } from '@/planet/stores/ui'
import { explorationInput as input, clearExplorationInput } from './input'
export function ExplorationHUD() {
  const [prompt,setPrompt]=useState('')
  useEffect(()=>{const changed=(event:Event)=>setPrompt((event as CustomEvent<string>).detail);window.addEventListener('reboot-exploration-prompt',changed);return()=>{window.removeEventListener('reboot-exploration-prompt',changed);clearExplorationInput()}},[])
  const hold=(code:string)=>({
    onPointerDown:(e:React.PointerEvent<HTMLButtonElement>)=>{e.currentTarget.setPointerCapture(e.pointerId);input.keys.add(code)},
    onPointerUp:()=>input.keys.delete(code),onPointerCancel:()=>input.keys.delete(code),onLostPointerCapture:()=>input.keys.delete(code),onBlur:()=>input.keys.delete(code),
    onKeyDown:(e:React.KeyboardEvent<HTMLButtonElement>)=>{if(e.code==='Space'||e.code==='Enter'){e.preventDefault();input.keys.add(code)}},
    onKeyUp:(e:React.KeyboardEvent<HTMLButtonElement>)=>{if(e.code==='Space'||e.code==='Enter'){e.preventDefault();input.keys.delete(code)}},
  })
  return <section className="exploration-hud" aria-label="Exploration controls">
    <button className="exploration-exit" onClick={()=>useUI.getState().setExploring(false)}>Return to Overview · Esc</button>
    <p className="exploration-help">WASD / arrows · Walk <span>Shift · Sprint</span> Space · Jump <span>Drag · Look</span> Scroll · Zoom</p>
    {prompt&&<button className="exploration-prompt" onClick={()=>{input.interact=true}}>{prompt==='Low gravity · longer jumps'?prompt:`E · ${prompt}`}</button>}
    <div className="touch-movement"><button aria-label="Walk forward" {...hold('KeyW')}>↑</button><div><button aria-label="Walk left" {...hold('KeyA')}>←</button><button aria-label="Walk backward" {...hold('KeyS')}>↓</button><button aria-label="Walk right" {...hold('KeyD')}>→</button></div></div>
    <button className="touch-jump" onClick={()=>{input.jump=true}}>Jump</button>
  </section>
}
