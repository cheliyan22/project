import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { CITIES, type CityId } from '../cityRegistry'
import { seeded } from '../cities/cityKit'
import { Architecture, Parts, useEnvironment } from './ScenePrimitives'
import { terrain } from './DistrictTerrain'
import { DistrictDetails } from './DistrictIdentity'

/** Terrain and walking surfaces stay separate from the authored scenic skyline. */
function makeTerrain(city: CityId) {
  const a = new Architecture()
  terrain(a,city)
  return a
}
export function CityEnvironment({city}: {city:CityId}) {
  const data=useMemo(()=>makeTerrain(city),[city])
  return <><Parts solid data={data} name={`${city}-terrain`} /><DistrictDetails city={city}/><Atmosphere city={city} /></>
}

const WEATHER:Record<CityId,{size:number;opacity:number;vertical:number}>= {
  Graveyard:{size:.11,opacity:.4,vertical:42},IdeaHub:{size:.08,opacity:.38,vertical:30},Legend:{size:.07,opacity:.35,vertical:34},
  AI:{size:.09,opacity:.5,vertical:50},Gaming:{size:.12,opacity:.48,vertical:38},Education:{size:.13,opacity:.4,vertical:34},
  Health:{size:.1,opacity:.35,vertical:28},Creator:{size:.12,opacity:.45,vertical:45},Space:{size:.14,opacity:.65,vertical:70},
  Robotics:{size:.09,opacity:.38,vertical:38},Community:{size:.12,opacity:.42,vertical:30},
}
function Atmosphere({city}: {city:CityId}) {
  const {lowEffects,reduced}=useEnvironment()
  const ref=useRef<THREE.Points>(null),weather=WEATHER[city]
  const positions=useMemo(()=>{
    const count=lowEffects?36:180,values=new Float32Array(count*3)
    for(let i=0;i<count;i++) {
      values[i*3]=(seeded(city,i+801)-.5)*150
      values[i*3+1]=seeded(city,i+1103)*weather.vertical
      values[i*3+2]=(seeded(city,i+1409)-.5)*150
    }
    return values
  },[city,lowEffects,weather.vertical])
  useFrame((state,delta)=>{
    if(!ref.current||reduced||lowEffects)return
    ref.current.rotation.y+=Math.min(delta,.1)*(city==='Space'?.002:.006)
    if(city==='Community'||city==='Education'||city==='Graveyard')ref.current.position.y=Math.sin(state.clock.elapsedTime*.08)*1.5
  })
  return <group name={`${city}-atmosphere`}>
    <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" args={[positions,3]} /></bufferGeometry><pointsMaterial color={CITIES[city].palette.secondary} size={weather.size} transparent opacity={weather.opacity} depthWrite={false} sizeAttenuation /></points>
    {!lowEffects&&!['Space','AI'].includes(city)&&[0,1].map(i=><mesh key={i} position={[0,.5+i*.5,-22-i*20]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[130,35]} /><meshBasicMaterial color={CITIES[city].environment.bg} transparent opacity={.07} depthWrite={false} side={THREE.DoubleSide} /></mesh>)}
  </group>
}
