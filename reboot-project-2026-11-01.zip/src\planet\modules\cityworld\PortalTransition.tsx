import { useLayoutEffect, useMemo, useRef, type RefObject } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { useUI } from '@/planet/stores/ui'
import { useJourney } from '@/planet/stores/journey'
import { isCityId } from './cityRegistry'
import type { ProjectCategory } from '@/planet/types/project'
import { districtAnchor, FLIGHT_SECONDS, flightProgress, landingPose } from './flightMath'

export function viewFor(city: ProjectCategory | null, worlds: boolean) {
  if (!city && worlds) return { position: new THREE.Vector3(0, 34, 138), target: new THREE.Vector3() }
  return landingPose(city && isCityId(city) ? city : null)
}

/** Sole camera owner during travel. Destination mounts behind an opaque veil and
 * only reveals once the scene has committed frames. No controls run concurrently. */
export function PortalTransition({ color, reduced, ready, veil }: {
  color: string; reduced: boolean; lowEffects: boolean; ready: boolean; veil: RefObject<HTMLDivElement>
}) {
  const camera = useThree(s => s.camera) as THREE.PerspectiveCamera
  const phase = useUI(s => s.travelPhase)
  const id = useUI(s => s.travelId)
  const category = useUI(s => s.cityCategory)
  const destination = useUI(s => s.destination)
  const mode = useUI(s => s.mode)
  const elapsed = useRef(0)
  const path = useMemo(() => new THREE.CubicBezierCurve3(), [])
  const fromLook = useMemo(() => new THREE.Vector3(), [])
  const target = useMemo(() => new THREE.Vector3(), [])
  const look = useMemo(() => new THREE.Vector3(), [])
  const direction = useMemo(() => new THREE.Vector3(), [])
  useLayoutEffect(() => {
    elapsed.current = 0
    if (phase === 'departing') {
      path.v0.copy(camera.position)
      camera.getWorldDirection(direction)
      fromLook.copy(camera.position).addScaledVector(direction, 60)
      if (!category && destination && isCityId(destination)) {
        const anchor = districtAnchor(destination)
        const normal = anchor.clone().sub(new THREE.Vector3(12, 0, 0)).normalize()
        path.v1.copy(camera.position).multiplyScalar(.95).add(new THREE.Vector3(0, 12, 0))
        path.v2.copy(anchor).addScaledVector(normal, 35)
        path.v3.copy(anchor).addScaledVector(normal, 7)
        target.copy(anchor)
      } else {
        path.v1.copy(camera.position).add(new THREE.Vector3(0, 28, 10))
        path.v2.set(-22, 105, 80)
        path.v3.set(-35, 175, 50)
        target.set(0, 0, 0)
      }
    }
    if (phase === 'crossing' && veil.current) veil.current.style.opacity = '1'
    if (phase === 'arriving') {
      const pose = viewFor(category, mode === 'worlds')
      path.v0.set(...(category ? [-64, 110, 128] : [-58, 58, 154]) as [number, number, number])
      path.v1.set(...(category ? [-62, 70, 107] : [-32, 44, 141]) as [number, number, number])
      path.v2.set(...(category ? [44, 45, 95] : [0, 24, 128]) as [number, number, number])
      path.v3.copy(pose.position)
      fromLook.set(0, category ? 15 : 0, 0)
      target.copy(pose.target)
      camera.position.copy(reduced ? pose.position : path.v0)
      camera.lookAt(target)
    }
    if (phase === 'idle' && !useUI.getState().exploring) {
      const pose = viewFor(category, mode === 'worlds')
      // The finished path and the control target are identical: no end-of-flight snap.
      camera.position.copy(pose.position)
      camera.lookAt(pose.target)
      camera.fov = 50
      camera.updateProjectionMatrix()
      if (veil.current) veil.current.style.opacity = '0'
    }
  }, [phase, id, camera, category, destination, mode, reduced, path, fromLook, target, direction, veil])
  useLayoutEffect(() => () => {
    if (veil.current) veil.current.style.opacity = '0'
    camera.fov = 50; camera.updateProjectionMatrix()
  }, [camera, veil])
  useFrame((_, delta) => {
    const state = useUI.getState()
    if (state.travelId !== id || phase === 'idle' || phase === 'loading') return
    // Flight duration follows elapsed time, not frame count, even on slow GPUs.
    elapsed.current += Math.max(0, delta)
    let opacity = 0
    if (phase === 'departing') {
      const t = flightProgress(elapsed.current, FLIGHT_SECONDS.departing, reduced)
      if (!reduced) {
        path.getPoint(t, camera.position)
        look.lerpVectors(fromLook, target, t)
        camera.lookAt(look)
        camera.fov = 50 + Math.sin(t * Math.PI) * 7
        camera.updateProjectionMatrix()
      }
      opacity = reduced ? t : Math.max(0, (t - .66) / .34)
      // Apply the veil before swapping scene state.
      if (veil.current) veil.current.style.opacity = String(opacity)
      if (t === 1) state.advanceTravel(id, 'crossing')
    } else if (phase === 'crossing') {
      opacity = 1
      if (ready && elapsed.current >= (reduced ? .05 : FLIGHT_SECONDS.crossing)) state.advanceTravel(id, 'arriving')
    } else if (phase === 'arriving') {
      const t = flightProgress(elapsed.current, FLIGHT_SECONDS.arriving, reduced)
      if (!reduced) {
        path.getPoint(t, camera.position)
        look.lerpVectors(fromLook, target, t)
        camera.lookAt(look)
      }
      camera.fov = 50; camera.updateProjectionMatrix()
      opacity = Math.max(0, 1 - t * 6)
      if (t === 1) { state.advanceTravel(id, 'idle'); if (category) useJourney.getState().signal('arrival') }
    }
    if (veil.current) {
      veil.current.style.opacity = String(opacity)
      veil.current.style.setProperty('--flight-color', color)
    }
  })
  return null
}
