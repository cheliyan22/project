import { useEffect, useState } from 'react'
import { useThree } from '@react-three/fiber'
import { Physics, RigidBody, TrimeshCollider } from '@react-three/rapier'
import type { CityId } from '../cityRegistry'
import { bakeCollisionGeometry } from './collisionGeometry'
import { Player } from './Player'
import { useUI } from '@/planet/stores/ui'

/** Collision is compiled after the city's lazy scene has mounted, only for the active world. */
export default function Exploration({city,paused,reduced,collisionRevision}: {city:CityId;paused:boolean;reduced:boolean;collisionRevision:string}) {
  const [hidden,setHidden]=useState(()=>document.hidden)
  useEffect(()=>{const changed=()=>setHidden(document.hidden);document.addEventListener('visibilitychange',changed);return()=>document.removeEventListener('visibilitychange',changed)},[])
  const scene=useThree(s=>s.scene),[collision,setCollision]=useState<ReturnType<typeof bakeCollisionGeometry>|null>(null)
  useEffect(()=>{
    let timer=0
    const deadline=performance.now()+15000
    const initialize=()=>{
      const root=scene.getObjectByName(`${city}-district`)
      if(root){
        const geometry=bakeCollisionGeometry(root)
        if(geometry.indices.length){setCollision(geometry);return}
      }
      if(performance.now()>=deadline){
        useUI.getState().setExploring(false)
        useUI.getState().cancelTravel('Walkable surfaces could not load. Try Explore World again, or choose another city.')
        return
      }
      timer=window.setTimeout(initialize,100)
    }
    initialize()
    return()=>clearTimeout(timer)
  },[city,scene,collisionRevision])
  if(!collision)return null
  return <Physics timeStep={1/60} gravity={[0,-22,0]} paused={hidden}>
    <RigidBody type="fixed" colliders={false}><TrimeshCollider args={[collision.vertices,collision.indices]}/></RigidBody>
    {(city==='IdeaHub'||city==='Robotics')&&<RigidBody position={[1.6,1,40]} colliders="cuboid" mass={8} linearDamping={4} angularDamping={4} restitution={.05}><mesh><boxGeometry args={[.8,.8,.8]}/><meshStandardMaterial color="#b79066" roughness={.7}/></mesh></RigidBody>}
    <Player city={city} paused={paused} reduced={reduced}/>
  </Physics>
}
