import { create } from 'zustand'
import type { CityId } from '@/planet/modules/cityworld/cityRegistry'

export type Lesson = 'orbit' | 'destination' | 'landmark' | 'walk' | 'complete'
const TUTORIAL_KEY = 'reboot-second-dawn-tutorial-v1'
function hasLearned() {
  try { return localStorage.getItem(TUTORIAL_KEY) === 'complete' } catch { return false }
}
function remember() {
  try { localStorage.setItem(TUTORIAL_KEY, 'complete') } catch { /* Session still works without storage. */ }
}
interface JourneyState {
  introducing: boolean
  introId: number
  selectedCity: CityId
  lesson: Lesson | null
  learned: boolean
  startEntry: () => void
  finishEntry: () => void
  selectCity: (city: CityId) => void
  startTutorial: () => void
  skipTutorial: () => void
  signal: (event: 'orbit' | 'arrival' | 'landmark' | 'walk') => void
  dismiss: () => void
}
export const useJourney = create<JourneyState>((set, get) => ({
  introducing: true, introId: 0, selectedCity: 'AI', lesson: null, learned: hasLearned(),
  startEntry: () => set(s => ({ introducing: true, introId: s.introId + 1, lesson: null })),
  finishEntry: () => set(s => ({ introducing: false, lesson: s.learned ? null : 'orbit' })),
  selectCity: selectedCity => set({ selectedCity }),
  startTutorial: () => set({ introducing: false, lesson: 'orbit' }),
  skipTutorial: () => { remember(); set({ lesson: null, learned: true }) },
  signal: event => {
    const lesson = get().lesson
    if (event === 'orbit' && lesson === 'orbit') set({ lesson: 'destination' })
    // Choosing a destination before orbiting is allowed; don't strand the tutorial.
    if (event === 'arrival' && (lesson === 'destination' || lesson === 'orbit')) set({ lesson: 'landmark' })
    if (event === 'landmark' && lesson === 'landmark') set({ lesson: 'walk' })
    if (event === 'walk' && lesson === 'walk') { remember(); set({ lesson: 'complete', learned: true }) }
  },
  dismiss: () => set({ lesson: null }),
}))
