import type { CityId } from '@/planet/modules/cityworld/cityRegistry'
import type { Vec } from '@/planet/modules/cityworld/environment/ScenePrimitives'

export type TerrainKind = 'crater' | 'canyon' | 'cliff' | 'plate' | 'cascade' | 'grove' | 'tidal' | 'void' | 'shelf' | 'trench' | 'hill'

export type MotionKind = 'ash' | 'sparks' | 'cloudsea' | 'pulse' | 'coins' | 'pages' | 'mist' | 'fragments' | 'starlight' | 'forge' | 'lanterns'

export interface WorldPalette {
  /** Ground and mass colour. */
  base: string
  /** Secondary mass, roofs, plinths. */
  mass: string
  /** Structural metal, timber, brass. */
  trim: string
  /** The city's single signal colour. */
  accent: string
  secondary: string
  /** Emissive colour for lit openings. */
  glow: string
}

export interface WorldProfile {
  id: CityId
  terrain: TerrainKind
  sky: {
    top: string
    horizon: string
    ground: string
    sun: string
    sunDir: Vec
    night: boolean
    stars: number
    clouds: number
    haze: number
  }
  light: {
    key: string
    keyIntensity: number
    keyFrom: Vec
    fill: string
    fillIntensity: number
    ambient: string
    ambientIntensity: number
    shadows: boolean
  }
  palette: WorldPalette
  atmosphere: {
    fog: string
    fogDensity: number
    mistColor: string
    mistOpacity: number
    motion: MotionKind
    shafts: number
  }
  fabric: {
    /** Average height multiplier for ambient architecture. */
    density: number
    height: number
    spread: number
  }
}
