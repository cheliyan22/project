import { useEffect, useMemo } from 'react'
import * as THREE from 'three'
import { CITIES, type CityId } from '../cityRegistry'
import { Architecture, Motion, Parts, useEnvironment, type Vec } from './ScenePrimitives'
import type { Finish } from './SurfaceMaterials'

const V=(x:number,y:number,z:number):Vec=>[x,y,z]
function arch(a:Architecture,x:number,z:number,r:number,spring:number,color:string,width=.42,finish:Finish='stone',start=0,end=Math.PI) {
  for(const side of [-1,1])a.beam(V(x+side*r,0,z),V(x+side*r,spring,z),width,color,false,finish)
  const steps=Math.max(8,Math.ceil(r*2.4))
  for(let i=0;i<steps;i++) {
    const t=start+(end-start)*i/steps,u=start+(end-start)*(i+1)/steps
    a.beam(V(x+Math.cos(t)*r,spring+Math.sin(t)*r,z),V(x+Math.cos(u)*r,spring+Math.sin(u)*r,z),width,color,false,finish)
  }
}
function truss(a:Architecture,from:Vec,to:Vec,width:number,color:string) {
  a.beam(from,to,width,color,false,'metal')
  const start=new THREE.Vector3(...from),end=new THREE.Vector3(...to),length=start.distanceTo(end),steps=Math.max(2,Math.floor(length/3))
  for(let i=0;i<steps;i++) {
    const p=start.clone().lerp(end,i/steps),q=start.clone().lerp(end,(i+1)/steps)
    a.beam(V(p.x,p.y-.75,p.z),V(q.x,q.y+.75,q.z),width*.35,color,false,'metal')
  }
}
function domeRibs(a:Architecture,x:number,z:number,r:number,h:number,color:string,count=10) {
  for(let i=0;i<count;i++) {
    const angle=i*Math.PI/count
    for(let j=0;j<10;j++) {
      const t=j*Math.PI/10,u=(j+1)*Math.PI/10
      a.beam(V(x+Math.cos(angle)*Math.cos(t)*r,Math.sin(t)*h,z+Math.sin(angle)*Math.cos(t)*r),V(x+Math.cos(angle)*Math.cos(u)*r,Math.sin(u)*h,z+Math.sin(angle)*Math.cos(u)*r),.12,color,false,'metal')
    }
  }
  a.ring([x,.15,z],r,color,undefined,false)
}
function tree(a:Architecture,d:Architecture,x:number,z:number,size:number,low:boolean,colors=['#54866a','#82a36d','#abc183']) {
  a.add('pillar',[x,size*.4,z],[.18,size*.8,.18],'#78644e',undefined,false,'wood')
  for(let i=0;i<(low?3:7);i++) {
    const angle=i*2.4,r=i?size*.24:0
    d.add('orb',[x+Math.cos(angle)*r,size*.82+Math.sin(i)*size*.12,z+Math.sin(angle)*r],[size*.34,size*.28,size*.32],colors[i%colors.length],undefined,false,'foliage')
  }
}
function stairs(a:Architecture,x:number,z:number,w:number,count:number,color:string,reverse=false) {
  for(let i=0;i<count;i++)a.box([x,.12+i*.22,z+(reverse?-1:1)*i*.85],[w,.24,1],color)
}
function lamp(a:Architecture,x:number,z:number,color:string,h=3) {
  a.beam(V(x,0,z),V(x,h,z),.1,'#526574',false,'metal')
  a.add('orb',[x,h,z],[.18,.24,.18],color,undefined,true)
}
function books(d:Architecture,x:number,y:number,z:number,count:number,axis:'x'|'z'='x') {
  const colors=['#d4b579','#659d98','#a66f76','#738da9','#c5c0a1']
  for(let i=0;i<count;i++)d.box([x+(axis==='x'?i*.43:0),y+(i%4)*.025,z+(axis==='z'?i*.43:0)],[axis==='x'?.32:.7,.85,axis==='z'?.32:.7],colors[i%colors.length],[0,0,(i%5-2)*.035],false,'wood')
}
function solar(d:Architecture,x:number,y:number,z:number,w:number,h:number,angle=0) {
  d.box([x,y,z],[w,.15,h],'#294b79',[.18,angle,0],false,'metal')
  for(let i=0;i<6;i++)d.box([x+(i-2.5)*w/6,y+.1,z],[.035,.025,h*.96],'#94b5cf',[.18,angle,0])
  for(let i=0;i<4;i++)d.box([x,y+.11,z+(i-1.5)*h/4],[w*.98,.025,.035],'#94b5cf',[.18,angle,0])
}
function deadTree(a:Architecture,x:number,z:number,h:number) {
  a.beam(V(x,0,z),V(x+.4,h,z),.28,'#494351',false,'wood')
  for(const side of [-1,1]) {
    a.beam(V(x+.2,h*.48,z),V(x+side*h*.3,h*.72,z+.4),.16,'#514859',false,'wood')
    a.beam(V(x+side*h*.3,h*.72,z+.4),V(x+side*h*.42,h*.9,z-.3),.09,'#514859',false,'wood')
  }
}
function arcade(a:Architecture,d:Architecture,x:number,z:number,color:string,accent:string,turn=0) {
  a.box([x,3,z],[4,6,3.2],color,[0,turn,0],false,'metal')
  a.box([x,6.4,z-.3],[4.4,1.2,3.8],accent,[0,turn,0],false,'ceramic')
  a.box([x,4.35,z+1.65],[3.2,2.2,.12],'#142338',[-.12,turn,0],false,'ceramic')
  d.box([x,4.4,z+1.73],[2.7,1.65,.03],accent,[-.12,turn,0],true)
  a.box([x,2.6,z+2],[4,.35,1.8],color,[.15,turn,0],false,'metal')
  a.add('pillar',[x-.9,3,z+2],[.1,.7,.1],'#b7c0bd',undefined,false,'metal')
  d.add('orb',[x-.9,3.4,z+2],[.24,.24,.24],'#f06c75')
  for(const dx of [.35,1])d.add('orb',[x+dx,2.9,z+2.15],[.16,.08,.16],dx>.5?'#f3c76e':'#75d6c2')
}
function house(a:Architecture,d:Architecture,x:number,z:number,w:number,h:number,color:string,roof:string) {
  a.box([x,h/2,z],[w,h,w*.75],color)
  for(const side of [-1,1])a.box([x+side*w*.26,h+.7,z],[w*.58,.28,w*.85],roof,[0,0,-side*.48],false,'ceramic')
  a.box([x,h*.33,z+w*.38],[1.1,h*.66,.15],'#40585b',undefined,false,'wood')
  for(const dx of [-w*.28,w*.28]) {
    d.box([x+dx,h*.62,z+w*.39],[1.15,1.3,.08],'#f3cc8d',undefined,true)
    d.box([x+dx,h*.62,z+w*.43],[.08,1.4,.08],roof,undefined,false,'wood')
  }
  a.box([x,h+.1,z+w*.45],[w*.8,.2,1.4],roof,undefined,false,'wood')
}

/** Authored district scenery. It never represents projects, residents or live activity. */
export function districtArchitecture(city:CityId,low:boolean) {
  const solid=new Architecture(),detail=new Architecture(),a=solid,d=detail,p=CITIES[city].palette
  switch(city) {
    case 'AI': {
      // Server cloisters read as infrastructure, with fiber canals converging on the Core.
      for(const [x,z] of [[-30,8],[29,4],[-22,-34],[25,-32]]) {
        a.add('hex',[x,.35,z],[8,.7,8],'#29495d',undefined,false,'metal')
        for(let i=0;i<5;i++) {
          const dx=x+(i-2)*2.5,h=7+(i%3)*3
          a.box([dx,h/2,z-3],[1.5,h,3.4],i%2?'#32566c':'#213c52',undefined,false,'metal')
          for(let j=0;j<5;j++)d.box([dx,1+j*1.1,z-1.27],[1.05,.12,.04],j===i%5?'#e2b877':p.accent,undefined,true)
          d.beam(V(dx,h,z-3),V(dx,h+1.8,z-3),.08,p.secondary,true)
        }
        for(const side of [-1,1])arch(a,x,z+side*5,7,2,'#6192a8',.22,'metal')
        d.beam(V(x,.12,z+6),V(x*.25,.12,z*.25),.14,p.accent,true)
      }
      for(const [x,z,h] of [[-52,-42,25],[0,-64,34],[52,-44,28]] as const) {
        for(let i=0;i<4;i++)a.add('hex',[x,2+i*4,z],[5-i*.6,3.4,5-i*.6],i%2?'#294d66':'#39677c',[0,i*.18,0],false,'metal')
        for(let i=0;i<3;i++){const t=i*Math.PI*2/3;a.beam(V(x+Math.cos(t)*7,0,z+Math.sin(t)*7),V(x+Math.cos(t)*3,h,z+Math.sin(t)*3),.35,'#568ca1',false,'metal')}
        a.add('orb',[x,h,z],[2,2,2],'#72c9d8');d.ring([x,h,z],4,p.accent,[.4,.2,0])
      }
      for(let i=0;i<10;i++)lamp(d,i%2?-5:5,16+i*4,p.accent,2.5)
      break
    }
    case 'Gaming': {
      // An arcade boulevard, a racing bowl and a chunky fantasy gate form three distinct silhouettes.
      arcade(a,d,-31,7,'#56436f','#f1a75b',.12);arcade(a,d,-25,10,'#38637a','#79d4ca',-.12)
      arcade(a,d,30,3,'#693f67','#d97a9f',-.15);arcade(a,d,24,7,'#47588a','#e7c46e',.15)
      for(const [x,z] of [[-30,8],[29,4]] as const)for(let i=0;i<4;i++) {
        a.box([x-6+i*4,.25,z+7],[3.6,.5,3.6],i%2?'#4f3b6c':'#31526c')
        d.box([x-6+i*4,.53,z+7],[2.8,.04,.15],i%2?p.secondary:p.accent,undefined,true)
      }
      // Racing circuit with banked checkpoints and blocky grandstands.
      a.add('pillar',[-22,.2,-34],[14,.4,14],'#252b43');d.ring([-22,.48,-34],11,'#c9b58b',undefined,false)
      d.ring([-22,.5,-34],7,'#6b527d',undefined,false)
      for(let i=0;i<18;i++){const t=i*Math.PI/9;d.box([-22+Math.cos(t)*9,.54,-34+Math.sin(t)*9],[1.4,.04,.22],i%2?'#e5d4ad':'#514163',[0,-t,0])}
      for(let row=0;row<4;row++)for(let i=0;i<7;i++)a.box([-31+i*2.7,.45+row*.55,-47-row],[2.4,.5,1.6],['#745582','#47768a','#b88465'][row%3])
      arch(a,-22,-34,4,1,p.secondary,.45,'ceramic')
      // Fantasy arena: asymmetric pixel cliffs, banners and a gateway rather than another tower.
      for(let i=0;i<9;i++) {
        const x=18+(i%3)*4,z=-39+Math.floor(i/3)*4,h=3+(i*7)%8
        a.box([x,h/2,z],[4,h,4],['#65517c','#3f5c77','#87636f'][i%3])
        d.box([x,h+.12,z],[4.1,.22,4.1],i%2?'#b68d75':'#718eaa')
      }
      for(const x of [20,31])a.box([x,7,-27],[2,14,2],'#74517e')
      a.box([25.5,13,-27],[13,2,2.4],'#d3a164')
      for(let i=0;i<7;i++)d.box([20+i*1.8,13,-25.75],[.85,.75,.05],i%2?p.secondary:p.accent,undefined,true)
      for(const [x,z,h] of [[-52,-40,13],[2,-65,19],[53,-43,16]] as const) {
        for(let i=0;i<5;i++)a.box([x+(i%2)*1.2,1.5+i*2.3,z],[8-i,3,8-i],i%2?'#514477':'#355b76')
        d.add('rock',[x,h,z],[1.4,1.8,1.4],p.accent,undefined,true)
      }
      for(let i=0;i<12;i++)d.box([-4+i%2*8,.15,17+i*3],[1.2,.05,.35],i%3?p.secondary:p.accent,[0,i*.4,0],true)
      break
    }
    case 'Education': {
      // Crescent libraries and reading gardens frame the Knowledge Tree.
      for(const [x,z] of [[-30,8],[29,4]] as const) {
        for(let k=0;k<3;k++)arch(a,x,z-5+k*4,7,5,'#b9b394',.4,'stone')
        a.box([x,10,z-1],[15,.45,11],'#728b83')
        for(const side of [-1,1])for(let level=0;level<4;level++) {
          a.box([x+side*6,1+level*1.8,z-1],[.8,.18,9],'#a78d65',undefined,false,'wood')
          books(d,x+side*6,1.5+level*1.8,z-5,15,'z')
        }
        stairs(a,x,z+8,8,5,'#bcb59a',true)
        tree(a,d,x+9,z+5,6,low)
      }
      // Observatory and open-book lecture pavilion.
      a.add('pillar',[-22,2,-34],[8,4,8],'#66847f');domeRibs(a,-22,-34,8,7,'#d0c5a3',8)
      a.add('pillar',[25,.4,-32],[11,.8,11],'#71877d')
      for(const side of [-1,1]) {
        a.box([25+side*5,5,-32],[10,.45,12],'#d0bd93',[0,0,side*.25],false,'wood')
        for(let i=0;i<7;i++)d.box([25+side*(1+i*1.3),5.3+Math.abs(i-3)*.28,-32],[.05,.03,11],'#927f66',[0,0,side*.25])
      }
      for(const [x,z] of [[-52,-43],[0,-65],[52,-43]] as const) {
        a.add('pillar',[x,6,z],[4,12,4],'#56766f')
        for(let i=0;i<5;i++){a.ring([x,4+i*2.3,z],5-i*.4,i%2?'#baa77f':'#72998e',undefined,false);books(d,x-3,4.5+i*2.3,z+3,12)}
        a.add('orb',[x,15,z],[5,2,5],'#9aaf91',undefined,false,'foliage')
      }
      for(const x of [-7,7])for(let i=0;i<6;i++)tree(a,d,x,17+i*6,3.8,low)
      break
    }
    case 'Health': {
      // A chain of translucent growing houses, medicinal beds and shallow water channels.
      for(const [x,z,r] of [[-30,8,9],[29,4,10],[-22,-34,8],[25,-32,9]] as const) {
        a.add('pillar',[x,.25,z],[r,.5,r],'#85a996');domeRibs(a,x,z,r,r*.75,'#d4e3d4',low?6:10)
        for(let i=0;i<4;i++) {
          const angle=i*Math.PI/2+.4,tx=x+Math.cos(angle)*r*.55,tz=z+Math.sin(angle)*r*.55
          a.box([tx,.45,tz],[2.6,.9,4],'#a9bda6',[0,-angle,0])
          tree(a,d,tx,tz,3.8,low,['#4f9b7b','#78bd93','#b4d3a3'])
        }
        a.ring([x,.5,z],r*.85,'#b8d8c8',undefined,false)
      }
      for(const side of [-1,1]) {
        a.box([side*8,-.05,25],[4,.2,40],'#4b8c91')
        for(let i=0;i<8;i++)a.box([side*8,.15,10+i*5],[4.6,.25,.5],'#c5d8c5')
      }
      for(const [x,z] of [[-52,-42],[0,-65],[52,-43]] as const) {
        for(let i=0;i<5;i++)a.add('orb',[x+(i-2)*3,3+i%2*2,z],[4,5,4],i%2?'#71a88d':'#9bc1a6',undefined,false,'ceramic')
        a.add('orb',[x,10,z],[8,2.5,7],'#7db397',undefined,false,'foliage')
      }
      break
    }
    case 'Creator': {
      // Suspended studios and impossible stairs deliberately ignore ordinary building grammar.
      for(const [x,z,sign] of [[-30,8,-1],[29,4,1],[-22,-34,-1],[25,-32,1]] as const) {
        for(const dx of [-6,6])a.beam(V(x+dx,0,z),V(x+dx+sign*2,15,z),.45,'#c2a789',false,'metal')
        truss(a,V(x-8,15,z),V(x+8,17,z),.5,'#c2a789')
        a.box([x,11,z],[13,.5,9],'#665579',[0,sign*.2,sign*.1])
        for(let i=0;i<5;i++) {
          const color=['#d17c9e','#6f9fc0','#deb879','#7bb5a6','#a68bbb'][i]
          a.box([x-5+i*2.5,14+Math.sin(i)*1.5,z],[2.1,6,.22],color,[0,sign*.35,(i-2)*.08],false,'ceramic')
          d.box([x-5+i*2.5,14+Math.sin(i)*1.5,z+.14],[1.5,.15,.03],'#f0d6b0',[0,sign*.35,(i-2)*.08],true)
        }
        for(let i=0;i<8;i++)a.box([x+sign*(7+i*.6),.3+i*.65,z+7-i*.6],[4,.3,1.2],i%2?'#8d7196':'#668da4',[0,i*.08,0])
      }
      for(const [x,z] of [[-52,-43],[0,-65],[52,-43]] as const) {
        a.add('rock',[x,8,z],[7,11,5],'#675279',[.3,.5,.2])
        a.ring([x,16,z],8,'#bf91b2',[.4,.3,.6],false)
        a.box([x+6,12,z],[10,.5,8],'#7694ae',[.2,.4,.3])
      }
      break
    }
    case 'IdeaHub': {
      // The district visibly progresses from exposed ruins to copper-frame restoration.
      for(const [x,z,restored] of [[-30,8,false],[29,4,true],[-22,-34,false],[25,-32,true]] as const) {
        a.box([x,.3,z],[17,.6,15],restored?'#5d7e77':'#5c514f')
        for(const dx of [-7,7])for(const dz of [-6,6]) {
          const h=restored?13:5+(dx+dz+20)%7
          a.beam(V(x+dx,0,z+dz),V(x+dx,h,z+dz),.3,'#c49667',false,'metal')
          if(restored)a.beam(V(x+dx,h,z+dz),V(x-dx,h,z+dz),.28,'#c49667',false,'metal')
        }
        if(restored) {
          a.box([x,12.8,z],[15,.45,13],'#699c91',undefined,false,'metal')
          for(let i=0;i<4;i++)a.box([x-5+i*3.3,4,z-5],[2.4,7,.3],i%2?'#80b5a5':'#496d6c')
          truss(a,V(x-9,16,z-5),V(x+9,16,z-5),.45,'#d0a06c')
          a.beam(V(x+6,16,z-5),V(x+6,7,z-5),.08,'#d4d6c7',false,'metal')
          d.box([x+6,6.5,z-5],[2,.7,2],p.accent,undefined,true)
        } else {
          for(let i=0;i<5;i++)a.box([x-5+i*2,1+i%3,z],[3,.6,5],i%2?'#79655b':'#4e6265',[.1,i*.3,(i-2)*.12])
          a.beam(V(x-7,2,z-6),V(x+5,9,z+4),.25,'#937461',false,'metal')
        }
        for(let i=0;i<4;i++)a.box([x-6+i*4,.7,z+7],[2.4,1.4,2],restored?'#82b3a2':'#8c715d',undefined,false,'wood')
      }
      truss(a,V(-22,5,-25),V(25,5,-23),.8,'#859f98')
      for(const [x,z] of [[-52,-42],[0,-65],[52,-43]] as const) {
        for(let i=0;i<4;i++)a.box([x,2+i*4,z],[10-i*1.4,.6,9-i],i<2?'#725c55':'#69a395',[0,0,(i-1)*.06])
        for(const side of [-1,1])a.beam(V(x+side*6,0,z),V(x+side*4,20,z),.35,'#c39767',false,'metal')
        a.add('orb',[x,20,z],[2,2,2],p.accent,undefined,true)
      }
      break
    }
    case 'Graveyard': {
      // Broken cloisters and memorial gardens replace intact generic towers.
      for(const [x,z] of [[-30,8],[29,4],[-22,-34],[25,-32]] as const) {
        for(let i=0;i<4;i++) {
          const h=4+(i*5)%8
          arch(a,x-6+i*4,z,2,h,'#676777',.35,'stone',0,Math.PI*(i%2?.62:1))
          a.box([x-6+i*4,.35,z+5],[2.8,.7,4],'#514b5d',[.1,i*.4,(i-2)*.1])
        }
        a.box([x,3,z-5],[13,6,.7],'#3f4655',[0,0,.12])
        for(let i=0;i<6;i++)d.box([x-5+i*2,3.2,z-4.6],[.3,1.5,.08],i%2?'#8e5d6b':'#545d71',undefined,i%2===0)
        deadTree(a,x+8,z+5,7)
        for(const dx of [-5,5])lamp(d,x+dx,z+6,'#cf716e',1.4)
      }
      for(const [x,z,h] of [[-52,-42,22],[0,-65,28],[52,-43,24]] as const) {
        for(const side of [-1,1])a.beam(V(x+side*6,0,z),V(x+side*4,h,z),.7,'#56586a',false,'stone')
        for(let i=0;i<4;i++)a.box([x,3+i*5,z],[12-i*1.5,.6,8],i%2?'#3f4152':'#5b5263',[0,0,(i-2)*.1])
        a.box([x+3,h,z],[5,9,4],'#4c4a5d',[0,0,-.4])
      }
      break
    }
    case 'Legend': {
      // Civic palace wings, long colonnades and ceremonial gardens make a monumental district.
      for(const [x,z] of [[-30,8],[29,4],[-22,-34],[25,-32]] as const) {
        a.box([x,.4,z],[20,.8,16],'#aaa996')
        for(let i=0;i<6;i++)for(const side of [-1,1]) {
          a.add('pillar',[x-8+i*3.2,4.5,z+side*6],[.42,9,.42],'#ddd3b8',undefined,false,'stone')
          a.add('pillar',[x-8+i*3.2,9,z+side*6],[.7,.35,.7],'#c2a16e')
        }
        a.box([x,9.4,z],[20,.8,15],'#d7c9aa')
        a.box([x,12,z],[16,4.5,11],'#87918b')
        for(let i=0;i<5;i++)d.box([x-6+i*3,12,z+5.55],[1.4,2.4,.06],'#f3d49a',undefined,true)
        a.add('cone',[x,16,z],[10,5,8],'#c7ae7e',[0,Math.PI/4,0],false,'ceramic')
        stairs(a,x,z+10,12,6,'#d3c8ac',true)
      }
      for(const side of [-1,1])for(let i=0;i<7;i++) {
        const z=15+i*5
        a.add('pillar',[side*8,3,z],[.45,6,.45],'#d9cfb7')
        a.add('rock',[side*8,6.7,z],[.7,1,.7],'#c9a86e')
        tree(a,d,side*13,z,4,low,['#7c8c64','#a5a56e','#c0b681'])
      }
      for(const [x,z] of [[-52,-43],[0,-66],[52,-43]] as const) {
        a.add('pillar',[x,9,z],[7,18,7],'#a6a793')
        for(let i=0;i<4;i++)a.ring([x,4+i*4,z],7-i*.5,i%2?'#d5bd86':'#e3d7b9',undefined,false)
        a.add('cone',[x,24,z],[5,14,5],'#d8bf88')
      }
      break
    }
    case 'Space': {
      // A working-looking spaceport: docking arms, pressure habitats, solar farms and asteroid anchors.
      for(const [x,z] of [[-30,8],[29,4]] as const) {
        a.add('pillar',[x,3,z],[6,6,6],'#71849b',undefined,false,'metal')
        a.add('orb',[x,6,z],[6,4,6],'#b3bec4',undefined,false,'ceramic')
        d.ring([x,6,z],6,p.accent,[Math.PI/2,0,0])
        for(const side of [-1,1]) {
          truss(a,V(x+side*6,4,z),V(x+side*13,4,z),.5,'#8d9fac')
          a.box([x+side*14,4,z],[3,5,7],'#526982',undefined,false,'metal')
          d.box([x+side*14,4,z+3.55],[1.8,2,.06],'#79c9dc',undefined,true)
        }
      }
      for(const [x,z] of [[-22,-34],[25,-32]] as const)for(let i=0;i<4;i++) {
        const px=x-8+i*5
        a.beam(V(px,0,z),V(px,3,z),.25,'#94a5b3',false,'metal');solar(d,px,3.3,z,4.4,8)
      }
      // Rocket assembly silhouette on the remote pad.
      a.add('pillar',[0,11,-65],[3,22,3],'#b8c2c7',undefined,false,'metal')
      a.add('cone',[0,26,-65],[3,8,3],'#d6d2c4',undefined,false,'ceramic')
      for(const side of [-1,1]) {
        a.add('cone',[side*3,5,-65],[1.6,8,1.6],'#687e96')
        truss(a,V(side*8,0,-65),V(side*8,30,-65),.45,'#ba9b71')
        for(let y=4;y<28;y+=5)a.beam(V(side*8,y,-65),V(side*2,y,-65),.22,'#ba9b71',false,'metal')
      }
      for(let i=0;i<(low?10:22);i++){const t=i*2.4,r=48+i%4*6;a.add('rock',[Math.cos(t)*r,-2+i%5*3,-35+Math.sin(t)*r],[2+i%3,2+i%4,2+i%3],'#535c76',[i,.3,i])}
      break
    }
    case 'Robotics': {
      // Sawtooth factories, open conveyors and test rigs expose how this district works.
      for(const [x,z] of [[-30,8],[29,4],[-22,-34],[25,-32]] as const) {
        a.box([x,3,z-3],[18,6,10],'#536b75',undefined,false,'metal')
        for(let i=0;i<5;i++) {
          a.box([x-7.2+i*3.6,7,z-3],[4,.3,11],i%2?'#8d9b98':'#b18c64',[0,0,i%2?.45:-.45],false,'metal')
          d.box([x-7.2+i*3.6,4,z+2.05],[1.8,2,.05],i%2?'#75c8b5':'#dfac69',undefined,true)
        }
        a.box([x,1.1,z+7],[16,.5,3],'#354e59',undefined,false,'metal')
        for(let i=0;i<12;i++)a.add('pillar',[x-7.2+i*1.3,1.45,z+7],[.18,2.8,.18],'#a6b0b1',[0,0,Math.PI/2],false,'metal')
        for(let i=0;i<4;i++)a.box([x-5+i*3.4,2.3,z+7],[1.5,1.4,1.5],i%2?'#b58e62':'#6d8c8b',undefined,false,'metal')
        for(const side of [-1,1])a.beam(V(x+side*9,0,z+7),V(x+side*9,11,z+7),.45,'#c39967',false,'metal')
        truss(a,V(x-9,11,z+7),V(x+9,11,z+7),.45,'#c39967')
      }
      for(const [x,z] of [[-52,-42],[0,-65],[52,-43]] as const) {
        a.add('pillar',[x,8,z],[5,16,5],'#4a626e',undefined,false,'metal')
        for(let i=0;i<4;i++)a.ring([x,4+i*4,z],5.3,i%2?p.secondary:p.accent,undefined,i%2===0)
        a.add('pillar',[x+7,12,z],[1.5,24,1.5],'#8b7966',undefined,false,'metal')
        a.add('cone',[x+7,25,z],[2,4,2],'#b19977')
      }
      break
    }
    case 'Community': {
      // A real neighborhood edge: varied homes, a market, workshop yards and planted lanes.
      house(a,d,-32,6,11,7,'#c5ad8c','#a76550');house(a,d,-24,10,7,5,'#91afa0','#557f78')
      house(a,d,29,3,12,8,'#c49b7e','#875f55');house(a,d,23,9,7,5,'#b7b392','#628b7c')
      house(a,d,-23,-34,12,7,'#b7a68c','#986552');house(a,d,26,-32,13,8,'#95afa2','#5c827b')
      for(const [x,z] of [[-30,8],[29,4],[-22,-34],[25,-32]] as const) {
        for(let i=0;i<3;i++)tree(a,d,x-10+i*10,z+10,5.5,low)
        a.box([x,.25,z+9],[15,.5,6],'#b5a78c')
      }
      // Market awnings and communal tables, without invented people or transactions.
      for(let i=0;i<4;i++) {
        const x=-9+i*6,z=27
        for(const dx of [-2,2])a.beam(V(x+dx,0,z),V(x+dx,3,z),.12,'#7d6853',false,'wood')
        d.box([x,3.2,z],[4.8,.18,4],i%2?'#c37960':'#70a392',[.1,0,0],false,'wood')
        a.box([x,1,z],[3.8,.25,1.5],'#b18f68',undefined,false,'wood')
      }
      for(const [x,z] of [[-52,-42],[0,-65],[52,-43]] as const) {
        house(a,d,x,z,13,8,'#b8a589','#a36f58')
        a.add('pillar',[x+8,7,z],[2,14,2],'#879f90')
        a.add('cone',[x+8,15,z],[3,4,3],'#c28a65')
        d.add('orb',[x+8,11,z+2.05],[.7,.7,.1],'#f1d19a',undefined,true)
      }
      for(const side of [-1,1])for(let i=0;i<8;i++)lamp(d,side*5,15+i*5,'#ffd49a',2.8)
      break
    }
  }
  return {solid,detail}
}

function GlassDome({position,radius,height,color}:{position:Vec;radius:number;height:number;color:string}) {
  return <mesh position={position} scale={[1,height/radius,1]}><sphereGeometry args={[radius,32,16,0,Math.PI*2,0,Math.PI/2]}/><meshPhysicalMaterial color={color} transparent opacity={.13} roughness={.12} metalness={.05} depthWrite={false} side={THREE.DoubleSide}/></mesh>
}
function Dish({position,radius=5,rotation=[.65,0,0]}:{position:Vec;radius?:number;rotation?:Vec}) {
  const geometry=useMemo(()=>{
    const points=Array.from({length:18},(_,i)=>{const r=i/17*radius;return new THREE.Vector2(r,r*r*.055)})
    return new THREE.LatheGeometry(points,40)
  },[radius])
  useEffect(()=>()=>geometry.dispose(),[geometry])
  return <group position={position} rotation={rotation}><mesh geometry={geometry}><meshStandardMaterial color="#c1cbd0" metalness={.5} roughness={.35} side={THREE.DoubleSide}/></mesh><mesh position={[0,radius*.55,0]}><sphereGeometry args={[.28,12,8]}/><meshBasicMaterial color="#7dd8ef"/></mesh></group>
}
function Conduit({points,color}:{points:Vec[];color:string}) {
  const geometry=useMemo(()=>new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),48,.09,6,false),[points])
  useEffect(()=>()=>geometry.dispose(),[geometry])
  return <mesh geometry={geometry}><meshBasicMaterial color={color} transparent opacity={.7}/></mesh>
}
function FloatingDetails({city}:{city:CityId}) {
  const {lowEffects}=useEnvironment()
  if(city==='Education')return <>{[-1,1].map(side=><Motion key={side} position={[side*16,15,-7]} speed={side*.07} bob={.7}><group>{Array.from({length:lowEffects?3:7},(_,i)=><mesh key={i} position={[(i-3)*1.4,Math.sin(i)*1.5,Math.cos(i)*2]} rotation={[.2,i*.4,(i-3)*.12]}><boxGeometry args={[1.1,.035,1.5]}/><meshStandardMaterial color={i%2?'#e8d8af':'#a8c8bd'} roughness={.8}/></mesh>)}</group></Motion>)}</>
  if(city==='Gaming')return <>{[-1,1].map(side=><Motion key={side} position={[side*15,12,-10]} speed={side*.25} bob={1.2}><group>{[0,1,2].map(i=><mesh key={i} position={[i*2.2,Math.sin(i)*2,0]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[.7,.7,.16,16]}/><meshStandardMaterial color="#f3c566" emissive="#b36b2c" emissiveIntensity={.25} metalness={.5}/></mesh>)}</group></Motion>)}</>
  if(city==='Creator')return <Motion position={[0,24,-13]} speed={.06} bob={1}><group>{[0,1,2,3].map(i=><mesh key={i} position={[(i-1.5)*4,Math.sin(i)*2,0]} rotation={[i*.2,i*.4,i*.3]}><boxGeometry args={[3,5,.12]}/><meshStandardMaterial color={['#d27a9d','#6d9ec0','#deb675','#79b3a3'][i]} roughness={.45}/></mesh>)}</group></Motion>
  if(city==='Space')return <Motion position={[-36,28,-55]} speed={.12}><group><mesh><boxGeometry args={[2,1.4,2]}/><meshStandardMaterial color="#a5b5c1" metalness={.7}/></mesh>{[-1,1].map(side=><mesh key={side} position={[side*4,0,0]}><boxGeometry args={[6,.12,3]}/><meshStandardMaterial color="#345d91" metalness={.4}/></mesh>)}</group></Motion>
  return null
}
export function DistrictDetails({city}:{city:CityId}) {
  const {lowEffects}=useEnvironment()
  const data=useMemo(()=>districtArchitecture(city,lowEffects),[city,lowEffects])
  return <group name={`${city}-authored-district`}>
    <Parts solid data={data.solid}/><Parts data={data.detail}/>
    {city==='Health'&&<>{[[-30,8,9],[29,4,10],[-22,-34,8],[25,-32,9]].map(([x,z,r])=><GlassDome key={`${x}-${z}`} position={[x,.45,z]} radius={r} height={r*.75} color="#a8e6cf"/>)}<mesh position={[0,.08,27]} rotation={[-Math.PI/2,0,0]}><planeGeometry args={[12,42]}/><meshPhysicalMaterial color="#3f9397" roughness={.16} metalness={.2} transparent opacity={.8}/></mesh></>}
    {city==='Education'&&<GlassDome position={[-22,4,-34]} radius={8} height={7} color="#d3e5cf"/>}
    {city==='Space'&&<><Dish position={[-43,8,-25]} radius={7}/><Dish position={[43,6,-20]} radius={5} rotation={[.9,0,-.4]}/></>}
    {city==='AI'&&<>{[[-30,8],[29,4],[-22,-34],[25,-32]].map(([x,z],i)=><Conduit key={i} points={[[x,.4,z],[x*.7,1.2,z*.65],[x*.35,.6,z*.35],[0,2,0]]} color={i%2?CITIES[city].palette.secondary:CITIES[city].palette.accent}/>)}</>}
    <FloatingDetails city={city}/>
  </group>
}
