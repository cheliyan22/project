import { lazy, Suspense, useEffect, useState } from 'react'
import { MotionConfig } from 'framer-motion'
import { ArrowLeft, Coins, LockKeyhole, Store } from 'lucide-react'
import { useAuth as useBoltAuth } from '@/lib/auth'
import { supabase } from '@/lib/supabase'
import { syncPlanetUser, useProjects } from '@/planet/stores/auth'
import { useUI } from '@/planet/stores/ui'
import { useJourney } from '@/planet/stores/journey'
import { startActivityRewards, useEconomy } from '@/planet/stores/economy'
import { PlanetGate } from '@/planet/modules/cityworld/PlanetGate'
import '@/planet/planet.css'
import '@/planet/second-dawn.css'

const CityWorld = lazy(() => import('@/planet/modules/cityworld/CityWorldModule').then(m => ({ default: m.CityWorldModule })))
const BuildingShop = lazy(() => import('@/planet/components/BuildingShop').then(m => ({ default: m.BuildingShop })))
type Access = { allowed: boolean; admin: boolean; unlockAt: string | null; daysRemaining: number; userId: string }
function LinkLoader() {
  return <div className="dawn-loader" role="status"><div className="dawn-loader-orbit" /><p>ESTABLISHING ORBIT</p><small>Preparing your second beginning.</small></div>
}

export default function PlanetPage({ onExit }: { onExit: () => void }) {
  const { user } = useBoltAuth()
  const [access, setAccess] = useState<Access | null>(null)
  const [accessError, setAccessError] = useState('')
  const [retry, setRetry] = useState(0)
  const [shopOpen, setShopOpen] = useState(false)
  const balance = useEconomy(s => s.balance)
  const introducing = useJourney(s => s.introducing)
  const travelling = useUI(s => s.travelPhase !== 'idle')
  const allowed = !!user && access?.userId === user.id && access.allowed

  useEffect(() => {
    syncPlanetUser(user ? { uid: user.id, email: user.email ?? null, displayName: user.user_metadata?.username ?? null, photoURL: user.user_metadata?.avatar_url ?? null } : null)
  }, [user])
  useEffect(() => {
    // Directly initialize orbit; returning from a previous visit must not trigger exit travel.
    useUI.getState().cancelTravel()
    useUI.setState({mode:'city', cityCategory:null, destination:null, categoryFilter:null, exploring:false, selectedProjectId:null})
    useJourney.getState().startEntry()
    void useProjects.getState().fetchProjects()
  }, [])
  useEffect(() => {
    let live = true
    setAccess(null); setAccessError('')
    if (!user) return () => { live = false }
    const timeout = window.setTimeout(() => {
      if (live) { live = false; setAccessError('The connection timed out. Retry the planet link or return to your archive.') }
    }, 15000)
    void (async () => {
      try {
        const { data, error } = await supabase.rpc('planet_access_status')
        if (!live) return
        if (error) throw error
        const row = Array.isArray(data) ? data[0] : data
        setAccess({
          userId:user.id,
          allowed: Boolean(row?.allowed ?? row?.has_access ?? row?.hasAccess),
          admin: Boolean(row?.admin ?? row?.is_admin ?? row?.isAdmin),
          unlockAt: row?.unlock_at ?? row?.unlockAt ?? null,
          daysRemaining: Math.max(0, Number(row?.days_remaining ?? row?.daysRemaining ?? 0)),
        })
      } catch {
        if (live) setAccessError('Planet access is temporarily unavailable. Your archive is still available.')
      } finally { clearTimeout(timeout) }
    })()
    return () => { live = false; clearTimeout(timeout) }
  }, [user, retry])
  useEffect(() => {
    if (!allowed) return
    void useEconomy.getState().loadEconomy()
    return startActivityRewards((nextBalance, dailyRemaining) => useEconomy.setState({ balance: nextBalance, dailyRemaining }))
  }, [allowed])

  const back = <button className="btn btn-primary" onClick={onExit}><ArrowLeft size={14} /> Return to archive</button>
  if (!user) return <PlanetGate><LockKeyhole color="#d7c09a" /><p className="label-mono">YOUR NEXT CHAPTER</p><h1>A world worth<br />coming back to.</h1><p>Sign in through Reboot to start your 30-day planet unlock. Your projects, your city, your next beginning.</p>{back}</PlanetGate>
  if (accessError) return <PlanetGate><p className="label-mono">CONNECTION INTERRUPTED</p><h1>Holding in orbit.</h1><p>{accessError}</p><button className="btn btn-primary" onClick={() => setRetry(r => r + 1)}>Retry planet link</button> {back}</PlanetGate>
  if (!access || access.userId !== user.id) return <LinkLoader />
  if (!allowed) return <PlanetGate><LockKeyhole color="#d7c09a" /><p className="label-mono">YOUR WORLD IS WAITING</p><h1>Every beginning<br />has its moment.</h1><p>Reboot Planet opens 30 days after account creation. Until then, your projects and profile remain in the archive.</p><div className="planet-countdown">{access.daysRemaining} {access.daysRemaining === 1 ? 'DAY' : 'DAYS'} TO ARRIVAL</div>{access.unlockAt && <p>Unlocks {new Date(access.unlockAt).toLocaleDateString()}</p>}{back}</PlanetGate>

  return <MotionConfig reducedMotion="user"><div className="planet-page reboot-shell">
    <Suspense fallback={<LinkLoader />}><CityWorld /></Suspense>
    <div className={`planet-toolbar ${introducing || travelling ? 'is-cinematic' : ''}`} aria-label="Planet dock" ref={element => { if (element) element.inert = introducing || travelling }}>
      <button className="btn" onClick={onExit}><ArrowLeft size={13} /> Archive</button>
      <button className="btn" onClick={() => useUI.getState().setMode('personal')}>My City</button>
      <button className="btn btn-primary" onClick={() => setShopOpen(true)}><Store size={14} /> Building shop <span className="planet-wallet"><Coins size={13} /> {balance.toLocaleString()}</span></button>
    </div>
    {shopOpen && <Suspense fallback={<div className="planet-shop-loading">Loading building catalogue…</div>}><BuildingShop onClose={() => setShopOpen(false)} /></Suspense>}
  </div></MotionConfig>
}
