import { supabase } from '@/lib/supabase'

/** The planet uses Bolt's single Supabase identity and session. */
export { supabase }
export const publicSupabase = supabase
export const dataConfigured = Boolean(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY)
