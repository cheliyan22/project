import { useEffect } from 'react'
import { useThree } from '@react-three/fiber'

/**
 * A world is "painted" when its first frame has structure and keeps it.
 *
 * Counting frames proves nothing: the HUD controls and the capture rig only care
 * about what the canvas actually holds. So this samples the real drawing buffer
 * and asks a question that works for every city's palette — does the frame
 * contain shapes? Darkness is not a failure (Graveyard's water and AI City's
 * void are meant to be near-black) and neither is over-brightness.
 *
 * A clear colour alone is a flat rectangle: standard deviation near zero, one
 * occupied luminance bucket. A sky gradient, a terrace edge or a colonnade all
 * produce several buckets. A single frame is not enough either — a district can
 * flash once while shaders compile and go black again — so two consecutive
 * samples have to agree before the world counts as on screen.
 */

export const RENDER_PROBE = {
  width: 80,
  height: 45,
  minStdDev: 2.5,
  minBuckets: 3,
  agreementFloor: 1.5,
  agreementRatio: 0.2,
  intervalMs: 150,
  /* A cold dev compile can take tens of seconds, so slowness is not failure:
   * at 15s the reader is told what is happening and offered a retry, while the
   * probe keeps reading. Only at 90s does it stop and stay stopped. */
  slowMs: 15000,
  giveUpMs: 90000,
} as const;

export interface RenderSample {
  mean: number;
  stdDev: number;
  buckets: number;
  width: number;
  height: number;
}

export interface RenderProbeReport {
  samples: number;
  elapsedMs: number;
  painted: boolean;
  slow: boolean;
  failure: string | null;
  sample: RenderSample | null;
  thresholds: typeof RENDER_PROBE;
}

declare global {
  interface Window {
    __rebootRender?: RenderProbeReport;
  }
}

let scratch: HTMLCanvasElement | null = null;
let context: CanvasRenderingContext2D | null = null;

function scratchContext(): CanvasRenderingContext2D | null {
  if (typeof document === "undefined") return null;
  if (!scratch) {
    scratch = document.createElement("canvas");
    scratch.width = RENDER_PROBE.width;
    scratch.height = RENDER_PROBE.height;
    context = scratch.getContext("2d", { willReadFrequently: true });
  }
  return context;
}

/** Samples the presented frame. Returns null when the buffer is unreadable. */
export function readSample(canvas: HTMLCanvasElement): RenderSample | null {
  if (!canvas.width || !canvas.height) return null;
  const ctx = scratchContext();
  if (!ctx) return null;
  const { width, height } = RENDER_PROBE;
  try {
    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(canvas, 0, 0, width, height);
    const { data } = ctx.getImageData(0, 0, width, height);
    const total = width * height;
    const seen = new Uint8Array(16);
    let buckets = 0;
    let sum = 0;
    let sumSquares = 0;
    for (let i = 0; i < total; i++) {
      const offset = i * 4;
      const luma =
        0.2126 * data[offset] +
        0.7152 * data[offset + 1] +
        0.0722 * data[offset + 2];
      sum += luma;
      sumSquares += luma * luma;
      const bucket = Math.min(15, Math.floor(luma / 16));
      if (!seen[bucket]) {
        seen[bucket] = 1;
        buckets += 1;
      }
    }
    const mean = sum / total;
    const variance = Math.max(0, sumSquares / total - mean * mean);
    return {
      mean,
      stdDev: Math.sqrt(variance),
      buckets,
      width: canvas.width,
      height: canvas.height,
    };
  } catch {
    return null;
  }
}

/** Does this frame hold structure, rather than a flat clear colour? */
export function isPainted(sample: RenderSample): boolean {
  return (
    sample.stdDev >= RENDER_PROBE.minStdDev &&
    sample.buckets >= RENDER_PROBE.minBuckets
  );
}

/** Do two samples describe the same picture, at the same canvas size? */
export function agrees(previous: RenderSample | null, next: RenderSample): boolean {
  if (!previous) return false;
  if (previous.width !== next.width || previous.height !== next.height) return false;
  const close = (a: number, b: number) =>
    Math.abs(a - b) <=
    Math.max(
      RENDER_PROBE.agreementFloor,
      RENDER_PROBE.agreementRatio * Math.max(Math.abs(a), Math.abs(b)),
    );
  return close(previous.mean, next.mean) && close(previous.stdDev, next.stdDev);
}

interface UseRenderProbeOptions {
  /** Probing runs only while the district has mounted and is not painted yet. */
  active: boolean;
  /** Bumped to restart after the reader presses Retry. */
  nonce: number;
  /** Fired once, when the world is taking noticeably long. Probing continues. */
  onSlow?: () => void;
  onPainted: () => void;
  onFailed: (failure: RenderFailure) => void;
}

export type RenderFailure = "timeout";

/**
 * Runs inside the Canvas, so it reads the same context the district renders to.
 * Samples at 150ms while a world loads, costs one 80x45 readback, then stops.
 */
export function useRenderProbe({ active, nonce, onSlow, onPainted, onFailed }: UseRenderProbeOptions) {
  const gl = useThree((state) => state.gl);

  useEffect(() => {
    if (!active) return;
    const canvas = gl.domElement;
    const startedAt = performance.now();
    let previous: RenderSample | null = null;
    let samples = 0;
    let painted = false;
    let slow = false;
    let failure: RenderFailure | null = null;
    let stopped = false;
    let timer = 0;

    const publish = (sample: RenderSample | null) => {
      if (!import.meta.env.DEV) return;
      window.__rebootRender = {
        samples,
        elapsedMs: Math.round(performance.now() - startedAt),
        painted,
        slow,
        failure,
        sample,
        thresholds: RENDER_PROBE,
      };
    };

    const stop = () => {
      stopped = true;
      window.clearInterval(timer);
    };

    const tick = () => {
      if (stopped) return;
      const elapsed = performance.now() - startedAt;
      const sample = readSample(canvas);
      samples += 1;
      if (sample && isPainted(sample) && agrees(previous, sample)) {
        painted = true;
        stop();
        publish(sample);
        onPainted();
        return;
      }
      previous = sample;
      if (!slow && elapsed >= RENDER_PROBE.slowMs) {
        slow = true;
        publish(sample);
        onSlow?.();
      }
      if (elapsed >= RENDER_PROBE.giveUpMs) {
        failure = "timeout";
        stop();
        publish(sample);
        onFailed("timeout");
        return;
      }
      publish(sample);
    };

    timer = window.setInterval(tick, RENDER_PROBE.intervalMs);
    tick();

    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, [gl, active, nonce, onSlow, onPainted, onFailed]);
}
