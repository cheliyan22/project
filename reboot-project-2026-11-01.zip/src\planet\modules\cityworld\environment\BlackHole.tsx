import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useEnvironment } from './ScenePrimitives'
import { Architecture, Motion, Parts } from './ScenePrimitives'

/** Layered accretion geometry creates a bent-light silhouette without a screen-space pass. */
export function BlackHole({position = [-28,34,-42], scale = 1}: {position?: [number,number,number];scale?:number}) {
  const debris=useMemo(()=>{
    const a=new Architecture()
    for(let i=0;i<28;i++) {const angle=i*2.4,r=15+(i%7)*1.6;a.add('rock',[Math.cos(angle)*r,Math.sin(angle)*r*.38,(i%3-1)*2],[.25+i%3*.15,.4,.5],i%3?'#596579':'#794758',[i,0,i])}
    return a
  },[])
  return <group name="black-hole" position={position} scale={scale} rotation={[.15,-.45,.25]}>
    <mesh><sphereGeometry args={[8,32,20]} /><meshBasicMaterial fog={false} color="#010104" /></mesh>
    {[8.3,9.1,11,13,15].map((r,i)=><mesh key={r} rotation={[i<2?0:1.16,0,0]} scale={[1,i<2?1:1.12,1]}><torusGeometry args={[r,i===0?.15:.24,6,96]} /><meshBasicMaterial fog={false} color={['#b797bd','#334f67','#a85178','#6d425d','#334958'][i]} transparent opacity={1-i*.14} depthWrite={false} /></mesh>)}
    <AccretionDisk /><pointLight color="#bc6b8f" intensity={35} distance={45} decay={2}/><Motion speed={-.055}><Parts data={debris} /></Motion><Infall />
  </group>
}

function Infall() {
  const mesh=useRef<THREE.InstancedMesh>(null),time=useRef(0),{reduced,lowEffects}=useEnvironment()
  const dummy=useMemo(()=>new THREE.Object3D(),[])
  useFrame((_,delta)=>{
    if(!mesh.current)return
    if(!reduced)time.current+=Math.min(delta,.1)
    for(let i=0;i<8;i++) {
      const progress=(time.current*.025+i/8)%1,r=22-progress*15,angle=i*2.4+progress*4
      dummy.position.set(Math.cos(angle)*r,Math.sin(angle)*r*.5,Math.sin(angle)*2)
      dummy.scale.setScalar((1-progress)*.6);dummy.rotation.set(angle,angle,0);dummy.updateMatrix();mesh.current.setMatrixAt(i,dummy.matrix)
    }
    mesh.current.instanceMatrix.needsUpdate=true
  })
  if(lowEffects)return null
  return <instancedMesh ref={mesh} args={[undefined,undefined,8]} frustumCulled={false}><icosahedronGeometry args={[1,0]}/><meshBasicMaterial color="#8c647f" fog={false}/></instancedMesh>
}

function AccretionDisk() {
  const ref=useRef<THREE.ShaderMaterial>(null),{reduced}=useEnvironment(),uniforms=useMemo(()=>({time:{value:0}}),[])
  useFrame((_,delta)=>{if(ref.current&&!reduced)ref.current.uniforms.time.value+=Math.min(delta,.1)})
  return <mesh rotation={[1.16,0,0]}><ringGeometry args={[9.4,18,96,8]}/><shaderMaterial ref={ref} uniforms={uniforms} transparent depthWrite={false} side={THREE.DoubleSide}
    vertexShader="varying vec3 vPos; void main(){vPos=position;vec3 p=position;p.z=sin(length(p.xy)*.7)*.45;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.0);}"
    fragmentShader="varying vec3 vPos; uniform float time; void main(){float radius=length(vPos.xy);float angle=atan(vPos.y,vPos.x);float bands=.55+.45*sin(radius*6.-angle*3.+time*.5);float edge=(1.-smoothstep(12.,18.,radius))*smoothstep(9.4,10.2,radius);vec3 hot=mix(vec3(.22,.31,.46),vec3(.75,.42,.55),bands);gl_FragColor=vec4(hot,edge*(.35+.5*bands));}"/></mesh>
}
