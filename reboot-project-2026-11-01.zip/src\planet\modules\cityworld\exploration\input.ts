/** Transient device input is intentionally outside the persistent project/UI stores. */
export const explorationInput = { keys: new Set<string>(), jump: false, interact: false, yaw: 0, pitch: .32, distance: 7 }
export function clearExplorationInput() { explorationInput.keys.clear(); explorationInput.jump=false; explorationInput.interact=false }
