import { create } from 'zustand'
import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useUI } from '@/planet/stores/ui'
import { isCityId, CITIES, type CityId } from '../cityRegistry'
import { WORLD_PROFILES } from '../worldManifest'
import { useEnvironment } from './ScenePrimitives'
export type WeatherKind='world'|'clear'|'summer'|'rain'|'snow'
export const useWeather=create<{kind:WeatherKind;set:(kind:WeatherKind)=>void}>(set=>({kind:'world',set:kind=>set({kind})}))
export function weatherFor(city:CityId,override:WeatherKind) {return city==='Space' && ['rain','snow','summer'].includes(override) ? 'world' : override}
export function WeatherControl(){
 const {kind,set}=useWeather(),city=useUI(s=>s.cityCategory),space=city==='Space'
 return <label className="weather-control">Atmosphere <select aria-label="Weather" value={space?weatherFor('Space',kind):kind} onChange={e=>set(e.target.value as WeatherKind)}><option value="world">World atmosphere</option><option value="clear">Clear</option>{!space&&<><option value="summer">Warm daylight</option><option value="rain">Rain</option><option value="snow">Snow</option></>}</select></label>
}
export function Weather(){
 const category=useUI(s=>s.cityCategory),city=category&&isCityId(category)?category:'Community',override=useWeather(s=>s.kind)
 const kind=weatherFor(city,override),profile=WORLD_PROFILES[city],{lowEffects,reduced}=useEnvironment()
 const count=lowEffects?48:profile.quality.particles,time=useRef(0),attr=useRef<THREE.BufferAttribute>(null)
 const vertices=useMemo(()=>new Float32Array(count*6),[count,city,kind])
 const colors=useMemo(()=>{
  const a=new Float32Array(count*6),color=new THREE.Color()
  for(let i=0;i<count;i++){color.set(kind==='rain'?'#9cbecb':kind==='snow'?'#e5f4ff':city==='Graveyard'?'#a49bad':city==='Education'||city==='Community'?i%2?'#bb976d':'#77aa8b':city==='Robotics'?'#d9b086':CITIES[city].palette.secondary);a.set([color.r,color.g,color.b,color.r,color.g,color.b],i*6)}return a
 },[city,kind,count])
 useFrame((_,delta)=>{
  if(!attr.current)return
  if(!reduced)time.current+=Math.min(delta,.08)
  const t=time.current,a=attr.current.array as Float32Array
  for(let i=0;i<count;i++) {
   let x=((i*17.31)%94)-47,z=((i*23.77)%94)-47,y=30-((i*7.3+t*(kind==='rain'?21:kind==='snow'?2:1))%30),dx=.07,dy=.07,dz=0
   if(kind==='rain'){dx=.18;dy=-1.2}
   else if(kind==='snow'){x+=Math.sin(t*.4+i)*1.5;dy=.04}
   else if(kind==='world') {
    const phase=(t*.06+i/count)%1,angle=i*2.4+t*.1
    switch(profile.weather){
     case 'ash': {const r=28-phase*17;x=-28+Math.cos(angle+phase*4)*r;z=-42+Math.sin(angle+phase*4)*r;y=3+phase*29;break}
     case 'dust': x=(i%2?29:-30)+Math.sin(angle)*7;z=(i%2?4:8)+Math.cos(angle)*6;y=phase*6;dy=.03;break
     case 'celebration': x=Math.sin(angle)*25;z=Math.cos(angle)*25;y=8+phase*25;dx=.12;dy=.02;break
     case 'data': {const lane=i%4,sites=[[-30,8],[29,4],[-22,-34],[25,-32]],p=sites[lane];x=p[0]*phase;z=p[1]*phase;y=16*(1-phase)+3*phase+Math.sin(phase*Math.PI)*4;dx=.15;dy=.1;break}
     case 'pixels': x=Math.floor(x/2)*2;z=Math.floor(z/2)*2;dy=-.25;dx=0;break
     case 'pages': case 'leaves': x+=Math.sin(t*.3+i)*4;y=18-((i+t*.65)%18);dx=profile.weather==='pages'?.3:.15;dz=.1;dy=Math.sin(t+i)*.08;break
     case 'mist': x=Math.sin(angle)*30;z=Math.cos(angle)*30;y=.8+phase*2;dx=.5;dy=.02;break
     case 'surreal': x=Math.sin(angle)*28;z=Math.cos(angle*1.1)*30;y=5+Math.sin(angle*2)*4;dy=.15;dx=.15;break
     case 'solar': x=Math.sin(angle)*68;z=Math.cos(angle)*65;y=18+phase*40;dx=.08;dy=.08;break
     case 'steam': x=(i%2?14:-14)+Math.sin(angle)*.7;z=36+Math.cos(angle)*.7;y=2+phase*5;dy=i%5===0?-.2:.22;dx=.06;break
    }
   }
   a.set([x,y,z,x+dx,y+dy,z+dz],i*6)
  }
  attr.current.needsUpdate=true
 })
 if(kind==='clear')return null
 if(kind==='summer')return <directionalLight position={[-30,45,-70]} color="#ffcf91" intensity={.6}/>
 return <group name={`${city}-${kind}-weather`} userData={{particles:count,profile:profile.weather}}>
 <lineSegments key={`${count}-${city}-${kind}`} frustumCulled={false}><bufferGeometry><bufferAttribute ref={attr} attach="attributes-position" args={[vertices,3]}/><bufferAttribute attach="attributes-color" args={[colors,3]}/></bufferGeometry><lineBasicMaterial vertexColors transparent opacity={kind==='rain'?.5:.65} depthWrite={false}/></lineSegments>
 {kind==='rain'&&<RainImpacts color={CITIES[city].palette.secondary} reduced={reduced}/>}
 {kind==='world'&&city==='Space'&&<Aurora reduced={reduced}/>}
 </group>
}
function RainImpacts({color,reduced}:{color:string;reduced:boolean}) {
 const ref=useRef<THREE.InstancedMesh>(null),time=useRef(0),dummy=useMemo(()=>new THREE.Object3D(),[])
 useFrame((_,delta)=>{if(!ref.current)return;if(!reduced)time.current+=Math.min(delta,.1);for(let i=0;i<18;i++){const p=(time.current*1.3+i/18)%1;dummy.position.set((i%3-1)*1.8,.075,15+i*2);dummy.rotation.set(-Math.PI/2,0,0);dummy.scale.setScalar(.1+p*.3);dummy.updateMatrix();ref.current.setMatrixAt(i,dummy.matrix)}ref.current.instanceMatrix.needsUpdate=true})
 return <instancedMesh ref={ref} args={[undefined,undefined,18]}><ringGeometry args={[.75,1,10]}/><meshBasicMaterial color={color} transparent opacity={.2} depthWrite={false}/></instancedMesh>
}
function Aurora({reduced}:{reduced:boolean}) {
 const shader=useRef<THREE.ShaderMaterial>(null),uniforms=useMemo(()=>({time:{value:0}}),[])
 useFrame((_,delta)=>{if(shader.current&&!reduced)shader.current.uniforms.time.value+=Math.min(delta,.1)})
 return <mesh position={[0,40,-90]}><planeGeometry args={[170,45,1,1]}/><shaderMaterial ref={shader} uniforms={uniforms} transparent depthWrite={false} side={THREE.DoubleSide}
 vertexShader="varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}"
 fragmentShader="varying vec2 vUv; uniform float time; void main(){float ridge=.5+.13*sin(vUv.x*14.+time*.1)+.08*sin(vUv.x*27.-time*.12);float beam=exp(-pow((vUv.y-ridge)*9.,2.));float taper=sin(vUv.x*3.14159);vec3 color=mix(vec3(.18,.65,.58),vec3(.36,.28,.7),vUv.x);gl_FragColor=vec4(color,beam*taper*.35);}"/></mesh>
}
