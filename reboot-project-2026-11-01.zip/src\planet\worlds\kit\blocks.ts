import { Architecture } from '@/planet/modules/cityworld/environment/ScenePrimitives'
import type { Finish } from '@/planet/modules/cityworld/environment/SurfaceMaterials'
import type { CityId } from '@/planet/modules/cityworld/cityRegistry'
import type { WorldProfile } from '../types'
import { hash, mixHex, shade, stream, TAU } from './math'

/* Authored architectural recipes. Each city composes these differently — the
 * recipe mix, proportions, roof language and material pairing are what make a
 * place recognisable, not a colour swap. */

const push = (a: Architecture, shape: Parameters<Architecture['add']>[0], pos: [number, number, number], scale: [number, number, number], colour: string, rot?: [number, number, number], glow = false, finish?: Finish) =>
  a.add(shape, pos, scale, colour, rot, glow, finish)

/** Post-and-lintel colonnade with a solid entablature. */
function colonnade(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, count = 6, height = 12) {
  const c = p.palette
  for (let i = 0; i < count; i++) {
    const off = (i - (count - 1) / 2) * s * 1.9
    const px = x + Math.cos(rot) * off
    const pz = z + Math.sin(rot) * off
    a.add('pillar', [px, height / 2, pz], [s * 0.34, height, s * 0.34], c.mass, undefined, false, 'stone')
    a.add('pillar', [px, height + 0.25, pz], [s * 0.5, 0.5, s * 0.5], c.trim, undefined, false, 'stone')
  }
  a.box([x, height + 0.9, z], [count * s * 1.9, 1.1, s * 1.05], c.mass, [0, -rot, 0], false, 'stone')
  a.box([x, height + 1.7, z], [count * s * 1.9 + 1, 0.5, s * 1.3], c.trim, [0, -rot, 0], false, 'stone')
}

/** Repeating vault arcade: the signature of civic and archive architecture. */
function arcade(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, bays = 4, radius = 6) {
  const c = p.palette
  for (let i = 0; i < bays; i++) {
    const off = (i - (bays - 1) / 2) * radius * 2.1
    const px = x + Math.cos(rot) * off
    const pz = z + Math.sin(rot) * off
    a.add('arch', [px, radius * 0.98, pz], [radius, radius, radius * 0.62], c.mass, [0, -rot, 0], false, 'stone')
    a.add('pillar', [px - Math.cos(rot) * radius * 1.02, radius * 0.5, pz - Math.sin(rot) * radius * 1.02], [s * 0.3, radius, s * 0.3], c.mass, undefined, false, 'stone')
  }
  a.box([x, radius * 2 + 1, z], [bays * radius * 2.1, 1.4, radius * 1.4], c.mass, [0, -rot, 0], false, 'stone')
}

/** Stepped massing tower with setbacks and a crown. */
export function tower(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, tiers = 3, height = 34) {
  const c = p.palette
  let y = 0
  let w = s * 2.6
  for (let i = 0; i < tiers; i++) {
    const h = height * (0.5 - i * 0.1)
    a.box([x, y + h / 2, z], [w, h, w * 0.8], i % 2 ? c.base : shade(c.base, 0.05), [0, -rot, 0], false, 'stone')
    a.box([x, y + h + 0.25, z], [w * 1.06, 0.5, w * 0.86], c.trim, [0, -rot, 0], false, 'metal')
    y += h
    w *= 0.74
  }
  a.add('wedge', [x, y + 1.4, z], [w * 0.9, w * 1.5, w * 0.7], c.mass, [0, -rot, 0], false, 'stone')
  // Vertical light slots rather than a wall of neon.
  for (let i = 0; i < 3; i++) {
    const off = (i - 1) * w * 0.5
    push(a, 'box', [x + Math.cos(rot) * off, height * 0.34 + 3, z + Math.sin(rot) * off], [0.22, height * 0.36, 0.1], c.glow, [0, -rot, 0], true)
  }
}

/** Open work gantry: legs, cross beam and a hoist. */
function gantry(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, height = 24) {
  const c = p.palette
  for (const side of [-1, 1]) {
    const px = x + Math.cos(rot + Math.PI / 2) * side * s * 1.9
    const pz = z + Math.sin(rot + Math.PI / 2) * side * s * 1.9
    a.beam([px, 0, pz], [px, height, pz], s * 0.28, c.trim, false, 'metal')
    a.beam([px, height * 0.45, pz], [px + Math.cos(rot) * side * s, height * 0.75, pz + Math.sin(rot) * side * s], s * 0.15, c.trim, false, 'metal')
  }
  a.beam([x - Math.cos(rot + Math.PI / 2) * s * 1.9, height, z - Math.sin(rot + Math.PI / 2) * s * 1.9], [x + Math.cos(rot + Math.PI / 2) * s * 1.9, height, z + Math.sin(rot + Math.PI / 2) * s * 1.9], s * 0.3, c.trim, false, 'metal')
  a.beam([x, height, z], [x, height - 6, z], 0.18, c.accent, true)
  a.box([x, height - 6.6, z], [s * 0.9, 0.7, s * 0.9], c.mass, [0, -rot, 0], false, 'metal')
}

/** Scaffolded skeletal frame — a building mid-construction. */
function scaffold(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, height = 26) {
  const c = p.palette
  for (const dx of [-1, 1]) for (const dz of [-1, 1]) {
    const px = x + Math.cos(rot) * dx * s + Math.sin(rot) * dz * s
    const pz = z + Math.sin(rot) * dx * s - Math.cos(rot) * dz * s
    a.beam([px, 0, pz], [px, height, pz], s * 0.2, c.trim, false, 'metal')
  }
  for (let level = 1; level <= 4; level++) {
    const y = (height / 5) * level
    a.box([x, y, z], [s * 2.1, 0.24, s * 2.1], mixHex(c.trim, c.base, 0.35), [0, -rot, 0], false, 'metal')
    if (level % 2 === 0) a.box([x, y + 2.6, z], [s * 1.5, 5, s * 1.5], shade(c.base, 0.02), [0, -rot, 0], false, 'stone')
  }
  a.beam([x - s, height * 0.7, z], [x + s * 0.6, height * 1.05, z], s * 0.14, c.trim, false, 'metal')
}

/** A monolithic slab with a single carved portal and vertical ribs. */
function monolith(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, height = 30) {
  const c = p.palette
  a.box([x, height / 2, z], [s * 2.4, height, s * 1.6], c.base, [0.04, -rot, 0.05], false, 'stone')
  for (let i = 0; i < 5; i++) {
    const off = (i - 2) * s * 0.45
    a.box([x + Math.cos(rot) * off, height * 0.5, z + Math.sin(rot) * off + s * 0.82], [s * 0.12, height * 0.92, 0.3], c.mass, [0.04, -rot, 0.05], false, 'stone')
  }
  a.box([x, 3.4, z + s * 0.8], [s * 0.8, 6.8, 0.5], '#0b0f16', [0, -rot, 0], false, 'stone')
  push(a, 'box', [x, 0.9, z + s * 0.9], [s * 0.5, 0.3, 0.2], c.glow, [0, -rot, 0], true)
  a.add('wedge', [x, height + s * 0.6, z], [s * 1.1, s * 2, s * 0.9], c.mass, [0.04, -rot, 0.05], false, 'stone')
}

/** Suspended gallery frame: architecture without a ground floor. */
function frame(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, y = 12, tilt = 0) {
  const c = p.palette
  const bar = (ox: number, oy: number, w: number, h: number) =>
    a.box([x + Math.cos(rot) * ox, y + oy, z + Math.sin(rot) * ox], [w, h, 0.7], c.mass, [tilt, -rot, 0], false, 'ceramic')
  bar(0, s, s * 2, 0.8)
  bar(0, -s, s * 2, 0.8)
  bar(-s, 0, 0.8, s * 2)
  bar(s, 0, 0.8, s * 2)
  a.box([x, y, z], [s * 1.9, s * 1.8, 0.3], shade(c.trim, 0.06), [tilt, -rot, 0], false, 'ceramic')
  push(a, 'box', [x, y - s * 0.9, z], [s * 1.6, 0.18, 0.5], c.glow, [tilt, -rot, 0], true)
}

/** Low hall with a gabled roof and a lit clerestory. */
function hall(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, height = 12) {
  const c = p.palette
  a.box([x, height / 2, z], [s * 3, height, s * 2], c.base, [0, -rot, 0], false, 'stone')
  a.add('wedge', [x, height + s * 0.42, z], [s * 1.9, s * 2.6, s * 1.5], c.mass, [0, -rot, 0], false, 'stone')
  for (let i = 0; i < 4; i++) {
    push(a, 'box', [x + Math.cos(rot) * (i - 1.5) * s * 0.72, 4.4, z + Math.sin(rot) * (i - 1.5) * s * 0.72 + s * 0.95], [0.5, 2.6, 0.14], c.glow, [0, -rot, 0], true)
  }
  a.box([x, 0.3, z + s * 1.2], [s * 1.2, 0.6, s * 0.8], c.mass, [0, -rot, 0], false, 'stone')
}

/** Terraced housing block with a gabled roof and awning. */
function house(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number) {
  const c = p.palette
  const w = s * 1.5
  a.box([x, s * 0.85, z], [w, s * 1.7, w * 0.8], c.base, [0, -rot, 0], false, 'stone')
  a.add('wedge', [x, s * 1.85, z], [w * 0.68, w * 1.1, w * 0.62], c.mass, [0, -rot, 0], false, 'ceramic')
  push(a, 'box', [x + Math.cos(rot + Math.PI / 2) * 0 + Math.cos(rot) * w * 0.4, s * 1.1, z + Math.sin(rot) * w * 0.4], [0.9, 1.4, 0.12], c.glow, [0, -rot, 0], true)
  a.box([x + Math.cos(rot + Math.PI / 2) * w * 0.55, s * 1.5, z + Math.sin(rot + Math.PI / 2) * w * 0.55], [w * 0.7, 0.16, w * 0.4], c.trim, [0.08, -rot, 0], false, 'wood')
}

/** Industrial chimney with banding and an ember mouth. */
function chimney(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, height = 30) {
  const c = p.palette
  a.add('pillar', [x, height / 2, z], [s * 0.6, height, s * 0.6], shade(c.base, 0.06), [0, -rot, 0], false, 'metal')
  for (let i = 0; i < 3; i++) a.ring([x, height * (0.3 + i * 0.26), z], s * 0.75, c.trim, undefined, false)
  push(a, 'orb', [x, height + 0.4, z], [s * 0.42, s * 0.2, s * 0.42], c.secondary, undefined, true)
}

/** Observatory dish built from stacked rings and a cone reflector. */
export function dish(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number) {
  const c = p.palette
  for (let i = 0; i < 4; i++) {
    a.ring([x, 6 + i * 0.9, z], s * (1.5 - i * 0.26), mixHex(c.trim, c.base, i * 0.2), [0.6, -rot, 0], false)
  }
  a.add('cone', [x, 7.4, z], [s * 1.3, s * 1.1, s * 1.1], c.mass, [Math.PI, -rot, 0], false, 'metal')
  a.add('pillar', [x, 3, z], [s * 0.32, 6, s * 0.32], c.trim, undefined, false, 'metal')
  push(a, 'orb', [x, 8.4, z], [s * 0.18, s * 0.14, s * 0.18], c.accent, undefined, true)
}

/** Conveyor run: rollers, belt deck and side rails. */
function conveyor(a: Architecture, p: WorldProfile, x: number, z: number, s: number, rot: number, length = 26) {
  const c = p.palette
  a.box([x, 3.2, z], [length, 0.5, s * 1.1], c.base, [0, -rot, 0], false, 'metal')
  for (let i = 0; i < 8; i++) {
    const d = (i / 7 - 0.5) * length
    a.add('pillar', [x + Math.cos(rot) * d, 3.6, z + Math.sin(rot) * d], [s * 0.3, 0.8, s * 0.55], c.trim, [0, -rot, Math.PI / 2], false, 'metal')
  }
  for (const side of [-1, 1]) {
    a.box([x + Math.cos(rot + Math.PI / 2) * side * s * 0.7, 4.2, z + Math.sin(rot + Math.PI / 2) * side * s * 0.7], [length, 0.3, 0.2], c.accent, [0, -rot, 0], false, 'metal')
    a.beam([x + Math.cos(rot + Math.PI / 2) * side * s * 0.7, 0, z + Math.sin(rot + Math.PI / 2) * side * s * 0.7], [x + Math.cos(rot + Math.PI / 2) * side * s * 0.7, 3, z + Math.sin(rot + Math.PI / 2) * side * s * 0.7], 0.2, c.trim, false, 'metal')
  }
}

/** Lit street furniture shared by every city. */
function lamp(a: Architecture, p: WorldProfile, x: number, z: number) {
  a.add('pillar', [x, 2.2, z], [0.12, 4.4, 0.12], p.palette.trim, undefined, false, 'metal')
  push(a, 'orb', [x, 4.7, z], [0.26, 0.34, 0.26], p.palette.glow, undefined, true)
}

export function plantRing(_a: Architecture, _p: WorldProfile, radius: number, count: number, recipe: (x: number, z: number, i: number) => void, offset = 0) {
  for (let i = 0; i < count; i++) {
    const t = (i / count) * TAU + offset
    recipe(Math.cos(t) * radius, Math.sin(t) * radius, i)
  }
}

function scatter(_a: Architecture, _p: WorldProfile, count: number, min: number, max: number, seed: string, recipe: (x: number, z: number, i: number) => void, skipEntrance = true) {
  const rnd = stream(seed)
  for (let i = 0; i < count; i++) {
    const angle = rnd() * TAU
    const radius = min + rnd() * (max - min)
    const x = Math.cos(angle) * radius
    const z = Math.sin(angle) * radius
    if (skipEntrance && Math.abs(x) < 9 && z > 18) continue
    recipe(x, z, i)
  }
}

export function buildFabric(city: CityId, p: WorldProfile): Architecture {
  const a = new Architecture()
  const c = p.palette
  const d = p.fabric.density
  const s = p.fabric.spread * 0.1 + 0.6

  switch (city) {
    case 'Graveyard': {
      // A necropolis of vaults that lost their roofs, leaning slabs and sealed doors.
      arcade(a, p, -28, 10, 0.8, Math.PI / 2, 4, 6.4)
      arcade(a, p, 30, -6, 0.7, Math.PI / 2, 3, 5.6)
      for (const [x, z, h, r] of [[-34, -26, 30, 0.3], [36, 26, 24, -0.25], [12, -40, 34, 0.16], [-14, 42, 22, -0.4]] as const) {
        monolith(a, p, x, z, s * 1.2, r, h)
      }
      scatter(a, p, Math.round(12 * d), 24, 50, 'grave-tombs', (x, z, i) => {
        const h = 2 + hash(i, 2) * 6
        a.box([x, h / 2, z], [1.6 + hash(i, 3) * 1.4, h, 1.1], shade(c.base, 0.06), [0, hash(i, 4) * 0.5, (hash(i, 5) - 0.5) * 0.4], false, 'stone')
        if (i % 4 === 0) push(a, 'box', [x, 0.5, z + 0.6], [0.7, 0.16, 0.1], c.accent, undefined, true)
      })
      // Fallen fragments and dead lanterns.
      scatter(a, p, 9, 20, 46, 'grave-rubble', (x, z, i) => {
        a.add('rock', [x, 0.6 + hash(i, 6) * 2, z], [3 + hash(i, 7) * 4, 1.6 + hash(i, 8) * 3, 2.4], shade(c.base, 0.04), [hash(i, 9), hash(i, 10), hash(i, 11)], false, 'stone')
        if (i % 3 === 0) push(a, 'orb', [x, 3.4, z], [0.34, 0.5, 0.34], c.secondary, undefined, true)
      })
      for (let i = 0; i < 6; i++) lamp(a, p, Math.cos(i * 1.05) * 44, Math.sin(i * 1.05) * 44)
      break
    }
    case 'IdeaHub': {
      // Working scaffolds over repair bays; nothing here is finished.
      for (const [x, z, h] of [[-34, 6, 28], [32, 2, 24], [-24, -34, 30], [26, -30, 22]] as const) {
        scaffold(a, p, x, z, s * 1.15, hash(x, z) * 0.6, h)
        gantry(a, p, x + 6, z - 6, s * 0.9, 0.3, h * 0.8)
      }
      hall(a, p, -38, 30, s * 0.9, 0.2, 10)
      hall(a, p, 36, 30, s * 0.8, -0.25, 9)
      // Stacked material crates and cable reels.
      scatter(a, p, Math.round(14 * d), 22, 46, 'revival-stack', (x, z, i) => {
        const h = 1 + hash(i, 2) * 1.4
        a.box([x, h / 2, z], [3.2, h, 2.4], mixHex(c.trim, c.base, 0.5), [0, hash(i, 3) * 0.8, 0], false, 'wood')
        if (i % 3 === 0) a.add('pillar', [x, 2.4, z], [1, 2, 1], shade(c.trim, -0.1), [Math.PI / 2, hash(i, 4), 0], false, 'metal')
      })
      for (const [x, z] of [[-18, 26], [20, 24], [-40, -8], [40, -14]] as const) {
        gantry(a, p, x, z, s * 1.3, hash(x, z) * 3, 34)
      }
      for (let i = 0; i < 5; i++) lamp(a, p, Math.cos(i * 1.25) * 40, Math.sin(i * 1.25) * 40)
      break
    }
    case 'Legend': {
      // Symmetry is the point: twin colonnades, twin obelisks, one ceremonial axis.
      for (const side of [-1, 1]) {
        colonnade(a, p, side * 30, 22, s * 1.1, 0, 7, 15)
        colonnade(a, p, side * 30, -18, s * 1.1, 0, 5, 13)
        for (let i = 0; i < 3; i++) {
          a.add('pillar', [side * (38 + i * 2), 8, 34 - i * 6], [1.1, 16, 1.1], c.mass, undefined, false, 'stone')
        }
        a.box([side * 42, 2, 8], [16, 4, 26], c.base, undefined, false, 'stone')
      }
      for (let i = 0; i < 7; i++) {
        const z = 44 - i * 4
        a.box([0, i * 0.55 - 0.4, z], [16 - i * 0.8, 0.8, 4.4], i % 2 ? c.mass : c.base, undefined, false, 'ceramic')
      }
      scatter(a, p, Math.round(8 * d), 34, 54, 'legend-garden', (x, z, i) => {
        a.add('orb', [x, 3, z], [7, 2.4, 6], mixHex(c.base, c.trim, 0.45), undefined, false, 'foliage')
        a.add('pillar', [x, 1.4, z], [2.2, 2.8, 2.2], mixHex(c.mass, c.trim, 0.3), undefined, false, 'ceramic')
        if (i % 2 === 0) push(a, 'orb', [x, 5.6, z], [0.5, 0.5, 0.5], c.glow, undefined, true)
      })
      for (const side of [-1, 1]) for (let i = 0; i < 4; i++) lamp(a, p, side * (24 + i * 5), 40)
      break
    }
    case 'AI': {
      // Tendon pylons and suspended data volumes; the city is a lattice, not a skyline.
      for (let i = 0; i < 8; i++) {
        const t = (i / 8) * TAU + 0.2
        const x = Math.cos(t) * 38
        const z = Math.sin(t) * 38
        for (let leg = 0; leg < 3; leg++) {
          const off = (leg - 1) * 3.4
          a.beam([x + Math.cos(t + Math.PI / 2) * off, 0, z + Math.sin(t + Math.PI / 2) * off], [x + Math.cos(t) * 2, 30 + hash(i, leg) * 8, z + Math.sin(t) * 2], 0.34, mixHex(c.trim, c.base, 0.2), false, 'metal')
        }
        a.box([x, 26 + hash(i, 2) * 8, z], [7, 1.2, 7], mixHex(c.base, c.trim, 0.4), [0, t, 0], false, 'metal')
        push(a, 'box', [x, 27 + hash(i, 2) * 8, z], [4.6, 0.2, 4.6], c.glow, undefined, true)
        a.ring([x, 18, z], 6.5, c.accent, [Math.PI / 2, 0, t], false)
      }
      // Suspended volumes held between pylons.
      scatter(a, p, Math.round(10 * d), 24, 44, 'cortex-volume', (x, z, i) => {
        const y = 14 + hash(i, 2) * 14
        a.add('hex', [x, y, z], [4.4, 3, 4.4], mixHex(c.base, c.mass, 0.4), [0.2, hash(i, 3) * 2, 0.15], false, 'metal')
        a.beam([x, y, z], [x, 0.4, z], 0.12, c.secondary, true)
        if (i % 2 === 0) push(a, 'box', [x, y - 1.7, z], [2.6, 0.14, 2.6], c.glow, undefined, true)
      })
      for (let i = 0; i < 14; i++) {
        const t = hash(i, 21) * TAU
        const r = 20 + hash(i, 22) * 30
        a.beam([Math.cos(t) * r, 0.1, Math.sin(t) * r], [Math.cos(t + 0.2) * (r + 12), 0.1, Math.sin(t + 0.2) * (r + 12)], 0.09, c.accent, true)
      }
      break
    }
    case 'Gaming': {
      // Arcade canyon: cabinet facades, gate arches, stepped platforms.
      for (let i = 0; i < 6; i++) {
        const t = (i / 6) * TAU + 0.3
        const x = Math.cos(t) * 36
        const z = Math.sin(t) * 36
        const h = 10 + hash(i, 2) * 12
        a.box([x, h / 2, z], [7, h, 5], i % 2 ? c.base : mixHex(c.base, c.secondary, 0.18), [0, -t, 0], false, 'stone')
        a.box([x, h + 1, z], [7.6, 2, 5.4], c.mass, [0, -t, 0], false, 'ceramic')
        for (let k = 0; k < 3; k++) push(a, 'box', [x + Math.cos(t) * 2.6, 3 + k * 3, z + Math.sin(t) * 2.6], [1.4, 0.5, 0.14], k % 2 ? c.accent : c.glow, [0, -t, 0], true)
        if (i % 2 === 0) a.add('arch', [x, 5.6, z], [4.2, 4.2, 4.2], c.secondary, [0, -t, 0], false, 'ceramic')
      }
      // Floating playfield platforms at four heights.
      for (const [x, y, z, w] of [[-26, 12, -18, 10], [22, 17, -24, 8], [-16, 22, 20, 7], [30, 9, 16, 9]] as const) {
        a.box([x, y, z], [w, 0.7, w], c.base, [0, hash(x, z) * 0.6, 0], false, 'stone')
        a.ring([x, y + 0.5, z], w * 0.42, c.accent, undefined, false)
        push(a, 'box', [x, y + 0.9, z], [w * 0.3, 0.3, w * 0.3], c.glow, undefined, true)
      }
      scatter(a, p, Math.round(10 * d), 22, 46, 'arcade-stack', (x, z, i) => {
        const h = 3 + hash(i, 3) * 9
        a.box([x, h / 2, z], [3.4, h, 3.4], mixHex(c.base, c.mass, hash(i, 4) * 0.6), [0, hash(i, 5) * 1.2, 0], false, 'stone')
        a.add('wedge', [x, h + 1.2, z], [2.4, 2.6, 2.4], c.mass, [0, hash(i, 6) * 1.2, 0], false, 'ceramic')
      })
      for (let i = 0; i < 8; i++) {
        const x = Math.cos(i * 0.8) * 44
        const z = Math.sin(i * 0.8) * 44
        a.add('pillar', [x, 3, z], [0.3, 6, 0.3], c.trim, undefined, false, 'metal')
        push(a, 'orb', [x, 6.4, z], [0.5, 0.5, 0.5], i % 2 ? c.accent : c.secondary, undefined, true)
      }
      break
    }
    case 'Education': {
      // Terraced library: shelving walls, reading platforms, lanterns under a canopy.
      for (let i = 0; i < 4; i++) {
        const t = (i / 4) * TAU + 0.4
        const x = Math.cos(t) * 34
        const z = Math.sin(t) * 34
        for (let shelf = 0; shelf < 5; shelf++) {
          a.box([x, 2 + shelf * 3.4, z], [16, 0.5, 6], shade(c.base, 0.03 + shelf * 0.012), [0, -t, 0], false, 'wood')
          for (let b = 0; b < 10; b++) {
            push(a, 'box', [x + Math.cos(t) * (b - 4.5) * 1.4, 2.9 + shelf * 3.4, z + Math.sin(t) * (b - 4.5) * 1.4], [0.9, 1.5, 0.6], mixHex(c.mass, c.accent, hash(b, shelf, i) * 0.5), [0, -t, 0], false)
          }
        }
        a.box([x, 11, z], [18, 0.6, 8], c.mass, [0, -t, 0], false, 'wood')
      }
      // Hanging reading terraces under the canopy.
      for (const [x, y, z] of [[-20, 14, 16], [22, 18, -14], [4, 21, -30]] as const) {
        a.add('pillar', [x, y - 0.4, z], [7, 0.5, 7], c.mass, undefined, false, 'wood')
        for (let i = 0; i < 4; i++) push(a, 'orb', [x + Math.cos(i * 1.6) * 4, y + 1.4, z + Math.sin(i * 1.6) * 4], [0.28, 0.4, 0.28], c.glow, undefined, true)
        a.beam([x, y, z], [0, y + 6, 0], 0.14, c.trim, false, 'wood')
      }
      scatter(a, p, Math.round(10 * d), 24, 48, 'library-root', (x, z, i) => {
        a.add('pillar', [x, 1.6, z], [1 + hash(i, 2) * 1.4, 3.2, 1 + hash(i, 3) * 1.2], shade(c.trim, -0.25), [0.06, 0, 0.06], false, 'wood')
        a.add('orb', [x, 4.6, z], [3.4 + hash(i, 4) * 2.4, 1.8, 3], mixHex(c.base, c.accent, 0.35), undefined, false, 'foliage')
      })
      for (let i = 0; i < 6; i++) lamp(a, p, Math.cos(i * 1.05) * 30, Math.sin(i * 1.05) * 30)
      break
    }
    case 'Health': {
      // Tidal sanatorium: white pavilions, half-submerged arcades, planted roofs.
      for (let i = 0; i < 5; i++) {
        const t = (i / 5) * TAU + 0.25
        const x = Math.cos(t) * 36
        const z = Math.sin(t) * 36
        a.add('pillar', [x, 3, z], [6.5, 6, 6.5], c.base, undefined, false, 'ceramic')
        a.add('orb', [x, 6.6, z], [6.2, 3.4, 6.2], mixHex(c.base, c.trim, 0.4), undefined, false, 'ceramic')
        a.add('orb', [x, 7.4, z], [5.2, 2.2, 5.2], mixHex(c.base, c.accent, 0.45), undefined, false, 'foliage')
        push(a, 'box', [x, 3.4, z + 3.4], [3.4, 0.24, 0.2], c.glow, undefined, true)
      }
      arcade(a, p, -28, -22, 0.7, 0.4, 3, 5)
      arcade(a, p, 30, -16, 0.65, -0.3, 3, 4.6)
      scatter(a, p, Math.round(12 * d), 22, 48, 'clinic-garden', (x, z, i) => {
        a.add('orb', [x, 1.2, z], [4 + hash(i, 2) * 3, 1.4, 3.4], mixHex(c.base, c.trim, 0.5), undefined, false, 'foliage')
        if (i % 2 === 0) a.add('pillar', [x, 0.7, z], [1.8, 1.4, 1.8], mixHex(c.base, '#e6f2e8', 0.4), undefined, false, 'ceramic')
      })
      for (let i = 0; i < 7; i++) lamp(a, p, Math.cos(i * 0.9) * 42, Math.sin(i * 0.9) * 42)
      break
    }
    case 'Creator': {
      // Floating galleries, tilted frames and stairs that end in air.
      for (const [x, z, y, rot, sz] of [[-32, -10, 10, 0.3, 8], [34, -20, 15, -0.24, 7], [-20, 26, 19, 0.5, 6], [26, 24, 8, -0.4, 5]] as const) {
        frame(a, p, x, z, s * 2.2 * (sz / 8), rot, y, 0.05)
      }
      for (let i = 0; i < 5; i++) {
        const t = (i / 5) * TAU + 0.5
        a.box([Math.cos(t) * 42, 6 + i * 2.4, Math.sin(t) * 42], [16, 0.6, 9], mixHex(c.base, c.mass, 0.4), [0, -t, 0.08], false, 'ceramic')
      }
      // Impossible stair: treads that climb into open air.
      for (let i = 0; i < 16; i++) {
        const t = i * 0.24
        a.box([Math.cos(t) * (18 + i * 1.1), 1 + i * 1.3, Math.sin(t) * (18 + i * 1.1)], [5, 0.4, 2.4], i % 2 ? c.mass : c.base, [0, -t, 0.04], false, 'ceramic')
      }
      scatter(a, p, Math.round(9 * d), 22, 46, 'gallery-sculpture', (x, z, i) => {
        const y = 8 + hash(i, 2) * 12
        a.add('orb', [x, y, z], [1.6 + hash(i, 3) * 2.4, 1.6, 1.6], mixHex(c.accent, c.secondary, hash(i, 4)), [hash(i, 5), hash(i, 6), 0], false, 'ceramic')
        a.beam([x, y, z], [x, 0.2, z], 0.06, c.trim, true)
      })
      break
    }
    case 'Space': {
      // Observatory shelf: domes, hangars, solar arrays and a docking spine.
      for (let i = 0; i < 4; i++) {
        const t = (i / 4) * TAU + 0.6
        const x = Math.cos(t) * 34
        const z = Math.sin(t) * 34
        a.add('pillar', [x, 2.2, z], [7, 4.4, 7], c.base, undefined, false, 'metal')
        a.add('orb', [x, 4.4, z], [7, 4.6, 7], mixHex(c.base, c.trim, 0.5), undefined, false, 'metal')
        a.ring([x, 2.6, z], 7.4, c.trim, undefined, false)
        push(a, 'box', [x, 1.6, z + 7.4], [3, 0.3, 0.2], c.glow, undefined, true)
      }
      // Solar arrays.
      for (const side of [-1, 1]) {
        for (let i = 0; i < 3; i++) {
          const x = side * (30 + i * 9)
          a.beam([x, 0, -38], [x, 10, -38], 0.4, c.trim, false, 'metal')
          a.box([x, 10.4, -38], [12, 0.3, 7], mixHex(c.base, c.secondary, 0.35), [0, 0, side * 0.24], false, 'ceramic')
          for (let g = 0; g < 5; g++) a.box([x, 10.45, -38 - 2.6 + g * 1.3], [12, 0.04, 0.1], c.trim, [0, 0, side * 0.24], false, 'metal')
        }
      }
      // Docking spine.
      for (let i = 0; i < 5; i++) {
        a.box([0, 8, -52 - i * 7], [3, 1.2, 6], c.base, undefined, false, 'metal')
        a.ring([0, 8, -52 - i * 7], 2.4, c.accent, [Math.PI / 2, 0, 0], true)
      }
      scatter(a, p, Math.round(8 * d), 22, 44, 'shelf-crater', (x, z, i) => {
        a.add('rock', [x, 0.8, z], [3 + hash(i, 2) * 3, 1.6, 2.6], shade(c.base, 0.05), [0, hash(i, 3) * 3, 0], false, 'stone')
        if (i % 3 === 0) a.add('pillar', [x, 4, z], [0.4, 8, 0.4], c.trim, undefined, false, 'metal')
      })
      break
    }
    case 'Robotics': {
      // Foundry line: halls, conveyors, arms, chimneys and a gantry crane.
      for (const [x, z, h, r] of [[-34, 8, 18, 0.1], [34, 4, 22, -0.12], [-28, -32, 16, 0.2], [30, -30, 20, -0.18]] as const) {
        hall(a, p, x, z, s * 1.1, r, h)
        gantry(a, p, x + Math.cos(r) * 12, z, s, r, h + 12)
      }
      for (const side of [-1, 1]) {
        conveyor(a, p, side * 26, 26, s * 0.8, side > 0 ? Math.PI / 2 : -Math.PI / 2, 30)
        chimney(a, p, side * 44, -12, s, 0, 34)
        chimney(a, p, side * 40, 30, s * 0.8, 0, 26)
      }
      // Half-built machine hulls on the deck.
      scatter(a, p, Math.round(10 * d), 22, 44, 'foundry-hull', (x, z, i) => {
        a.box([x, 2, z], [7, 4, 5], shade(c.base, 0.05), [0, hash(i, 2) * 1.2, 0], false, 'metal')
        for (let k = 0; k < 3; k++) push(a, 'box', [x, 4.4, z + (k - 1) * 1.6], [5, 0.2, 0.5], c.glow, undefined, true)
        if (i % 2 === 0) a.beam([x, 4, z], [x + 4, 9, z], 0.3, c.trim, false, 'metal')
      })
      break
    }
    case 'Community':
    default: {
      // Hearth terraces: homes, awnings, stalls, laundry and lantern strings.
      for (let i = 0; i < 14; i++) {
        const t = (i / 14) * TAU + 0.15
        const r = 34 + hash(i, 2) * 16
        house(a, p, Math.cos(t) * r, Math.sin(t) * r, s * (1 + hash(i, 3) * 0.4), -t + Math.PI / 2)
      }
      for (let i = 0; i < 6; i++) {
        const t = (i / 6) * TAU + 0.4
        const x = Math.cos(t) * 26
        const z = Math.sin(t) * 26
        a.add('pillar', [x, 1.6, z], [1.1, 3.2, 1.1], c.trim, undefined, false, 'wood')
        a.add('cone', [x, 3.6, z], [3.4, 1.6, 3.4], i % 2 ? c.mass : c.secondary, [0, Math.PI / 4, 0], false, 'ceramic')
        a.beam([x, 3, z], [Math.cos(t + 0.5) * 30, 3, Math.sin(t + 0.5) * 30], 0.06, c.glow, true)
      }
      scatter(a, p, Math.round(12 * d), 22, 48, 'hearth-craft', (x, z, i) => {
        a.box([x, 0.9, z], [2.6, 1.8, 1.4], mixHex(c.trim, c.base, 0.4), [0, hash(i, 2) * 3, 0], false, 'wood')
        if (i % 3 === 0) a.add('orb', [x, 3, z], [0.34, 0.44, 0.34], c.glow, undefined, true)
        if (i % 4 === 0) a.add('orb', [x + 2, 1.4, z], [2.2, 1.2, 2], mixHex(c.base, c.accent, 0.4), undefined, false, 'foliage')
      })
      for (const [x, z] of [[-18, 24], [20, 22], [-24, -22], [26, -20]] as const) {
        a.add('pillar', [x, 1.2, z], [1.4, 2.4, 1.4], c.trim, undefined, false, 'wood')
        a.box([x, 2.5, z], [4, 0.2, 2], mixHex(c.mass, c.base, 0.4), undefined, false, 'wood')
      }
      break
    }
  }

  // Shared civic furniture: benches, a low wall, and the entrance gate.
  const gateFinish: Finish = 'stone'
  for (const side of [-1, 1]) {
    a.add('pillar', [side * 6.5, 3, 50], [1.1, 6, 1.1], c.mass, undefined, false, gateFinish)
    push(a, 'orb', [side * 6.5, 6.4, 50], [0.4, 0.5, 0.4], c.glow, undefined, true)
  }
  a.box([0, 7.2, 50], [15, 0.7, 1.6], c.trim, undefined, false, 'metal')
  return a
}
