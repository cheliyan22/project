import { useEffect, useMemo, useRef, Suspense } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { CapsuleCollider, RigidBody, useBeforePhysicsStep, useRapier, type RapierRigidBody } from '@react-three/rapier'
import * as THREE from 'three'
import { Traveler, TravelerBoundary, type TravelerAction } from './Traveler'
import { useUI } from '@/planet/stores/ui'
import { useDistrictSignals } from '../environment/districtSignals'
import { WORLD_PROFILES, physicsAt } from '../worldManifest'
import type { CityId } from '../cityRegistry'
import { clearExplorationInput, explorationInput as input } from './input'
import { dampAngle } from '../motionMath'

export function Player({city, paused, reduced}: {city:CityId;paused:boolean;reduced:boolean}) {
  const {world,rapier} = useRapier(), {camera,gl,scene} = useThree()
  const body=useRef<RapierRigidBody>(null), visual=useRef<THREE.Group>(null), legs=useRef<THREE.Group>(null), arms=useRef<THREE.Group>(null)
  const vertical=useRef(0), grounded=useRef(false), gait=useRef(0), wasGrounded=useRef(false), landing=useRef(0), heading=useRef(Math.PI)
  const controller=useRef<ReturnType<typeof world.createCharacterController>|null>(null)
  const scratch=useMemo(()=>({target:new THREE.Vector3(),goal:new THREE.Vector3(),direction:new THREE.Vector3(),oldCamera:camera.position.clone(),oldRotation:camera.quaternion.clone()}),[camera])
  const action=useRef<TravelerAction>('Idle')
  const profile=WORLD_PROFILES[city]
  useEffect(()=>{
    const c=world.createCharacterController(.025);c.enableAutostep(.52,.25,false);c.enableSnapToGround(.25);c.setMaxSlopeClimbAngle(Math.PI*.28);c.setMinSlopeSlideAngle(Math.PI*.32);c.setApplyImpulsesToDynamicBodies(true);c.setCharacterMass(65);controller.current=c
    input.yaw=0;input.pitch=.32;input.distance=7;clearExplorationInput()
    const canvas=gl.domElement;canvas.tabIndex=0;canvas.focus()
    canvas.setAttribute('aria-label','Explore world. WASD or arrows to walk, Space to jump, Shift to sprint, E to inspect. Drag to look. Escape returns to overview.')
    const editing=(target:EventTarget|null)=>target instanceof HTMLElement && (!!target.closest('input,textarea,select,[contenteditable=true],dialog') || (!!target.closest('button') && !target.closest('.exploration-hud')) || target.isContentEditable)
    const keyDown=(event:KeyboardEvent)=>{
      const activatesButton=event.code==='Space' && event.target instanceof HTMLElement && !!event.target.closest('button')
      if(event.defaultPrevented||editing(event.target)||activatesButton)return
      if(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','ShiftLeft','ShiftRight','KeyE'].includes(event.code)) {
        event.preventDefault();input.keys.add(event.code)
        if(!event.repeat&&event.code==='Space')input.jump=true
        if(!event.repeat&&event.code==='KeyE')input.interact=true
      }
    }
    const keyUp=(event:KeyboardEvent)=>input.keys.delete(event.code)
    let pointer:number|null=null,lastX=0,lastY=0
    const down=(event:PointerEvent)=>{if(event.button!==0)return;canvas.focus({preventScroll:true});pointer=event.pointerId;lastX=event.clientX;lastY=event.clientY;canvas.setPointerCapture(pointer)}
    const move=(event:PointerEvent)=>{if(pointer!==event.pointerId)return;input.yaw-=(event.clientX-lastX)*.005;input.pitch=THREE.MathUtils.clamp(input.pitch+(event.clientY-lastY)*.004,-.1,1.1);lastX=event.clientX;lastY=event.clientY}
    const up=()=>{pointer=null}
    const wheel=(event:WheelEvent)=>{event.preventDefault();input.distance=THREE.MathUtils.clamp(input.distance+event.deltaY*.008,3,12)}
    const blur=()=>{clearExplorationInput();pointer=null}
    window.addEventListener('keydown',keyDown);window.addEventListener('keyup',keyUp);window.addEventListener('blur',blur);document.addEventListener('visibilitychange',blur)
    canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);canvas.addEventListener('wheel',wheel,{passive:false})
    return ()=>{
      world.removeCharacterController(c);controller.current=null;clearExplorationInput()
      window.removeEventListener('keydown',keyDown);window.removeEventListener('keyup',keyUp);window.removeEventListener('blur',blur);document.removeEventListener('visibilitychange',blur)
      canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',up);canvas.removeEventListener('wheel',wheel)
      canvas.removeAttribute('tabindex');camera.position.copy(scratch.oldCamera);camera.quaternion.copy(scratch.oldRotation)
    }
  },[city,gl,camera,world,controller,scratch])
  useEffect(()=>{if(paused)clearExplorationInput()},[paused])
  const nearest=useRef<{label:string;action:()=>void}|null>(null), prompt=useRef(''), scan=useRef(0)
  useBeforePhysicsStep(()=>{
    const rigid=body.current,c=controller.current;if(!rigid||!c)return
    const dt=world.timestep, p=rigid.translation(), collider=rigid.collider(0)
    if(paused){input.jump=false;input.interact=false;return}
    const has=(...codes:string[])=>codes.some(code=>input.keys.has(code))
    const forward=Number(has('KeyW','ArrowUp'))-Number(has('KeyS','ArrowDown')),right=Number(has('KeyD','ArrowRight'))-Number(has('KeyA','ArrowLeft'))
    const length=Math.hypot(forward,right)||1,speed=profile.speed*(has('ShiftLeft','ShiftRight')?1.65:1)
    const dx=(right*Math.cos(input.yaw)-forward*Math.sin(input.yaw))/length*speed, dz=(-forward*Math.cos(input.yaw)-right*Math.sin(input.yaw))/length*speed
    const physics=physicsAt(city,p.x,p.z),lowGravity=physics.lowGravity
    if(input.jump&&grounded.current)vertical.current=physics.jump
    input.jump=false
    vertical.current=Math.max(-30,vertical.current-physics.gravity*dt)
    c.computeColliderMovement(collider,{x:dx*dt,y:vertical.current*dt,z:dz*dt},rapier.QueryFilterFlags.EXCLUDE_SENSORS)
    const movement=c.computedMovement();grounded.current=c.computedGrounded()
    if(grounded.current&&vertical.current<0)vertical.current=-.5
    rigid.setNextKinematicTranslation({x:p.x+movement.x,y:p.y+movement.y,z:p.z+movement.z})
    if(p.y < -18 || Math.abs(p.x)>105 || Math.abs(p.z)>105) {rigid.setTranslation({x:profile.spawn[0],y:profile.spawn[1],z:profile.spawn[2]},true);vertical.current=0}
    if(dx||dz)heading.current=Math.atan2(dx,dz)
    gait.current+=Math.hypot(movement.x,movement.z)*2.1
    if(grounded.current&&!wasGrounded.current)landing.current=.15
    action.current=!grounded.current?(vertical.current>3?'Jump_Start':'Jump_Idle'):landing.current>0?'Jump_Land':Math.hypot(dx,dz)>.1?(has('ShiftLeft','ShiftRight')?'Running_A':'Walking_A'):'Idle'
    wasGrounded.current=grounded.current;landing.current=Math.max(0,landing.current-dt)
    if(visual.current){visual.current.rotation.y=dampAngle(visual.current.rotation.y,heading.current,14,dt);visual.current.position.y=-.9-landing.current*.4}
    if(legs.current)legs.current.children.forEach((leg,i)=>{leg.rotation.x=grounded.current&&Math.hypot(dx,dz)>.1?Math.sin(gait.current+i*Math.PI)*.6:grounded.current?0:-.35})
    if(arms.current)arms.current.children.forEach((arm,i)=>{arm.rotation.x=grounded.current&&Math.hypot(dx,dz)>.1?-Math.sin(gait.current+i*Math.PI)*.5:grounded.current?0:-.9})
    scan.current+=dt
    if(scan.current>.15){
      scan.current=0;nearest.current=null;let distance=5
      scene.traverse(object=>{
        const projectId=object.userData.projectId,discovery=object.userData.discovery
        if(!projectId&&!discovery)return
        object.getWorldPosition(scratch.target);const d=Math.hypot(scratch.target.x-p.x,scratch.target.z-p.z)
        if(d<distance){distance=d;nearest.current={label:projectId?'Inspect project':discovery,action:()=>projectId?useUI.getState().selectProject(projectId):useDistrictSignals.getState().open(city)}}
      })
      if(Math.hypot(p.x,p.z-10)<5&&!nearest.current)nearest.current={label:'Activate landmark',action:()=>useDistrictSignals.getState().open(city)}
      const label=nearest.current?.label??(lowGravity?'Low gravity · longer jumps':'')
      if(label!==prompt.current){prompt.current=label;window.dispatchEvent(new CustomEvent('reboot-exploration-prompt',{detail:label}))}
    }
    if(input.interact){input.interact=false;nearest.current?.action()}
    gl.domElement.dataset.playerPosition=[p.x,p.y,p.z].map(n=>n.toFixed(2)).join(',')
    gl.domElement.dataset.playerGrounded=String(grounded.current)
  })
  useFrame((_,delta)=>{
    const rigid=body.current;if(!rigid)return
    const p=rigid.translation();scratch.target.set(p.x,p.y+.6,p.z)
    const cp=Math.cos(input.pitch)
    scratch.goal.set(p.x+Math.sin(input.yaw)*input.distance*cp,p.y+.6+Math.sin(input.pitch)*input.distance,p.z+Math.cos(input.yaw)*input.distance*cp)
    scratch.direction.copy(scratch.goal).sub(scratch.target);const distance=scratch.direction.length();scratch.direction.normalize()
    const ray=new rapier.Ray(scratch.target,scratch.direction)
    const hit=world.castRay(ray,distance+.35,true,rapier.QueryFilterFlags.EXCLUDE_SENSORS,undefined,undefined,rigid)
    if(hit)scratch.goal.copy(scratch.target).addScaledVector(scratch.direction,Math.max(.65,hit.timeOfImpact-.35))
    camera.position.lerp(scratch.goal,reduced?1:1-Math.exp(-Math.min(delta,.1)*12))
    // Test the smoothed position too: smoothing must not carry the camera through a wall.
    scratch.direction.copy(camera.position).sub(scratch.target);const smoothed=scratch.direction.length();scratch.direction.normalize()
    const blocked=world.castRay(new rapier.Ray(scratch.target,scratch.direction),smoothed,true,rapier.QueryFilterFlags.EXCLUDE_SENSORS,undefined,undefined,rigid)
    if(blocked)camera.position.copy(scratch.target).addScaledVector(scratch.direction,Math.max(.65,blocked.timeOfImpact-.35))
    camera.lookAt(scratch.target)
  })
  return <RigidBody ref={body} type="kinematicPosition" position={profile.spawn} colliders={false} enabledRotations={[false,false,false]} name="reboot-explorer">
    <CapsuleCollider args={[.55,.32]} friction={0}/>
    <group ref={visual} position={[0,-.9,0]}>
      <TravelerBoundary fallback={<group>      <mesh position={[0,1.15,0]}><boxGeometry args={[.58,.65,.36]}/><meshStandardMaterial color="#e4e1d7" roughness={.7}/></mesh>
      <mesh position={[0,1.7,0]}><sphereGeometry args={[.3,12,10]}/><meshStandardMaterial color="#a7bec8" metalness={.4} roughness={.35}/></mesh>
      <mesh position={[0,1.73,.255]}><boxGeometry args={[.35,.11,.1]}/><meshBasicMaterial color="#60ded5"/></mesh>
      <mesh position={[0,1.1,-.24]}><boxGeometry args={[.4,.5,.18]}/><meshStandardMaterial color="#546579"/></mesh>
      <group ref={legs} position={[0,.8,0]}>{[-1,1].map(side=><group key={side} position={[side*.17,0,0]}><mesh position={[0,-.35,0]}><boxGeometry args={[.22,.7,.25]}/><meshStandardMaterial color="#435868"/></mesh><mesh position={[0,-.68,.07]}><boxGeometry args={[.24,.12,.38]}/><meshStandardMaterial color="#273b4d"/></mesh></group>)}</group>
      <group ref={arms} position={[0,1.43,0]}>{[-1,1].map(side=><group key={side} position={[side*.4,0,0]}><mesh position={[0,-.28,0]}><boxGeometry args={[.17,.58,.19]}/><meshStandardMaterial color="#b3bfbe"/></mesh></group>)}</group></group>}><Suspense fallback={<group>      <mesh position={[0,1.15,0]}><boxGeometry args={[.58,.65,.36]}/><meshStandardMaterial color="#e4e1d7" roughness={.7}/></mesh>
      <mesh position={[0,1.7,0]}><sphereGeometry args={[.3,12,10]}/><meshStandardMaterial color="#a7bec8" metalness={.4} roughness={.35}/></mesh>
      <mesh position={[0,1.73,.255]}><boxGeometry args={[.35,.11,.1]}/><meshBasicMaterial color="#60ded5"/></mesh>
      <mesh position={[0,1.1,-.24]}><boxGeometry args={[.4,.5,.18]}/><meshStandardMaterial color="#546579"/></mesh>
      <group ref={legs} position={[0,.8,0]}>{[-1,1].map(side=><group key={side} position={[side*.17,0,0]}><mesh position={[0,-.35,0]}><boxGeometry args={[.22,.7,.25]}/><meshStandardMaterial color="#435868"/></mesh><mesh position={[0,-.68,.07]}><boxGeometry args={[.24,.12,.38]}/><meshStandardMaterial color="#273b4d"/></mesh></group>)}</group>
      <group ref={arms} position={[0,1.43,0]}>{[-1,1].map(side=><group key={side} position={[side*.4,0,0]}><mesh position={[0,-.28,0]}><boxGeometry args={[.17,.58,.19]}/><meshStandardMaterial color="#b3bfbe"/></mesh></group>)}</group></group>}><Traveler action={action} paused={paused}/></Suspense></TravelerBoundary>
    </group>
  </RigidBody>
}
