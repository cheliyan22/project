import { describe, expect, it } from 'vitest'
import * as THREE from 'three'
import { buildNexusGate } from './NexusGate'
import type { Architecture, Part, Vec } from '../modules/cityworld/environment/ScenePrimitives'
import type { Finish } from '../modules/cityworld/environment/SurfaceMaterials'

/* The Building shop now makes geometric claims about the flagship design, so
   they are checked geometrically instead of by eye:
     · "a gate you can walk through"
     · "an aperture cut through the roof"
   plus the placement and art-direction invariants the rebuild has to keep:
   nothing may leak out of the 2 x 2 block and nothing may float free.
   The rules below mirror exploration/collisionGeometry.ts exactly: a part joins
   the static collider mesh when it is not glow and its largest dimension is at
   least 0.4. Anything else is paint. */

const STYLE: { exterior: string; lighting: string; finish: Finish } =
  { exterior: '#20242d', lighting: '#36e4ff', finish: 'metal' }

/** Collects the parts a build would emit, without mounting a scene. */
function collector(): Architecture {
  const parts: Part[] = []
  const api = {
    parts,
    add(shape: Part['shape'], p: Vec, s: Vec, color: string, r: Vec, glow: boolean, finish?: Part['finish']) {
      parts.push({ shape, p, s, r, color, glow, finish })
    },
    box(p: Vec, s: Vec, color: string, r: Vec = [0, 0, 0], glow = false, finish?: Part['finish']) {
      api.add('box', p, s, color, r, glow, finish)
    },
    ring(p: Vec, radius: number, color: string, r: Vec = [Math.PI / 2, 0, 0], glow = true) {
      api.add('ring', p, [radius, radius, radius], color, r, glow)
    },
  }
  return api as unknown as Architecture
}

function build(detailed: boolean) {
  const solid = collector()
  buildNexusGate(solid, collector(), STYLE, detailed)
  return solid.parts
    .filter(part => !part.glow && Math.max(...part.s) >= 0.4 && part.shape !== 'ring')
    .map(part => {
      const rotation = new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(...part.r))
      const e = rotation.elements // column-major: row i is e[i], e[i + 4], e[i + 8]
      const half = [0, 1, 2].map(axis =>
        (Math.abs(e[axis]) * part.s[0] + Math.abs(e[axis + 4]) * part.s[1] + Math.abs(e[axis + 8]) * part.s[2]) / 2) as Vec
      return {
        label: `${part.shape} ${part.color} @ [${part.p.map(n => n.toFixed(2)).join(', ')}]`,
        min: part.p.map((position, axis) => position - half[axis]) as Vec,
        max: part.p.map((position, axis) => position + half[axis]) as Vec,
      }
    })
}

type Box = { label: string; min: Vec; max: Vec }

/** True when two volumes genuinely interpenetrate; a shared face is not a block. */
const bites = (a: Box, b: Box, tolerance = 0) => a.min.every((value, axis) => value < b.max[axis] - tolerance) &&
  a.max.every((value, axis) => value > b.min[axis] + tolerance)

const CORRIDOR: Box = { label: 'gate corridor', min: [-1.6, 0.45, -3.2], max: [1.6, 2.2, 3.2] }
const APERTURE: Box = { label: 'crown aperture', min: [-1.15, 9.2, 0.7], max: [2.55, 9.55, 3.35] }

describe('Reboot Nexus — The Canopied Gate', () => {
  it('leaves the ground level walkable for the explorer capsule', () => {
    for (const detailed of [false, true]) {
      const blockers = build(detailed).filter(box => bites(box, CORRIDOR))
      expect(blockers.map(box => box.label), `detailed=${detailed}`).toEqual([])
    }
  })

  it('floors that corridor and stands the mass on piers either side of it', () => {
    const colliders = build(false)
    const floor = colliders.filter(box => Math.abs(box.max[1] - 0.4) < 0.01 &&
      box.min[0] <= -1.6 && box.max[0] >= 1.6 && box.min[2] <= -3.2 && box.max[2] >= 3.2)
    expect(floor.length, 'a continuous walkable floor under the gate').toBeGreaterThan(0)
    for (const side of [-1, 1]) {
      const pier = colliders.filter(box => box.min[1] <= 0.6 && box.max[1] >= 4.0 &&
        (side === 1 ? box.min[0] : -box.max[0]) >= 1.9 && (side === 1 ? box.min[0] : -box.max[0]) <= 2.2)
      expect(pier.length, `the ${side === 1 ? 'east' : 'west'} pier`).toBeGreaterThan(0)
    }
  })

  it('cuts the aperture right through the crown roof band', () => {
    const blockers = build(true).filter(box => bites(box, APERTURE))
    expect(blockers.map(box => box.label)).toEqual([])
  })

  it('keeps every collider inside the 2 x 2 placement block', () => {
    // Placement anchors a building at a grid line, so the visible block is ±6 units.
    const escaping = build(true).filter(box => Math.abs(box.min[0]) > 6 || Math.abs(box.max[0]) > 6 ||
      Math.abs(box.min[2]) > 6 || Math.abs(box.max[2]) > 6)
    expect(escaping.map(box => box.label)).toEqual([])
  })

  it('floats nothing: every collider rests on the ground or joins another one', () => {
    const colliders = build(true)
    const adrift = colliders.filter(box => box.min[1] > 0.33 &&
      !colliders.some(other => other !== box && bites(box, other, -0.005)))
    expect(adrift.map(box => box.label)).toEqual([])
  })

  it('reads as a horizontal composition, not a skyscraper', () => {
    const colliders = build(true)
    const width = Math.max(...colliders.map(box => box.max[0])) - Math.min(...colliders.map(box => box.min[0]))
    const height = Math.max(...colliders.map(box => box.max[1]))
    expect(width).toBeGreaterThan(height)
    expect(height).toBeLessThan(12)
  })
})
