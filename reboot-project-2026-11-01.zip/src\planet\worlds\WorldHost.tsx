import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { Parts, useEnvironment } from '@/planet/modules/cityworld/environment/ScenePrimitives'
import { CityLandmark } from '@/planet/modules/cityworld/environment/Landmarks'
import type { CityId } from '@/planet/modules/cityworld/cityRegistry'
import { buildTerrain } from './kit/terrain'
import { buildFabric } from './kit/blocks'
import { AmbientMotes, CloudSea, GroundMist, LightShafts, WaterTable, WorldSky } from './kit/atmosphere'
import { WORLDS } from './profiles'
import { TAU } from './kit/math'

/** One moving set piece per city: meaningful activity, not decorative particles. */
function DistrictMotion({ city }: { city: CityId }) {
  const { reduced, lowEffects } = useEnvironment()
  const group = useRef<THREE.Group>(null)
  const secondary = useRef<THREE.Group>(null)
  const profile = WORLDS[city]

  useFrame((state, delta) => {
    if (reduced) return
    const t = state.clock.elapsedTime
    const dt = Math.min(delta, 0.1)
    if (group.current) {
      switch (city) {
        case 'Space':
          group.current.rotation.y += dt * 0.05
          break
        case 'AI':
          group.current.rotation.y += dt * 0.11
          break
        case 'Graveyard':
          group.current.rotation.y += dt * 0.035
          break
        case 'Creator':
          group.current.rotation.y += dt * 0.08
          group.current.rotation.x = Math.sin(t * 0.2) * 0.05
          break
        case 'Robotics':
          group.current.position.z = ((t * 3) % 46) - 23
          break
        case 'IdeaHub':
          group.current.position.x = Math.sin(t * 0.32) * 8
          group.current.position.y = 14 + Math.sin(t * 0.8) * 2.2
          break
        case 'Gaming':
          group.current.position.y = 13 + Math.sin(t * 0.7) * 1.6
          break
        case 'Legend':
          group.current.rotation.y += dt * 0.04
          break
        case 'Education':
        case 'Community':
          group.current.rotation.z = Math.sin(t * 0.6) * 0.06
          break
        case 'Health':
          group.current.position.y = 26 + Math.sin(t * 0.35) * 1.2
          break
        default:
          break
      }
    }
    if (secondary.current) {
      secondary.current.rotation.y -= dt * 0.06
      if (city === 'Community' || city === 'Education') secondary.current.position.y = 10 + Math.sin(t * 0.5 + 1) * 0.5
    }
  })

  const accent = profile.palette.accent
  const trim = profile.palette.trim
  const glow = profile.palette.glow

  return (
    <group name={`${city}-motion`}>
      {city === 'Graveyard' && (
        <group ref={group} position={[0, 22, -6]}>
          {[0, 1, 2, 3, 4, 5].map(i => (
            <mesh key={i} position={[Math.cos((i / 6) * TAU) * 11, Math.sin(i * 1.7) * 3, Math.sin((i / 6) * TAU) * 11]}>
              <boxGeometry args={[1.6 + (i % 3), 0.5, 1.2]} />
              <meshStandardMaterial color={trim} metalness={0.4} roughness={0.7} />
            </mesh>
          ))}
        </group>
      )}
      {city === 'IdeaHub' && (
        <group ref={group} position={[0, 14, -18]}>
          <mesh>
            <boxGeometry args={[6, 1.1, 6]} />
            <meshStandardMaterial color={trim} metalness={0.8} roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.85, 0]}>
            <boxGeometry args={[2.4, 0.5, 2.4]} />
            <meshBasicMaterial color={glow} toneMapped={false} />
          </mesh>
          <mesh position={[0, 6, 0]}>
            <boxGeometry args={[0.12, 12, 0.12]} />
            <meshStandardMaterial color={trim} metalness={0.7} roughness={0.5} />
          </mesh>
        </group>
      )}
      {city === 'Legend' && (
        <group ref={group} position={[0, 44, 0]}>
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[7, 0.1, 6, 64]} />
            <meshBasicMaterial color={accent} toneMapped={false} transparent opacity={0.75} />
          </mesh>
        </group>
      )}
      {city === 'AI' && (
        <group ref={group} position={[0, 26, 0]}>
          {[6.5, 9.5, 12.5].map((r, i) => (
            <mesh key={r} rotation={[Math.PI / 2 + i * 0.22, i * 0.5, 0]}>
              <torusGeometry args={[r, 0.08, 6, lowEffects ? 32 : 72]} />
              <meshBasicMaterial color={i === 1 ? profile.palette.secondary : accent} toneMapped={false} transparent opacity={0.7} />
            </mesh>
          ))}
          <mesh position={[0, 0, 0]}>
            <octahedronGeometry args={[1.5]} />
            <meshBasicMaterial color={glow} toneMapped={false} />
          </mesh>
        </group>
      )}
      {city === 'Gaming' && (
        <group ref={group} position={[0, 13, -26]}>
          <mesh>
            <boxGeometry args={[9, 0.7, 9]} />
            <meshStandardMaterial color={trim} metalness={0.5} roughness={0.4} />
          </mesh>
          <mesh position={[0, 2.6, 0]}>
            <octahedronGeometry args={[1.8]} />
            <meshBasicMaterial color={accent} toneMapped={false} />
          </mesh>
          <mesh position={[0, -0.8, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[3.4, 3.9, 32]} />
            <meshBasicMaterial color={profile.palette.secondary} toneMapped={false} side={THREE.DoubleSide} transparent opacity={0.6} />
          </mesh>
        </group>
      )}
      {city === 'Education' && (
        <group ref={group} position={[0, 22, 0]}>
          {Array.from({ length: 7 }, (_, i) => (
            <mesh key={i} position={[Math.cos((i / 7) * TAU) * 9, Math.sin(i * 1.3) * 2, Math.sin((i / 7) * TAU) * 9]}>
              <boxGeometry args={[2.4, 0.12, 1.6]} />
              <meshBasicMaterial color={glow} toneMapped={false} transparent opacity={0.8} />
            </mesh>
          ))}
        </group>
      )}
      {city === 'Health' && (
        <group ref={group} position={[0, 26, 0]}>
          {Array.from({ length: 5 }, (_, i) => (
            <mesh key={i} rotation={[Math.PI / 2, 0, (i / 5) * TAU]}>
              <torusGeometry args={[9 - i * 1.2, 0.06, 6, 48, Math.PI * 1.2]} />
              <meshBasicMaterial color={accent} toneMapped={false} transparent opacity={0.45} />
            </mesh>
          ))}
        </group>
      )}
      {city === 'Creator' && (
        <group ref={group} position={[0, 20, 0]}>
          {Array.from({ length: 8 }, (_, i) => (
            <mesh key={i} position={[Math.cos((i / 8) * TAU) * 10, Math.sin(i * 1.9) * 4, Math.sin((i / 8) * TAU) * 10]} rotation={[i * 0.4, i * 0.7, i * 0.2]}>
              <boxGeometry args={[2.6, 1.8, 0.14]} />
              <meshStandardMaterial color={i % 2 ? profile.palette.secondary : accent} metalness={0.4} roughness={0.3} emissive={accent} emissiveIntensity={0.25} />
            </mesh>
          ))}
        </group>
      )}
      {city === 'Space' && (
        <group ref={group} position={[0, 20, 0]}>
          <mesh rotation={[0.5, 0, 0.2]}>
            <ringGeometry args={[13, 13.4, 64]} />
            <meshBasicMaterial color={accent} toneMapped={false} side={THREE.DoubleSide} transparent opacity={0.5} />
          </mesh>
          <mesh position={[13, 0, 0]}>
            <boxGeometry args={[1.6, 0.3, 0.8]} />
            <meshBasicMaterial color={glow} toneMapped={false} />
          </mesh>
        </group>
      )}
      {city === 'Robotics' && (
        <group ref={group} position={[26, 4.2, 0]}>
          <mesh>
            <boxGeometry args={[2.4, 1.6, 3]} />
            <meshStandardMaterial color={profile.palette.base} metalness={0.85} roughness={0.35} />
          </mesh>
          <mesh position={[0, 1, 0]}>
            <boxGeometry args={[1.4, 0.2, 2.2]} />
            <meshBasicMaterial color={glow} toneMapped={false} />
          </mesh>
        </group>
      )}
      {(city === 'Community') && (
        <>
          <group ref={group} position={[0, 12, 18]}>
            {Array.from({ length: 9 }, (_, i) => (
              <mesh key={i} position={[(i - 4) * 2.4, Math.sin(i * 1.1) * 0.5, Math.cos(i) * 0.6]}>
                <sphereGeometry args={[0.32, 8, 6]} />
                <meshBasicMaterial color={glow} toneMapped={false} />
              </mesh>
            ))}
          </group>
          <group ref={secondary} position={[24, 10, 14]}>
            {Array.from({ length: 6 }, (_, i) => (
              <mesh key={i} position={[(i - 2.5) * 2.2, 0, 0]}>
                <sphereGeometry args={[0.28, 8, 6]} />
                <meshBasicMaterial color={profile.palette.secondary} toneMapped={false} />
              </mesh>
            ))}
          </group>
        </>
      )}
    </group>
  )
}

export function WorldHost({ city }: { city: CityId }) {
  const profile = WORLDS[city]
  const { lowEffects } = useEnvironment()
  const terrain = useMemo(() => buildTerrain(city, profile), [city, profile])
  const fabric = useMemo(() => buildFabric(city, profile), [city, profile])

  return (
    <group name={`${city}-world`}>
      <WorldSky profile={profile} />
      <Parts solid data={terrain} name={`${city}-terrain`} />
      <Parts data={fabric} name={`${city}-fabric`} />
      <CityLandmark city={city} />
      <DistrictMotion city={city} />
      <GroundMist profile={profile} />
      <LightShafts profile={profile} />
      <AmbientMotes profile={profile} />
      {city === 'Legend' && <CloudSea profile={profile} />}
      {city === 'Health' && !lowEffects && <WaterTable profile={profile} />}
    </group>
  )
}
