import { useMemo } from 'react'
import { BackSide, Color, Vector3 } from 'three'
import type { Vec } from './ScenePrimitives'

const vertexShader = `varying vec3 vNormal;varying vec3 vWorld;varying vec3 vLocal;
void main(){vLocal=position;vNormal=normalize(mat3(modelMatrix)*normal);vWorld=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(vWorld,1.);}`
const noise = `float hash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
return mix(mix(mix(hash(i),hash(i+vec3(1,0,0)),f.x),mix(hash(i+vec3(0,1,0)),hash(i+vec3(1,1,0)),f.x),f.y),mix(mix(hash(i+vec3(0,0,1)),hash(i+vec3(1,0,1)),f.x),mix(hash(i+vec3(0,1,1)),hash(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm(vec3 p){return noise(p)*.57+noise(p*2.03)*.28+noise(p*4.01)*.15;}`

/** Distant planetary landmarks: procedural continents/bands, terminator and atmospheric limb. */
export function CelestialPlanet({position,radius,gas=false}:{position:Vec;radius:number;gas?:boolean}) {
  const uniforms=useMemo(()=>({sea:{value:new Color(gas?'#76658e':'#274f77')},land:{value:new Color(gas?'#cbb397':'#80a393')},sun:{value:new Vector3(-.5,.55,.7).normalize()},gas:{value:gas?1:0}}),[gas])
  return <group position={position} rotation={[.2,0,-.25]} name={gas?'ringed-planet':'ocean-planet'}>
    <mesh scale={radius}><sphereGeometry args={[1,48,32]}/><shaderMaterial uniforms={uniforms} vertexShader={vertexShader} fragmentShader={`
      varying vec3 vNormal;varying vec3 vWorld;varying vec3 vLocal;uniform vec3 sea;uniform vec3 land;uniform vec3 sun;uniform float gas;
      ${noise}
      void main(){vec3 n=normalize(vNormal);vec3 p=normalize(vLocal);float terrain=fbm(p*4.+3.);
      float pattern=gas>.5?.5+.5*sin(p.y*36.+terrain*7.):smoothstep(.46,.58,terrain);
      vec3 base=mix(sea,land,pattern);float cloud=smoothstep(.63,.8,fbm(p*9.+17.));base=mix(base,vec3(.85,.9,.91),cloud*.7);
      float light=smoothstep(-.22,.85,dot(n,sun));vec3 view=normalize(cameraPosition-vWorld);float rim=pow(1.-max(0.,dot(n,view)),3.);
      gl_FragColor=vec4(base*(.1+light*.95)+vec3(.2,.43,.67)*rim*light*.6,1.);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      }`}/></mesh>
    <mesh scale={radius*1.035}><sphereGeometry args={[1,40,24]}/><shaderMaterial side={BackSide} transparent depthWrite={false} uniforms={uniforms} vertexShader={vertexShader} fragmentShader={`
      varying vec3 vNormal;varying vec3 vWorld;uniform vec3 sun;
      void main(){vec3 n=normalize(vNormal);float edge=pow(1.-abs(dot(n,normalize(cameraPosition-vWorld))),3.);float day=smoothstep(-.3,.8,dot(n,sun));gl_FragColor=vec4(vec3(.35,.62,.89),edge*day*.55);
      #include <colorspace_fragment>
      }`}/></mesh>
    {gas&&<mesh rotation={[Math.PI/2,.12,0]}><ringGeometry args={[radius*1.3,radius*2.1,128]}/><meshStandardMaterial color="#a7a0bc" roughness={.9} transparent opacity={.5} side={2} depthWrite={false}/></mesh>}
  </group>
}
