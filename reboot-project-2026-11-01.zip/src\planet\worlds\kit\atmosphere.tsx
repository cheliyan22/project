import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useEnvironment } from '@/planet/modules/cityworld/environment/ScenePrimitives'
import type { WorldProfile } from '../types'
import { stream, TAU } from './math'

const skyVertex = `
  varying vec3 vDir;
  void main(){
    vDir = normalize(position);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }`

const skyFragment = `
  #include <common>
  #include <dithering_pars_fragment>
  varying vec3 vDir;
  uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uGround; uniform vec3 uSun;
  uniform vec3 uSunDir; uniform float uTime; uniform float uNight; uniform float uStars;
  uniform float uClouds; uniform float uHaze; uniform float uDetail;

  float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float noise(vec2 p){
    vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
  }
  float fbm(vec2 p){
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 5; i++){ v += a * noise(p); p *= 2.03; a *= 0.5; }
    return v;
  }
  // Star visibility falls away from the zenith.
  float starVisibility(float amount, float up){ return smoothstep(-0.05, 0.35, up) * (0.35 + amount * 0.9); }

  void main(){
    vec3 d = normalize(vDir);
    float up = clamp(d.y, -1.0, 1.0);

    // Vertical gradient with a compressed band at the horizon.
    vec3 color = mix(uHorizon, uTop, pow(clamp(up, 0.0, 1.0), 0.55));
    color = mix(color, uGround, smoothstep(0.0, -0.35, up));

    // Sun: tight disc, wide warm scatter.
    vec3 sunDir = normalize(uSunDir);
    float alignment = max(0.0, dot(d, sunDir));
    color += uSun * pow(alignment, 8.0) * 0.12 * (1.0 - uNight * 0.7);
    color += uSun * smoothstep(0.9988, 0.9996, alignment) * 1.6 * (1.0 - uNight);

    // Layered cloud deck, projected onto a plane above the viewer.
    if (uClouds > 0.01 && up > -0.02) {
      vec2 p = d.xz / max(0.1, up) * 1.25 + vec2(uTime * 0.004, uTime * 0.0018);
      float density = smoothstep(0.52, 0.78, fbm(p * (uDetail > 0.5 ? 2.4 : 1.3)));
      float fade = smoothstep(0.0, 0.16, up) * (1.0 - smoothstep(0.6, 1.0, up));
      vec3 cloudColor = mix(uHorizon * 0.9, uSun, 0.25) * (0.7 + uClouds * 0.5);
      color = mix(color, cloudColor, density * fade * uClouds * 0.85);
    }

    // Stars are only drawn where the sky is dark.
    if (uStars > 0.01) {
      vec2 uv = vec2(atan(d.z, d.x), asin(clamp(d.y, -1.0, 1.0)));
      vec2 grid = uv * vec2(260.0, 190.0);
      vec2 id = floor(grid);
      float seed = hash(id);
      float star = pow(max(0.0, 1.0 - length(fract(grid) - 0.5) * 2.0), 12.0) * step(0.988, seed);
      float twinkle = 0.75 + 0.25 * sin(uTime * 1.6 + hash(floor(d.xz * 90.0)) * 20.0);
      vec3 starColor = mix(vec3(0.66, 0.8, 1.0), vec3(1.0, 0.9, 0.74), hash(floor(d.zx * 60.0)));
      color += starColor * (smoothstep(0.75, 0.95, uStars) > 0.5 ? 1.0 : 0.6) * starVisibility(uStars, up) * star * twinkle * 1.4;
      // A faint dust band gives the void depth rather than flat black.
      float band = exp(-pow((up + 0.16 * sin(d.x * 3.4)) * 3.2, 2.0));
      color += vec3(0.12, 0.16, 0.28) * band * uStars * 0.35;
    }

    // Horizon haze.
    color += uHorizon * pow(1.0 - abs(up), 6.0) * uHaze * 0.22;

    gl_FragColor = vec4(color, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
    #include <dithering_fragment>
  }`

export function WorldSky({ profile }: { profile: WorldProfile }) {
  const { reduced } = useEnvironment()
  const material = useRef<THREE.ShaderMaterial>(null)
  const uniforms = useMemo(
    () => ({
      uTop: { value: new THREE.Color(profile.sky.top) },
      uHorizon: { value: new THREE.Color(profile.sky.horizon) },
      uGround: { value: new THREE.Color(profile.sky.ground) },
      uSun: { value: new THREE.Color(profile.sky.sun) },
      uSunDir: { value: new THREE.Vector3(...profile.sky.sunDir).normalize() },
      uTime: { value: 0 },
      uNight: { value: profile.sky.night ? 1 : 0 },
      uStars: { value: profile.sky.stars },
      uClouds: { value: profile.sky.clouds * (profile.atmosphere.motion === 'cloudsea' ? 1.15 : 1) },
      uHaze: { value: profile.sky.haze },
      uDetail: { value: 1 },
    }),
    [profile],
  )
  useFrame((_, delta) => {
    if (!material.current || reduced) return
    material.current.uniforms.uTime.value += Math.min(delta, 0.1)
  })
  return (
    <mesh name={`${profile.id}-sky`} renderOrder={-100} frustumCulled={false}>
      <sphereGeometry args={[520, 48, 32]} />
      <shaderMaterial
        ref={material}
        uniforms={uniforms}
        side={THREE.BackSide}
        depthWrite={false}
        dithering
        vertexShader={skyVertex}
        fragmentShader={skyFragment}
      />
    </mesh>
  )
}

/** Ground mist: a few bounded, depth-tested volumes instead of a full ray march. */
export function GroundMist({ profile }: { profile: WorldProfile }) {
  const { reduced, lowEffects } = useEnvironment()
  const shader = useRef<THREE.ShaderMaterial>(null)
  const uniforms = useMemo(
    () => ({
      uColor: { value: new THREE.Color(profile.atmosphere.mistColor) },
      uOpacity: { value: profile.atmosphere.mistOpacity * (lowEffects ? 0.4 : 1) },
      uTime: { value: 0 },
    }),
    [profile, lowEffects],
  )
  useFrame((_, delta) => {
    if (!shader.current || reduced) return
    shader.current.uniforms.uTime.value += Math.min(delta, 0.1)
  })
  const layers = lowEffects ? [3] : [2, 5.5, 10, 16]
  return (
    <group name={`${profile.id}-mist`}>
      {layers.map((y, i) => (
        <mesh key={y} position={[0, y, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[260 - i * 26, 260 - i * 26]} />
          <shaderMaterial
            ref={i === 0 ? shader : undefined}
            uniforms={uniforms}
            transparent
            depthWrite={false}
            vertexShader={`varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`}
            fragmentShader={`
              varying vec2 vUv; uniform vec3 uColor; uniform float uOpacity; uniform float uTime;
              float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
              float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
                return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y); }
              void main(){
                float d = length(vUv - 0.5) * 2.0;
                float falloff = smoothstep(1.0, 0.15, d);
                float n = noise(vUv * 7.0 + vec2(uTime * 0.02, uTime * 0.01)) * 0.6 + noise(vUv * 17.0 - uTime * 0.015) * 0.4;
                gl_FragColor = vec4(uColor, falloff * n * uOpacity);
              }`}
          />
        </mesh>
      ))}
    </group>
  )
}

/** Authored light shafts; only where a real opening or lamp justifies one. */
export function LightShafts({ profile }: { profile: WorldProfile }) {
  const { lowEffects } = useEnvironment()
  if (!profile.atmosphere.shafts) return null
  const count = lowEffects ? Math.min(2, profile.atmosphere.shafts) : profile.atmosphere.shafts
  return (
    <group name={`${profile.id}-shafts`}>
      {Array.from({ length: count }, (_, i) => {
        const angle = (i / count) * TAU + 0.4
        const x = Math.cos(angle) * 34
        const z = Math.sin(angle) * 34
        return (
          <mesh key={i} position={[x, 16, z]} rotation={[0.12, angle, -0.18]}>
            <coneGeometry args={[7 + i * 2, 34, 16, 1, true]} />
            <meshBasicMaterial color={profile.sky.sun} transparent opacity={0.045} side={THREE.DoubleSide} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
          </mesh>
        )
      })}
    </group>
  )
}

/** Rain-free ambient particulate: ash, sparks, pages, fragments, lanterns. */
export function AmbientMotes({ profile }: { profile: WorldProfile }) {
  const { reduced, lowEffects } = useEnvironment()
  const points = useRef<THREE.Points>(null)
  const count = lowEffects ? 90 : 300
  const motion = profile.atmosphere.motion
  const data = useMemo(() => {
    const rnd = stream(`${profile.id}-motes`)
    const position = new Float32Array(count * 3)
    const seed = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      const a = rnd() * TAU
      const r = 8 + rnd() * 70
      position[i * 3] = Math.cos(a) * r
      position[i * 3 + 1] = rnd() * 46 - 4
      position[i * 3 + 2] = Math.sin(a) * r
      seed[i] = rnd()
    }
    return { position, seed }
  }, [count, profile.id])
  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(data.position.slice(), 3))
    g.setAttribute('seed', new THREE.BufferAttribute(data.seed, 1))
    return g
  }, [data])
  useFrame((state, delta) => {
    if (reduced || !points.current) return
    const attribute = points.current.geometry.getAttribute('position') as THREE.BufferAttribute
    const arr = attribute.array as Float32Array
    const t = state.clock.elapsedTime
    const dt = Math.min(delta, 0.1)
    for (let i = 0; i < count; i++) {
      const s = data.seed[i]
      if (motion === 'ash') {
        arr[i * 3 + 1] -= dt * (0.4 + s * 0.7)
        arr[i * 3] += Math.sin(t * 0.4 + s * 12) * dt * 0.35
      } else if (motion === 'sparks' || motion === 'forge') {
        arr[i * 3 + 1] += dt * (1.2 + s * 2.4)
        if (arr[i * 3 + 1] > 44) arr[i * 3 + 1] = -2
      } else if (motion === 'pages') {
        arr[i * 3 + 1] -= dt * (0.5 + s * 0.5)
        arr[i * 3] += Math.cos(t * 0.6 + s * 8) * dt * 0.6
        if (arr[i * 3 + 1] < -3) arr[i * 3 + 1] = 42
      } else if (motion === 'coins' || motion === 'lanterns') {
        arr[i * 3 + 1] += Math.sin(t * 0.5 + s * 20) * dt * 0.25
        arr[i * 3] += Math.cos(t * 0.3 + s * 12) * dt * 0.3
      } else if (motion === 'fragments') {
        const radius = Math.hypot(arr[i * 3], arr[i * 3 + 2])
        const angle = Math.atan2(arr[i * 3 + 2], arr[i * 3]) + dt * 0.06 * (s > 0.5 ? 1 : -1)
        arr[i * 3] = Math.cos(angle) * radius
        arr[i * 3 + 2] = Math.sin(angle) * radius
      } else if (motion === 'mist') {
        arr[i * 3 + 1] += dt * (0.2 + s * 0.2)
        if (arr[i * 3 + 1] > 20) arr[i * 3 + 1] = 0
      } else if (motion === 'starlight' || motion === 'pulse') {
        arr[i * 3 + 1] += Math.sin(t * 0.3 + s * 14) * dt * 0.15
      }
    }
    attribute.needsUpdate = true
  })

  const moteColor =
    motion === 'pulse' ? profile.palette.accent
      : motion === 'forge' ? profile.palette.secondary
        : motion === 'ash' ? profile.palette.secondary
          : profile.palette.glow
  const color = moteColor
  return (
    <points ref={points} geometry={geometry} frustumCulled={false}>
      <pointsMaterial color={color} size={motion === 'fragments' ? 0.8 : 0.42} sizeAttenuation transparent opacity={motion === 'ash' ? 0.5 : 0.6} depthWrite={false} toneMapped={false} />
    </points>
  )
}

/** Cloud sea under a cliff city. */
export function CloudSea({ profile }: { profile: WorldProfile }) {
  const { reduced } = useEnvironment()
  const shader = useRef<THREE.ShaderMaterial>(null)
  const uniforms = useMemo(() => ({ uTime: { value: 0 }, uWarm: { value: new THREE.Color(profile.sky.sun) }, uCool: { value: new THREE.Color(profile.sky.horizon) } }), [profile])
  useFrame((_, delta) => {
    if (!shader.current || reduced) return
    shader.current.uniforms.uTime.value += Math.min(delta, 0.1)
  })
  return (
    <mesh position={[0, -34, 0]} rotation={[-Math.PI / 2, 0, 0]} name={`${profile.id}-cloud-sea`}>
      <planeGeometry args={[620, 620, 1, 1]} />
      <shaderMaterial
        ref={shader}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        vertexShader={`varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`}
        fragmentShader={`
          varying vec2 vUv; uniform float uTime; uniform vec3 uWarm; uniform vec3 uCool;
          float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
          float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
            return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y); }
          void main(){
            vec2 p = vUv * 9.0 + vec2(uTime * 0.012, uTime * 0.006);
            float n = 0.0, a = 0.5;
            for (int i = 0; i < 5; i++){ p *= 1.9; n += a * hash(floor(p)); a *= 0.55; }
            float cloud = smoothstep(0.2, 0.95, n + hash(floor(p * 0.6)) * 0.4);
            vec3 color = mix(uCool * 0.55, uWarm * 0.95, n);
            float edge = smoothstep(0.0, 0.2, length(vUv - 0.5) * 1.6);
            gl_FragColor = vec4(color, clamp(n * 0.9, 0.0, 0.85) * (0.55 + edge * 0.45));
          }`}
      />
    </mesh>
  )
}

/** Shallow water for the tidal city. */
export function WaterTable({ profile }: { profile: WorldProfile }) {
  const { reduced, lowEffects } = useEnvironment()
  const shader = useRef<THREE.ShaderMaterial>(null)
  const uniforms = useMemo(
    () => ({ uTime: { value: 0 }, uDeep: { value: new THREE.Color(profile.palette.base) }, uShallow: { value: new THREE.Color(profile.palette.secondary) } }),
    [profile],
  )
  useFrame((_, delta) => {
    if (!shader.current || reduced) return
    shader.current.uniforms.uTime.value += Math.min(delta, 0.1)
  })
  return (
    <mesh position={[0, -24, 0]} rotation={[-Math.PI / 2, 0, 0]} name={`${profile.id}-water`}>
      <circleGeometry args={[210, lowEffects ? 32 : 72]} />
      <shaderMaterial
        ref={shader}
        uniforms={uniforms}
        vertexShader={`varying vec2 vP; void main(){ vP = position.xy; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`}
        fragmentShader={`
          varying vec2 vP; uniform float uTime; uniform vec3 uDeep; uniform vec3 uShallow;
          void main(){
            float wave = sin(vP.x * 0.12 + uTime * 0.5) * sin(vP.y * 0.14 - uTime * 0.4);
            float ripple = pow(0.5 + 0.5 * sin(length(vP) * 0.35 - uTime * 1.2), 12.0);
            vec3 color = mix(uDeep * 0.7, uShallow * 0.8, 0.18 + wave * 0.08 + ripple * 0.35);
            gl_FragColor = vec4(color, 1.0);
            #include <tonemapping_fragment>
            #include <colorspace_fragment>
          }`}
      />
    </mesh>
  )
}
