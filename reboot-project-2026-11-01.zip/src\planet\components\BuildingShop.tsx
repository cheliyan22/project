import { useEffect, useId, useMemo, useRef, useState, type KeyboardEvent as ReactKeyboardEvent } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import {
  AlertTriangle,
  Check,
  Coins,
  LockKeyhole,
  MapPin,
  RefreshCw,
  RotateCcw,
  Save,
  ShoppingBag,
  Trash2,
  X,
} from 'lucide-react'
import { BuildingModel } from '@/planet/buildings/BuildingModel'
import {
  BUILDING_DEFINITIONS,
  DEFAULT_NEXUS_CUSTOMIZATION,
  getBuildingDefinition,
  normalizeBuildingCustomization,
  type BuildingAccessory,
  type BuildingCustomization,
  type BuildingId,
} from '@/planet/buildings/catalog'
import { awardAchievements, awardMessage } from '@/lib/achievements'
import { EnvironmentSettings } from '@/planet/modules/cityworld/environment/ScenePrimitives'
import { SurfaceProvider } from '@/planet/modules/cityworld/environment/SurfaceMaterials'
import { useEconomy, type OwnershipRecord, type PlacementRecord } from '@/planet/stores/economy'

type Tab = 'catalogue' | 'owned' | 'wallet'
type PlacementTarget = { x: number; z: number; rotation: number }

const TABS: readonly { id: Tab; label: string }[] = [
  { id: 'catalogue', label: 'Catalogue' },
  { id: 'owned', label: 'Owned' },
  { id: 'wallet', label: 'Wallet' },
]
const FINISHES: readonly BuildingCustomization['finish'][] = ['metal', 'concrete', 'obsidian', 'wood', 'glass']
const ACCESSORIES: readonly { id: BuildingAccessory; label: string }[] = [
  { id: 'antenna', label: 'Antenna' },
  { id: 'holo-sign', label: 'Holo sign' },
  { id: 'garden', label: 'Garden' },
  { id: 'solar-array', label: 'Solar array' },
]
const DEFAULT_PLACEMENT: PlacementTarget = { x: 0, z: 0, rotation: 0 }

function gridSize(id: BuildingId) {
  return id === 'reboot-nexus' ? 2 : 1
}

/** Mirrors the server footprint rules so a collision is shown before the RPC is tried. */
function footprintOf(id: BuildingId, rotation: number) {
  const footprint = getBuildingDefinition(id).footprint
  return rotation % 2 === 1 ? { width: footprint.depth, depth: footprint.width } : { width: footprint.width, depth: footprint.depth }
}

function occupiedCells(placements: PlacementRecord[], ownership: OwnershipRecord[], excludeId?: string | null): Map<string, string> {
  const cells = new Map<string, string>()
  for (const placement of placements) {
    if (placement.id === excludeId) continue
    const definitionId = placement.free_definition_id ?? ownership.find(item => item.id === placement.ownership_id)?.definition_id
    if (!definitionId) continue
    const definition = BUILDING_DEFINITIONS.find(item => item.id === definitionId)
    if (!definition) continue
    const size = footprintOf(definitionId, placement.rotation)
    for (let x = placement.grid_x; x < placement.grid_x + size.width; x++) {
      for (let z = placement.grid_z; z < placement.grid_z + size.depth; z++) cells.set(`${x},${z}`, definition.name)
    }
  }
  return cells
}

function conflictLabel(target: PlacementTarget, id: BuildingId, cells: Map<string, string>): string | null {
  const size = footprintOf(id, target.rotation)
  if (Math.abs(target.x) > 12 || Math.abs(target.z) > 12 || target.x + size.width - 1 > 12 || target.z + size.depth - 1 > 12) return 'the world edge'
  for (let x = target.x; x < target.x + size.width; x++) {
    for (let z = target.z; z < target.z + size.depth; z++) {
      const name = cells.get(`${x},${z}`)
      if (name) return name
    }
  }
  return null
}

function findFreeAnchor(id: BuildingId, rotation: number, cells: Map<string, string>): PlacementTarget | null {
  const size = footprintOf(id, rotation)
  const candidates: PlacementTarget[] = []
  for (let x = -12; x <= 12 - size.width + 1; x++) {
    for (let z = -12; z <= 12 - size.depth + 1; z++) candidates.push({ x, z, rotation })
  }
  candidates.sort((a, b) => (Math.abs(a.x) + Math.abs(a.z)) - (Math.abs(b.x) + Math.abs(b.z)))
  return candidates.find(candidate => !conflictLabel(candidate, id, cells)) ?? null
}

function formatDate(value: string) {
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleDateString()
}

function ModelPreview({ definitionId, customization }: {
  definitionId: BuildingId
  customization?: Partial<BuildingCustomization>
}) {
  const definition = getBuildingDefinition(definitionId)
  const distance = definitionId === 'reboot-nexus' ? 24 : 14
  return <div className="building-shop-preview" aria-label={`${definition.name} 3D preview`}>
    <Canvas
      camera={{ position: [distance * .72, distance * .54, distance * .8], fov: 40, near: .1, far: 160 }}
      dpr={[1, 1.5]}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
    >
      <EnvironmentSettings.Provider value={{ reduced: true, lowEffects: false }}>
        <SurfaceProvider city="AI" low={false}>
          <ambientLight intensity={.75} />
          <hemisphereLight args={['#9fc8ea', '#10151c', 1.1]} />
          <directionalLight position={[10, 16, 8]} intensity={2.2} color="#d8efff" />
          <directionalLight position={[-8, 7, -10]} intensity={1.1} color="#ff4fd8" />
          <group position={[0, 0, 0]}>
            <BuildingModel definitionId={definitionId} customization={customization} detailed preview />
          </group>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.03, 0]}>
            <circleGeometry args={[gridSize(definitionId) * 4.9, 48]} />
            <meshStandardMaterial color="#111e28" roughness={.88} metalness={.2} />
          </mesh>
          <gridHelper args={[distance * 1.8, 12, '#244b5c', '#172d39']} position={[0, -.01, 0]} />
          <OrbitControls
            makeDefault
            target={[0, definitionId === 'reboot-nexus' ? 5 : 2.4, 0]}
            enablePan={false}
            enableDamping={false}
            minDistance={distance * .65}
            maxDistance={distance * 1.8}
            maxPolarAngle={Math.PI / 1.95}
          />
        </SurfaceProvider>
      </EnvironmentSettings.Provider>
    </Canvas>
  </div>
}

function PlacementControls({ target, id, disabled, onChange }: {
  target: PlacementTarget
  id: BuildingId
  disabled: boolean
  onChange: (target: PlacementTarget) => void
}) {
  const size = gridSize(id)
  const limit = 12 - size + 1
  const update = (patch: Partial<PlacementTarget>) => onChange({ ...target, ...patch })
  return <fieldset className="building-shop-placement" disabled={disabled}>
    <legend>Grid placement</legend>
    <p>Anchor cell on a 25 × 25 grid. This design occupies {size} × {size} {size === 1 ? 'cell' : 'cells'}.</p>
    <div className="building-shop-coordinates">
      <label>X <input type="number" min={-12} max={limit} step={1} value={target.x}
        onChange={event => update({ x: Math.max(-12, Math.min(limit, Math.round(Number(event.target.value) || 0))) })} /></label>
      <label>Z <input type="number" min={-12} max={limit} step={1} value={target.z}
        onChange={event => update({ z: Math.max(-12, Math.min(limit, Math.round(Number(event.target.value) || 0))) })} /></label>
    </div>
    <div className="building-shop-rotation" role="group" aria-label="Building rotation">
      {[0, 1, 2, 3].map(value => <button key={value} type="button" aria-pressed={target.rotation === value}
        onClick={() => update({ rotation: value })}>{value * 90}°</button>)}
    </div>
    <p className="building-shop-hint">Placements cannot overlap. Moving a building never removes its ownership.</p>
  </fieldset>
}

function CustomizationEditor({ ownershipId, saved, draft, onChange, disabled }: {
  ownershipId: string
  saved: Partial<BuildingCustomization>
  draft: BuildingCustomization
  onChange: (draft: BuildingCustomization) => void
  disabled: boolean
}) {
  const customize = useEconomy(state => state.customize)
  const [message, setMessage] = useState('')
  const normalizedSaved = normalizeBuildingCustomization(saved)
  const save = async () => {
    setMessage('')
    const ok = await customize(ownershipId, draft)
    setMessage(ok ? 'Customization saved to your permanent building.' : useEconomy.getState().error ?? 'Customization was not saved.')
  }
  const toggleAccessory = (accessory: BuildingAccessory, checked: boolean) => {
    onChange({
      ...draft,
      accessories: checked
        ? [...new Set([...draft.accessories, accessory])]
        : draft.accessories.filter(item => item !== accessory),
    })
  }
  return <section className="building-shop-customization">
    <div className="building-shop-section-head"><div><p className="label-mono">NEXUS FITTINGS</p><h3>Customize permanently</h3></div><span className="building-shop-safe"><Check size={12} /> No extra charge</span></div>
    <div className="building-shop-custom-grid">
      <label>Exterior color <input type="color" value={draft.exteriorColor} disabled={disabled}
        onChange={event => onChange({ ...draft, exteriorColor: event.target.value })} /></label>
      <label>Lighting color <input type="color" value={draft.lightingColor} disabled={disabled}
        onChange={event => onChange({ ...draft, lightingColor: event.target.value })} /></label>
      <label>Finish <select value={draft.finish} disabled={disabled}
        onChange={event => onChange({ ...draft, finish: event.target.value as BuildingCustomization['finish'] })}>
        {FINISHES.map(finish => <option key={finish} value={finish}>{finish}</option>)}
      </select></label>
    </div>
    <fieldset className="building-shop-accessories" disabled={disabled}>
      <legend>Accessories</legend>
      {ACCESSORIES.map(accessory => <label key={accessory.id}><input type="checkbox"
        checked={draft.accessories.includes(accessory.id)}
        onChange={event => toggleAccessory(accessory.id, event.target.checked)} /> {accessory.label}</label>)}
    </fieldset>
    <div className="building-shop-actions">
      <button type="button" className="btn btn-primary" disabled={disabled} onClick={() => void save()}><Save size={13} /> Save customization</button>
      <button type="button" className="btn" disabled={disabled} onClick={() => { onChange(normalizedSaved); setMessage('Restored the last saved appearance.') }}><RotorResetIcon /> Restore saved</button>
      <button type="button" className="btn" disabled={disabled} onClick={() => { onChange({ ...DEFAULT_NEXUS_CUSTOMIZATION }); setMessage('Reset to the default Nexus appearance. Save to keep it.') }}><RotateCcw size={13} /> Reset preview</button>
    </div>
    {message && <p className="building-shop-message" role="status">{message}</p>}
  </section>
}

function RotorResetIcon() {
  return <RefreshCw size={13} />
}

export function BuildingShop({ onClose }: { onClose: () => void }) {
  const titleId = useId()
  const dialog = useRef<HTMLElement>(null)
  const [tab, setTab] = useState<Tab>('catalogue')
  const [selectedId, setSelectedId] = useState<BuildingId>('starter-shack')
  const [target, setTarget] = useState<PlacementTarget>(DEFAULT_PLACEMENT)
  const [confirmPurchase, setConfirmPurchase] = useState(false)
  const [message, setMessage] = useState('')
  const balance = useEconomy(state => state.balance)
  const transactions = useEconomy(state => state.transactions)
  const ownership = useEconomy(state => state.ownership)
  const placements = useEconomy(state => state.placements)
  const loading = useEconomy(state => state.loading)
  const busy = useEconomy(state => state.busy)
  const error = useEconomy(state => state.error)
  const dailyRemaining = useEconomy(state => state.dailyRemaining)
  const definition = getBuildingDefinition(selectedId)
  const nexusOwnership = ownership.find(item => item.definition_id === 'reboot-nexus')
  const savedCustomization = useMemo(
    () => normalizeBuildingCustomization(nexusOwnership?.customization ?? DEFAULT_NEXUS_CUSTOMIZATION),
    [nexusOwnership?.customization],
  )
  const [draft, setDraft] = useState<BuildingCustomization>(savedCustomization)
  const selectedPlacement = useMemo(() => placements.find(placement =>
    selectedId === 'reboot-nexus'
      ? placement.ownership_id === nexusOwnership?.id
      : placement.free_definition_id === selectedId
  ), [nexusOwnership?.id, placements, selectedId])
  const freePlacement = placements.find(placement => placement.free_definition_id !== null)
  const premiumPlacements = placements.filter(placement => placement.ownership_id !== null)
  // The server reuses the single free slot row for any free design, and the own row when repositioning.
  const excludedPlacementId = selectedId === 'reboot-nexus' ? selectedPlacement?.id ?? null : freePlacement?.id ?? null
  const cells = useMemo(() => occupiedCells(placements, ownership, excludedPlacementId), [placements, ownership, excludedPlacementId])
  const overlap = useMemo(() => conflictLabel(target, selectedId, cells), [target, selectedId, cells])
  const suggestion = useMemo(() => overlap ? findFreeAnchor(selectedId, target.rotation, cells) : null, [overlap, selectedId, target.rotation, cells])

  useEffect(() => { setDraft(savedCustomization) }, [savedCustomization])

  // Depend on the saved coordinates, not the record identity: every reload hands
  // back new objects, which used to discard grid edits the player had not saved.
  useEffect(() => {
    if (!selectedPlacement) return
    setTarget({ x: selectedPlacement.grid_x, z: selectedPlacement.grid_z, rotation: selectedPlacement.rotation })
  }, [selectedPlacement?.id, selectedPlacement?.grid_x, selectedPlacement?.grid_z, selectedPlacement?.rotation])

  useEffect(() => {
    const focusable = dialog.current?.querySelector<HTMLElement>('button, input, select, [tabindex="0"]')
    focusable?.focus()
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null
    return () => previous?.focus()
  }, [])

  const choose = (id: BuildingId) => {
    setSelectedId(id)
    setConfirmPurchase(false)
    setMessage('')
    const existing = id === 'reboot-nexus'
      ? placements.find(placement => placement.ownership_id === nexusOwnership?.id)
      : placements.find(placement => placement.free_definition_id === id)
    if (existing) { setTarget({ x: existing.grid_x, z: existing.grid_z, rotation: existing.rotation }); return }
    const occupied = occupiedCells(placements, ownership, id === 'reboot-nexus' ? null : freePlacement?.id ?? null)
    setTarget(findFreeAnchor(id, 0, occupied) ?? DEFAULT_PLACEMENT)
  }

  const onDialogKeyDown = (event: ReactKeyboardEvent<HTMLElement>) => {
    if (event.key === 'Escape') { event.preventDefault(); onClose(); return }
    if (event.key !== 'Tab' || !dialog.current) return
    const items = [...dialog.current.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), select:not(:disabled), [tabindex="0"]')]
    if (!items.length) return
    const first = items[0], last = items[items.length - 1]
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus() }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus() }
  }

  const runPlacement = async () => {
    setMessage('')
    if (selectedId === 'reboot-nexus') {
      if (!nexusOwnership) { setConfirmPurchase(true); return }
      const ok = await useEconomy.getState().placeOwned(nexusOwnership.id, target.x, target.z, target.rotation)
      setMessage(ok ? 'Nexus position saved. Ownership is unchanged.' : useEconomy.getState().error ?? 'Placement could not be saved.')
      return
    }
    const ok = await useEconomy.getState().placeFree(selectedId, target.x, target.z, target.rotation)
    setMessage(ok ? `${definition.name} is now your active free building.` : useEconomy.getState().error ?? 'Placement could not be saved.')
  }

  const purchase = async () => {
    setConfirmPurchase(false)
    setMessage('')
    const ok = await useEconomy.getState().purchase('reboot-nexus')
    if (ok) {
      // Ownership is now a fact the server can verify, so ask it which
      // achievements that unlocked rather than claiming one locally.
      const award = awardMessage(await awardAchievements())
      setMessage(`Reboot Nexus is yours permanently. Choose a placement when ready.${award ? ` ${award}` : ''}`)
      setTab('owned')
      return
    }
    setMessage(useEconomy.getState().error ?? 'Purchase was not confirmed.')
  }

  const remove = async (placementId: string, name: string) => {
    setMessage('')
    const ok = await useEconomy.getState().removePlacement(placementId)
    setMessage(ok ? `${name} removed from the grid. Ownership is unchanged.` : useEconomy.getState().error ?? 'The placement could not be removed.')
  }

  return <div className="building-shop-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose() }}>
    <section ref={dialog} className="building-shop glass-strong" role="dialog" aria-modal="true" aria-labelledby={titleId} onKeyDown={onDialogKeyDown}>
      <header className="building-shop-header">
        <div><p className="label-mono">REBOOT PLANET / ARCHIVE EXCHANGE</p><h2 id={titleId}>Building shop</h2></div>
        <div className="building-shop-header-actions">
          <span className="planet-wallet"><Coins size={13} /> {balance.toLocaleString()}</span>
          <button type="button" className="building-shop-close" aria-label="Close building shop" onClick={onClose}><X size={18} /></button>
        </div>
      </header>

      <nav className="building-shop-tabs" aria-label="Building shop sections">
        {TABS.map(item => <button key={item.id} type="button" aria-pressed={tab === item.id} onClick={() => setTab(item.id)}>
          {item.label}{item.id === 'owned' && ownership.length > 0 ? ` (${ownership.length})` : ''}
        </button>)}
        <button type="button" className="building-shop-refresh" disabled={loading || busy} onClick={() => void useEconomy.getState().loadEconomy()}><RefreshCw size={12} /> Refresh</button>
      </nav>

      {loading && <p className="building-shop-status" role="status">Synchronizing your buildings and wallet…</p>}
      {error && <p className="building-shop-error" role="alert">{error}</p>}
      {message && <p className="building-shop-success" role="status">{message}</p>}

      {tab === 'catalogue' && <div className="building-shop-catalogue">
        <div className="building-shop-list" aria-label="Building catalogue">
          <p className="label-mono">TEN FREE DESIGNS · ONE ACTIVE GRID SLOT</p>
          {BUILDING_DEFINITIONS.filter(item => !item.isPremium).map(item => {
            const activeFree = freePlacement?.free_definition_id === item.id
            return <button key={item.id} type="button" className="building-shop-card" aria-pressed={selectedId === item.id}
              onClick={() => choose(item.id)}>
              <span><strong>{item.name}</strong><small>{item.description}</small></span>
              <span className={activeFree ? 'building-shop-badge is-active' : 'building-shop-badge'}>{activeFree ? 'ON GRID' : 'FREE'}</span>
            </button>
          })}
          <p className="label-mono">PREMIUM</p>
          {BUILDING_DEFINITIONS.filter(item => item.isPremium).map(item =>
            <button key={item.id} type="button" className="building-shop-card is-premium" aria-pressed={selectedId === item.id}
              onClick={() => choose(item.id)}>
              <span><strong>{item.name}</strong><small>{item.description}</small></span>
              <span className={nexusOwnership ? 'building-shop-badge is-owned' : 'building-shop-badge is-price'}>
                {nexusOwnership ? 'OWNED' : <><Coins size={11} /> {item.price.toLocaleString()}</>}
              </span>
            </button>
          )}
        </div>

        <div className="building-shop-detail">
          <div className="building-shop-detail-head">
            <div><p className="label-mono">{definition.isPremium ? 'PREMIUM MEGASTRUCTURE' : 'FREE DESIGN'}</p><h3>{definition.name}</h3></div>
            {definition.isPremium && !nexusOwnership && <span className="building-shop-price"><Coins size={14} /> {definition.price.toLocaleString()}</span>}
          </div>
          <ModelPreview definitionId={selectedId} customization={selectedId === 'reboot-nexus' ? draft : undefined} />
          <p className="building-shop-description">{definition.description}{
            definition.isPremium
              ? ' Two piers carrying widening canopies, a gate you can walk through, and an aperture cut through the roof. Permanent ownership survives refresh, login, and placement changes.'
              : ' Selecting another free design replaces only your active free placement. Owned Nexuses are never affected.'
          }</p>
          {!definition.isPremium && freePlacement && freePlacement.free_definition_id !== selectedId &&
            <p className="building-shop-warning">Your current free slot holds {getBuildingDefinition(freePlacement.free_definition_id!).name}. Placing this design will replace that free placement.</p>}
          <PlacementControls target={target} id={selectedId} disabled={busy} onChange={setTarget} />
          {overlap && <div className="building-shop-conflict">
            <p className="building-shop-warning"><AlertTriangle size={13} /> {overlap === 'the world edge' ? 'That footprint reaches past the world edge. Pull the anchor toward the centre.' : `That footprint overlaps your ${overlap}. Choose another cell, or drop it on a free one.`}</p>
            {suggestion && <button type="button" className="btn" disabled={busy} onClick={() => setTarget(suggestion)}><MapPin size={13} /> Use free cell {suggestion.x}, {suggestion.z}</button>}
          </div>}
          {selectedId === 'reboot-nexus' && !nexusOwnership && <section className="building-shop-purchase">
            <p>One-time purchase with Reboot Coins. No subscription or real-money charge.</p>
            {balance < definition.price && <p className="building-shop-warning"><LockKeyhole size={13} /> You need {(definition.price - balance).toLocaleString()} more coins. Keep contributing and participating to earn them.</p>}
            {confirmPurchase
              ? <div className="building-shop-confirm" role="group" aria-label="Confirm Nexus purchase">
                <p>Spend <strong>{definition.price.toLocaleString()} coins</strong> for permanent Nexus ownership?</p>
                <button type="button" className="btn btn-primary" disabled={busy || balance < definition.price} onClick={() => void purchase()}>Confirm purchase</button>
                <button type="button" className="btn" disabled={busy} onClick={() => setConfirmPurchase(false)}>Cancel</button>
              </div>
              : <button type="button" className="btn btn-primary" disabled={busy || balance < definition.price} onClick={() => setConfirmPurchase(true)}><ShoppingBag size={14} /> Buy Nexus for {definition.price.toLocaleString()}</button>}
          </section>}
          {selectedId === 'reboot-nexus' && nexusOwnership && <>
            <div className="building-shop-actions">
              <button type="button" className="btn btn-primary" disabled={busy || !!overlap} onClick={() => void runPlacement()}>{selectedPlacement ? 'Save new position' : 'Place Nexus'}</button>
              {selectedPlacement && <button type="button" className="btn" disabled={busy} onClick={() => void remove(selectedPlacement.id, 'Reboot Nexus')}><Trash2 size={13} /> Remove from grid</button>}
            </div>
            <CustomizationEditor ownershipId={nexusOwnership.id} saved={nexusOwnership.customization} draft={draft} onChange={setDraft} disabled={busy} />
          </>}
          {!definition.isPremium && <div className="building-shop-actions">
            <button type="button" className="btn btn-primary" disabled={busy || !!overlap} onClick={() => void runPlacement()}>{selectedPlacement ? 'Save position' : freePlacement ? 'Replace free placement' : 'Place free building'}</button>
          </div>}
        </div>
      </div>}

      {tab === 'owned' && <div className="building-shop-owned">
        {!ownership.length && <div className="building-shop-empty"><ShoppingBag size={28} /><h3>No premium buildings yet</h3><p>Free designs can be placed at any time. The Reboot Nexus is the first permanent premium structure.</p><button type="button" className="btn" onClick={() => { setTab('catalogue'); choose('reboot-nexus') }}>View Reboot Nexus</button></div>}
        {ownership.map(item => {
          const ownedDefinition = getBuildingDefinition(item.definition_id)
          const placement = placements.find(candidate => candidate.ownership_id === item.id)
          return <article key={item.id} className="building-shop-owned-card">
            <div><p className="label-mono">PERMANENT OWNERSHIP</p><h3>{ownedDefinition.name}</h3><p>Acquired {formatDate(item.acquired_at)} · {placement ? `Placed at ${placement.grid_x}, ${placement.grid_z}` : 'Not on the grid'}</p></div>
            <div className="building-shop-actions">
              <button type="button" className="btn" disabled={busy} onClick={() => { setTab('catalogue'); choose(ownedDefinition.id) }}>{placement ? 'Reposition' : 'Place'}</button>
              {placement && <button type="button" className="btn" disabled={busy} onClick={() => void remove(placement.id, ownedDefinition.name)}><Trash2 size={13} /> Remove</button>}
            </div>
          </article>
        })}
        <section className="building-shop-rules">
          <h3>How ownership works</h3>
          <p>Purchases are tied to your account and remain yours across refresh, logout, and login. Removing a building from the grid does not delete or refund its ownership. Your free slot remains separate from premium placements.</p>
        </section>
      </div>}

      {tab === 'wallet' && <div className="building-shop-wallet">
        <section className="building-shop-balance"><p className="label-mono">REBOOT COINS</p><strong>{balance.toLocaleString()}</strong>
          <p>Earned through validated activity and trusted contribution rewards. The server is the source of truth for every balance.</p>
          {dailyRemaining !== null && <p className="building-shop-hint">{dailyRemaining.toLocaleString()} activity coins remain in today’s cap.</p>}
        </section>
        <section className="building-shop-ledger">
          <div className="building-shop-section-head"><h3>Recent ledger</h3><span>{premiumPlacements.length} premium {premiumPlacements.length === 1 ? 'placement' : 'placements'}</span></div>
          {!transactions.length && <p>No coin activity recorded yet. Validated participation and moderated contributions appear here.</p>}
          {transactions.map(transaction => <div key={transaction.id} className="building-shop-transaction">
            <span><strong>{transaction.reason}</strong><small>{transaction.type} · {formatDate(transaction.createdAt)}</small></span>
            <span className={transaction.amount >= 0 ? 'is-positive' : 'is-negative'}>{transaction.amount > 0 ? '+' : ''}{transaction.amount.toLocaleString()}</span>
          </div>)}
        </section>
      </div>}
    </section>
  </div>
}
